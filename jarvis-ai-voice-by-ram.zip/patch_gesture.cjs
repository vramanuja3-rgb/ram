const fs = require('fs');
let content = fs.readFileSync('src/components/Mark85SuitWidget.tsx', 'utf8');

// Add imports
if (!content.includes('useGestureDetection')) {
  content = content.replace(
    "import { SystemStatusWidget } from './SystemStatusWidget';",
    "import { SystemStatusWidget } from './SystemStatusWidget';\nimport { useGestureDetection } from '../hooks/useGestureDetection';"
  );
}

// Add hook inside component
if (!content.includes('const isScanning = useGestureDetection(')) {
  content = content.replace(
    "export const Mark85SuitWidget: React.FC<Mark85SuitWidgetProps> = ({",
    "export const Mark85SuitWidget: React.FC<Mark85SuitWidgetProps> = ({\n"
  );
  
  content = content.replace(
    "  transcript\n}) => {",
    "  transcript\n}) => {\n  const isScanning = useGestureDetection(2000, 3000);"
  );
}

// Add the style and scan overlay
if (!content.includes('hud-scan')) {
  const scanOverlay = `
      {/* Gesture Scan Overlay */}
      <style>{\`
        @keyframes hud-scan {
          0% { transform: translateY(-10vh); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translateY(110vh); opacity: 0; }
        }
        .animate-hud-scan {
          animation: hud-scan 1.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        }
      \`}</style>
      {isScanning && (
        <div className="absolute inset-0 pointer-events-none z-50 overflow-hidden flex flex-col">
          <div className="w-full h-1 bg-cyan-400 shadow-[0_0_30px_10px_rgba(6,182,212,0.6)] animate-hud-scan relative">
             {/* Scan trail */}
             <div className="absolute bottom-full left-0 w-full h-32 bg-gradient-to-t from-cyan-500/20 to-transparent" />
          </div>
        </div>
      )}
`;

  content = content.replace(
    "      {/* Background Grid & Hexagons */}",
    scanOverlay + "\n      {/* Background Grid & Hexagons */}"
  );
}

fs.writeFileSync('src/components/Mark85SuitWidget.tsx', content);
