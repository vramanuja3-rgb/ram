const fs = require('fs');
let widget = fs.readFileSync('src/components/StarkLabWidget.tsx', 'utf8');

// Fix syntax error with backslash in the style template literal
widget = widget.replace(
  "backgroundImage: \\`linear-gradient",
  "backgroundImage: `linear-gradient"
);
widget = widget.replace(
  "1px)\\`,",
  "1px)`,"
);

fs.writeFileSync('src/components/StarkLabWidget.tsx', widget);
