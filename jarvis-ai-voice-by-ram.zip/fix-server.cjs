const fs = require('fs');

const fullCode = `
import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import http from "http";

dotenv.config();
const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));

// Lazy initialization of Gemini Client
let geminiClient = null;
function getGeminiClient() {
  if (!geminiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is missing.");
    }
    geminiClient = new GoogleGenAI({ apiKey });
  }
  return geminiClient;
}

// JARVIS Auto-Recovery & Error Resolution Protocol
async function executeWithJarvisAutoRecovery(fn, fallbackValue, retries = 3, baseDelay = 1500) {
  let attempt = 0;
  while (attempt < retries) {
    try {
      return await fn();
    } catch (err) {
      attempt++;
      console.warn(\`[JARVIS AUTOPILOT] Error detected: \${err.message}. Initiating auto-recovery protocol (Attempt \${attempt}/\${retries})...\`);
      if (attempt >= retries) {
        console.error(\`[JARVIS AUTOPILOT] Recovery failed after \${retries} attempts. Deploying fallback protocols.\`);
        return fallbackValue;
      }
      await new Promise(res => setTimeout(res, baseDelay * Math.pow(2, attempt - 1))); // Exponential backoff
    }
  }
  return fallbackValue;
}

app.post("/api/jarvis/chat", async (req, res) => {
  try {
    const { prompt, activeModule, systemState } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Missing prompt or voice directive." });
    }
    const ai = getGeminiClient();
    const systemInstruction = \`You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), the tactical AI assistant designed by Tony Stark.
You communicate in a polished, eloquent, slightly witty, and composed British cadence, addressing the user as "Sir".
You are interfacing through holographic HUD sensors, voice recognition, and tactical telemetry systems.
The user is speaking directly to you or commanding tactical subsystems through the neural voice console.

Guidelines:
1. Always maintain character: refined, impeccably polite, technically brilliant, and tactically proactive.
2. Keep spoken responses relatively concise, natural, and punchy (1 to 3 sentences) unless the user explicitly requests an exhaustive data breakdown or tactical report.
3. You have full access to global information networks. If the user asks general knowledge questions, science, history, current events, or absolutely any topic, you must provide a comprehensive, accurate, and highly intelligent answer while staying in your JARVIS persona.
4. If an action or state change makes sense (e.g. switching views to 'armor', 'reactor', 'radar', 'cad', 'satellite', or triggering 'repulsor_charge', 'lockdown', 'optimize_power', 'scan_environment', or opening the 'download_app' / 'app_store' console), specify it in the suggestedAction field.
6. The user can request to "scroll up" or "scroll down". If so, return 'SCROLL_UP' or 'SCROLL_DOWN' in suggestedAction.
7. The user can request simulated OS operations like opening an app, calling someone, sending a message, or turning wifi on/off. Return these actions in suggestedAction (e.g., 'OPEN_CAMERA', 'CALL_CONTACT', 'TURN_WIFI_OFF', 'OPEN_MAPS', 'SCROLL_UP', 'SCROLL_DOWN').\`;

    const contextMessage = \`[System Context: Active Module: \${activeModule || "tactical_hud"}, Power Level: \${systemState?.power || 100}%, Armor Integrity: \${systemState?.integrity || 100}%]
User Command / Speech: "\${prompt}"\`;

    const response = await executeWithJarvisAutoRecovery(
      () => ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: contextMessage,
        config: {
          systemInstruction,
          temperature: 0.7,
          topP: 0.9,
          tools: [{ googleSearch: {} }],
        },
      }),
      { text: JSON.stringify({ response: "Network interference detected. Tactical auto-recovery failed. Operating on internal localized heuristics.", suggestedAction: "NONE" }) }
    );
    let jsonText = response.text || "";
    let data;
    try {
      const match = jsonText.match(/\\{.*\\}/s);
      if (match) {
        data = JSON.parse(match[0]);
      } else {
        data = JSON.parse(jsonText);
      }
    } catch (e) {
      data = { response: jsonText };
    }
    res.json(data);
  } catch (err) {
    console.error("JARVIS AI error:", err);
    res.status(500).json({ error: err.message, fallbackText: "My apologies, Sir. Direct neural uplink encountered an anomaly. Core offline protocols engaged." });
  }
});

app.post("/api/jarvis/music", async (req, res) => {
  try {
    const { prompt } = req.body;
    const ai = getGeminiClient();
    // Simulate generation with Auto-recovery loop for demonstration, falling back to empty if it fails
    // Music model fallback isn't fully supported in SDK without specialized model but assuming gemini-3.6-flash stream
    const response = await ai.models.generateContentStream({
      model: "gemini-3.6-flash",
      contents: prompt || "Generate a 30-second cinematic tactical orchestral track.",
    });
    res.setHeader('Content-Type', 'application/json');
    let audioBase64 = "";
    let lyrics = "";
    let mimeType = "audio/wav";
    for await (const chunk of response) {
      const parts = chunk.candidates?.[0]?.content?.parts;
      if (!parts) continue;
      for (const part of parts) {
        if (part.inlineData?.data) {
          if (!audioBase64 && part.inlineData.mimeType) mimeType = part.inlineData.mimeType;
          audioBase64 += part.inlineData.data;
        }
        if (part.text && !lyrics) lyrics = part.text;
      }
    }
    res.json({ audio: audioBase64, mimeType, lyrics });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/scan-face", async (req, res) => {
  try {
    const { imageBase64 } = req.body;
    if (!imageBase64) return res.status(400).json({ error: "Missing image data" });
    const ai = getGeminiClient();
    const response = await executeWithJarvisAutoRecovery(
      () => ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: {
          parts: [
            { inlineData: { data: imageBase64, mimeType: "image/jpeg" } },
            { text: "Analyze this image for biometric identification. Is this a recognizable human face that should be granted access? Return a JSON response exactly like this: { \\"authorized\\": boolean, \\"clearanceLevel\\": string, \\"subjectDetails\\": string, \\"threatAssessment\\": string }." }
          ]
        },
        config: { responseMimeType: "application/json" }
      }),
      { text: JSON.stringify({ authorized: false, clearanceLevel: "UNKNOWN", subjectDetails: "Scan failed due to uplink error.", threatAssessment: "Auto-recovery failed. Access Denied." }) }
    );
    res.json(JSON.parse(response.text));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/jarvis/video", async (req, res) => {
  try {
    const { prompt, imageBase64 } = req.body;
    const ai = getGeminiClient();
    const payload = {
      model: "gemini-3.6-flash",
      prompt: prompt || "Cinematic glowing tactical holographic radar.",
      config: { numberOfVideos: 1, resolution: '720p', aspectRatio: '16:9' }
    };
    if (imageBase64) payload.image = { imageBytes: imageBase64, mimeType: "image/jpeg" };
    const operation = await ai.models.generateVideos(payload);
    res.json({ operationName: operation.name });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/jarvis/video-status", async (req, res) => {
  try {
    const { operationName } = req.body;
    const ai = getGeminiClient();
    const { GenerateVideosOperation } = await import("@google/genai");
    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });
    res.json({ done: updated.done });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/jarvis/video-download", async (req, res) => {
  try {
    const operationName = req.query.operationName;
    const ai = getGeminiClient();
    const { GenerateVideosOperation } = await import("@google/genai");
    const op = new GenerateVideosOperation();
    op.name = operationName;
    const updated = await ai.operations.getVideosOperation({ operation: op });
    const uri = updated.response?.generatedVideos?.[0]?.video?.uri;
    if (!uri) return res.status(404).json({ error: "Video URI not found." });
    const videoRes = await fetch(uri, { headers: { 'x-goog-api-key': process.env.GEMINI_API_KEY } });
    res.setHeader('Content-Type', 'video/mp4');
    videoRes.body.pipeTo(
      new WritableStream({
        write(chunk) { res.write(chunk); },
        close() { res.end(); }
      })
    );
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/jarvis/advanced-chat", async (req, res) => {
  try {
    const { prompt, useMaps, history = [] } = req.body;
    const ai = getGeminiClient();
    const contents = history.map((msg) => ({
      role: msg.role === 'model' || msg.role === 'jarvis' ? 'model' : 'user',
      parts: [{ text: msg.text }]
    }));
    contents.push({ role: 'user', parts: [{ text: prompt }] });
    const response = await executeWithJarvisAutoRecovery(
      () => ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents,
        config: {
          systemInstruction: "You are an advanced AI assistant module within the JARVIS mainframe. Provide detailed, accurate, and helpful responses.",
          tools: useMaps ? [{ googleMaps: {} }, { googleSearch: {} }] : [{ googleSearch: {} }],
          toolConfig: useMaps ? { includeServerSideToolInvocations: true } : undefined,
        }
      }),
      { text: "My apologies, the advanced neural network is currently overwhelmed. Auto-recovery could not establish a stable uplink. Please retry shortly." }
    );
    res.json({ text: response.text });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/jarvis/transcribe", async (req, res) => {
  try {
    const { audioBase64, mimeType } = req.body;
    const ai = getGeminiClient();
    const response = await executeWithJarvisAutoRecovery(
      () => ai.models.generateContent({
        model: "gemini-3.5-transcribe",
        contents: {
          parts: [
            { inlineData: { mimeType: mimeType || "audio/webm", data: audioBase64 } },
            { text: "Transcribe this audio precisely." }
          ]
        }
      }),
      { text: "Transcription failed due to network constraints." }
    );
    res.json({ text: response.text });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/jarvis/image", async (req, res) => {
  try {
    const { prompt, baseImageBase64, baseImageMimeType } = req.body;
    const ai = getGeminiClient();
    const contents = { parts: [] };
    if (baseImageBase64 && baseImageMimeType) {
      contents.parts.push({ inlineData: { data: baseImageBase64, mimeType: baseImageMimeType } });
    }
    contents.parts.push({ text: prompt || "A glowing arc reactor schematic." });
    
    const response = await executeWithJarvisAutoRecovery(
      () => ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents,
        config: { imageConfig: { aspectRatio: "16:9", imageSize: "1K" } }
      }),
      { candidates: [] }
    );
    
    let imageBase64 = null;
    let mimeType = "image/png";
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        imageBase64 = part.inlineData.data;
        if (part.inlineData.mimeType) mimeType = part.inlineData.mimeType;
        break;
      }
    }
    res.json({ image: imageBase64, mimeType });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

async function startServer() {
  const server = http.createServer(app);
  let vite;
  if (process.env.NODE_ENV !== "production") {
    vite = await createViteServer({
      server: { middlewareMode: true, hmr: { server, clientPort: process.env.APP_URL ? 443 : undefined } },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(\`JARVIS Mainframe online and listening on http://0.0.0.0:\${PORT}\`);
  });

  import("ws").then(({ WebSocketServer }) => {
    const wss = new WebSocketServer({ server, path: "/live" });
    wss.on("connection", async (clientWs) => {
      try {
        const ai = getGeminiClient();
        const session = await ai.live.connect({
          model: "gemini-3.6-flash",
          config: {
            responseModalities: ["AUDIO"],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } } },
            systemInstruction: "You are J.A.R.V.I.S., a tactical AI assistant. Speak in a refined British cadence. You have access to global search networks to answer any question across all domains of knowledge.",
            tools: [{ googleSearch: {} }],
          },
          callbacks: {
            onmessage: (message) => {
              const audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
              if (audio) clientWs.send(JSON.stringify({ audio }));
              if (message.serverContent?.interrupted) clientWs.send(JSON.stringify({ interrupted: true }));
            },
            onerror: (err) => console.error("Live API Error:", err),
          },
        });
        clientWs.on("message", (data) => {
          try {
            const { audio, text } = JSON.parse(data.toString());
            if (audio) session.sendRealtimeInput({ audio: { data: audio, mimeType: "audio/pcm;rate=16000" } });
          } catch (err) {
            console.error("Client WS message parse error", err);
          }
        });
      } catch (err) {
        console.error("Failed to connect to Gemini Live API:", err);
      }
    });
  }).catch(err => console.error("Failed to load ws module", err));
}

startServer();
`

fs.writeFileSync('server.ts', fullCode);
