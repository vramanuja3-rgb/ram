const fs = require('fs');
let content = fs.readFileSync('src/types.ts', 'utf8');
content = content.replace(
  "export type AppView = 'dashboard' | 'chat' | 'settings' | 'memory';",
  "export type AppView = 'dashboard' | 'chat' | 'settings' | 'memory' | 'tactical';"
);
fs.writeFileSync('src/types.ts', content);
