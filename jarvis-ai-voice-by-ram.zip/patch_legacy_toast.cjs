const fs = require('fs');
let content = fs.readFileSync('src/components/LegacyHUD.tsx', 'utf8');

// Update Props
content = content.replace(
  'interface LegacyHUDProps {',
  `interface LegacyHUDProps {
  deviceAction?: string | null;
  onClearDeviceAction?: () => void;`
);

// Update destructuring
content = content.replace(
  'onToggleJarvisVoice,\n  onNavigate\n})',
  `onToggleJarvisVoice,
  onNavigate,
  deviceAction,
  onClearDeviceAction
})`
);

// Add useEffect for toast timer and lucide icons
content = content.replace(
  'import { Mic, Send, Volume2, VolumeX, Sparkles, Bot, User, Radio, X } from \'lucide-react\';',
  'import { Mic, Send, Volume2, VolumeX, Sparkles, Bot, User, Radio, X, Activity } from \'lucide-react\';'
);

const toastEffect = `
  useEffect(() => {
    if (deviceAction && onClearDeviceAction) {
      const timer = setTimeout(() => {
        onClearDeviceAction();
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [deviceAction, onClearDeviceAction]);
`;

content = content.replace(
  'const [inputText, setInputText] = useState(\'\');',
  'const [inputText, setInputText] = useState(\'\');' + toastEffect
);

// Add the toast to the DOM
const toastMarkup = `
      {/* Device Action Toast */}
      {deviceAction && (
        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="flex items-center gap-3 px-6 py-3 bg-cyan-950/90 border border-cyan-400 rounded-lg shadow-[0_0_20px_rgba(34,211,238,0.4)] backdrop-blur-md">
            <Activity className="w-5 h-5 text-cyan-400 animate-pulse" />
            <div className="flex flex-col">
              <span className="font-orbitron text-[10px] text-cyan-300 tracking-widest uppercase">Network Update</span>
              <span className="font-mono-tech text-sm text-cyan-100">{deviceAction}</span>
            </div>
          </div>
        </div>
      )}
`;

content = content.replace(
  '<div className="flex flex-col h-full bg-black/90 p-4 font-rajdhani">',
  '<div className="flex flex-col h-full bg-black/90 p-4 font-rajdhani relative">' + toastMarkup
);

fs.writeFileSync('src/components/LegacyHUD.tsx', content);
