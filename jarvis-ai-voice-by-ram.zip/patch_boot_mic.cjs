const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

const bootMic = `
      recognitionRef.current = recognition;
      
      // Auto-start hands-free mode if wake word is enabled
      if (settings.wakeWordEnabled) {
         autoRestartRef.current = true;
         try { recognition.start(); } catch(e) { console.warn("Auto-start mic blocked by browser"); }
      }
`;

content = content.replace("recognitionRef.current = recognition;", bootMic);
fs.writeFileSync('src/App.tsx', content);
