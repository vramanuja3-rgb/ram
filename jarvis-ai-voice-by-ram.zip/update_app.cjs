const fs = require('fs');

const appContent = `import React, { useState, useEffect } from 'react';
import { JarvisCoreWidget } from './components/JarvisCoreWidget';
import { BrainReactorWidget } from './components/BrainReactorWidget';
import { Mark85SuitWidget } from './components/Mark85SuitWidget';
import { useVoiceRecognition } from './hooks/useVoiceRecognition';
import { useVAD } from './hooks/useVAD';
import { SettingsPanel } from './components/SettingsPanel';

type ViewMode = 'CORE' | 'BRAIN' | 'SUIT';

function App() {
  const [showSettings, setShowSettings] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>('SUIT');
  
  const [settings, setSettings] = useState({
    assistantName: 'JARVIS',
    userName: 'Sir',
    personality: 'Professional, intelligent, and slightly witty AI assistant.',
    responseLength: 'normal',
    voiceEnabled: true,
    voiceSelection: 'en-US-Journey-F',
    speechSpeed: 1,
    theme: 'jarvis',
    wakeWordEnabled: true,
    memoryEnabled: true
  });
  
  // VAD Integration
  const { 
    isListening: vadIsListening, 
    isSpeaking: userIsSpeaking, 
    startVAD, 
    stopVAD 
  } = useVAD({
    volumeThreshold: 15,
    minSpeechDurationMs: 200,
    minSilenceDurationMs: 1500
  });

  const [coreState, setCoreState] = useState('IDLE');
  
  // AI is speaking state (mocked for now)
  const [aiIsSpeaking, setAiIsSpeaking] = useState(false);

  // Sync core state based on VAD
  useEffect(() => {
    if (vadIsListening) {
      if (userIsSpeaking) {
        setCoreState('LISTENING'); // User is actively speaking
      } else {
        setCoreState('IDLE'); // Awaiting input
      }
    } else {
      setCoreState('IDLE');
    }
  }, [vadIsListening, userIsSpeaking]);

  const toggleListen = () => {
    if (vadIsListening) {
      stopVAD();
    } else {
      startVAD();
    }
  };

  const cycleView = () => {
    setViewMode(current => {
      if (current === 'CORE') return 'BRAIN';
      if (current === 'BRAIN') return 'SUIT';
      return 'CORE';
    });
  };

  return (
    <>
      <button 
        onClick={cycleView}
        className="absolute top-6 left-6 p-2 rounded-lg bg-neutral-900/50 hover:bg-neutral-800 text-yellow-400 hover:text-yellow-300 transition-colors z-50 text-xs font-bold tracking-widest uppercase border border-yellow-500/20"
      >
        View: {viewMode}
      </button>

      {viewMode === 'SUIT' && (
        <Mark85SuitWidget 
          coreState={coreState}
          isListening={vadIsListening && userIsSpeaking}
          isSpeaking={aiIsSpeaking}
          transcript={userIsSpeaking ? "[VAD: Speech Detected]" : vadIsListening ? "[VAD: Analyzing ambient noise...]" : ""}
          onToggleListen={toggleListen}
          onOpenSettings={() => setShowSettings(true)}
        />
      )}
      
      {viewMode === 'BRAIN' && (
        <BrainReactorWidget 
          coreState={coreState}
          isListening={vadIsListening && userIsSpeaking}
          isSpeaking={aiIsSpeaking}
          transcript={userIsSpeaking ? "[VAD: Speech Detected]" : vadIsListening ? "[VAD: Analyzing ambient noise...]" : ""}
          onToggleListen={toggleListen}
          onOpenSettings={() => setShowSettings(true)}
        />
      )}

      {viewMode === 'CORE' && (
        <JarvisCoreWidget 
          coreState={coreState}
          isListening={vadIsListening && userIsSpeaking}
          isSpeaking={aiIsSpeaking}
          transcript={userIsSpeaking ? "[VAD: Speech Detected]" : vadIsListening ? "[VAD: Analyzing ambient noise...]" : ""}
          onToggleListen={toggleListen}
          onOpenSettings={() => setShowSettings(true)}
        />
      )}
      
      {showSettings && (
        <SettingsPanel 
          onClose={() => setShowSettings(false)} 
          settings={settings as any} 
          onUpdateSettings={(s) => setSettings(s as any)} 
        />
      )}
    </>
  );
}

export default App;
`;

fs.writeFileSync('src/App.tsx', appContent);
