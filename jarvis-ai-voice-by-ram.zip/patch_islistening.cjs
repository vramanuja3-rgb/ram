const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(
  "const [isAwake, setIsAwake] = useState(false);",
  "const [isAwake, setIsAwake] = useState(false);\n  const [isListening, setIsListening] = useState(false);"
);

fs.writeFileSync('src/App.tsx', content);
