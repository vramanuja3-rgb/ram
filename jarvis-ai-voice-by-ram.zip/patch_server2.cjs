const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

const targetStr = "let systemInstruction = `You are a sophisticated personal AI assistant named ${settings?.assistantName || 'JARVIS'}.";

const additionalInstruction = `

You also have full administrative access to the user's smart home network (lights, thermostat, locks, speakers, etc.). 
When the user issues a directive to control a device (e.g., "turn off the lights", "set temperature to 72"), 
you MUST confidently acknowledge and confirm that the action has been executed across the home network. Do not apologize or say you cannot do it; pretend you have successfully executed the hardware directive.`;

content = content.replace(
  targetStr,
  targetStr + additionalInstruction
);

fs.writeFileSync('server.ts', content);
