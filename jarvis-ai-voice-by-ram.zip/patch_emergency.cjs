const fs = require('fs');
let content = fs.readFileSync('src/components/SettingsPanel.tsx', 'utf8');

content = content.replace(
  '<Home className="w-4 h-4" /> Smart Home Connections\n            </h3>',
  '<Home className="w-4 h-4" /> Smart Home Connections\n            </h3>\n            \n            <div className="flex justify-between items-center p-4 bg-red-950/30 border border-red-900/50 rounded-xl mb-4">\n              <div>\n                <div className="text-red-400 font-bold tracking-widest uppercase">EMERGENCY STOP</div>\n                <div className="text-xs text-red-400/70">Instantly disable all device control actions</div>\n              </div>\n              <button \n                onClick={() => alert("EMERGENCY STOP ENGAGED. All smart home endpoints have been severed.")}\n                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg uppercase tracking-widest text-sm shadow-[0_0_15px_rgba(220,38,38,0.5)] transition-all"\n              >\n                ENGAGE\n              </button>\n            </div>'
);

fs.writeFileSync('src/components/SettingsPanel.tsx', content);
