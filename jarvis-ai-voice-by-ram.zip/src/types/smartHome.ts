export interface SmartDevice {
  id: string;
  name: string;
  room: string;
  type: 'LIGHT' | 'THERMOSTAT' | 'LOCK' | 'FAN' | 'SPEAKER' | 'SENSOR';
  state: Record<string, any>;
  capabilities: string[];
}

export interface SmartHomeProvider {
  getDevices(): Promise<SmartDevice[]>;
  getDeviceState(deviceId: string): Promise<Record<string, any>>;
  controlDevice(deviceId: string, action: string, parameters: Record<string, any>): Promise<Record<string, any>>;
}
