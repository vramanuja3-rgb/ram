import { useState, useEffect, useRef, useCallback } from 'react';

interface VADOptions {
  fftSize?: number;
  minSilenceDurationMs?: number;
  minSpeechDurationMs?: number;
  volumeThreshold?: number; // Volume above noise floor to trigger speech
}

export function useVAD(options: VADOptions = {}) {
  const {
    fftSize = 512,
    minSilenceDurationMs = 1000,
    minSpeechDurationMs = 150,
    volumeThreshold = 15,
  } = options;

  const [isSpeaking, setIsSpeaking] = useState(false);
  const [volume, setVolume] = useState(0);
  const [noiseFloor, setNoiseFloor] = useState(0);
  const [isSupported, setIsSupported] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);

  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const stateRef = useRef({
    isSpeaking: false,
    noiseFloor: 10,
    framesBelowThreshold: 0,
    framesAboveThreshold: 0,
    lastFrameTime: performance.now()
  });

  const stopVAD = useCallback(() => {
    setIsListening(false);
    setIsSpeaking(false);
    
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (sourceRef.current) {
      sourceRef.current.disconnect();
      sourceRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(console.error);
      audioContextRef.current = null;
    }
  }, []);

  const analyzeAudio = useCallback(() => {
    if (!analyserRef.current) return;

    const bufferLength = analyserRef.current.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    analyserRef.current.getByteFrequencyData(dataArray);

    let sum = 0;
    for (let i = 0; i < bufferLength; i++) {
      sum += dataArray[i];
    }
    const currentVolume = sum / bufferLength;
    setVolume(currentVolume);

    const now = performance.now();
    const dt = now - stateRef.current.lastFrameTime;
    stateRef.current.lastFrameTime = now;

    // Dynamically adjust noise floor (slowly rises, quickly drops)
    if (currentVolume < stateRef.current.noiseFloor) {
      stateRef.current.noiseFloor = currentVolume * 0.5 + stateRef.current.noiseFloor * 0.5;
    } else {
      stateRef.current.noiseFloor += 0.05; // slowly increase
    }
    
    // Clamp noise floor
    if (stateRef.current.noiseFloor < 1) stateRef.current.noiseFloor = 1;
    if (stateRef.current.noiseFloor > 50) stateRef.current.noiseFloor = 50;

    // Avoid updating React state every frame for noise floor
    if (Math.random() < 0.1) {
      setNoiseFloor(Math.round(stateRef.current.noiseFloor));
    }

    const isAboveThreshold = currentVolume > stateRef.current.noiseFloor + volumeThreshold;

    if (isAboveThreshold) {
      stateRef.current.framesAboveThreshold += dt;
      stateRef.current.framesBelowThreshold = 0;

      if (!stateRef.current.isSpeaking && stateRef.current.framesAboveThreshold >= minSpeechDurationMs) {
        stateRef.current.isSpeaking = true;
        setIsSpeaking(true);
      }
    } else {
      stateRef.current.framesBelowThreshold += dt;
      stateRef.current.framesAboveThreshold = 0;

      if (stateRef.current.isSpeaking && stateRef.current.framesBelowThreshold >= minSilenceDurationMs) {
        stateRef.current.isSpeaking = false;
        setIsSpeaking(false);
      }
    }

    animationFrameRef.current = requestAnimationFrame(analyzeAudio);
  }, [minSpeechDurationMs, minSilenceDurationMs, volumeThreshold]);

  const startVAD = useCallback(async () => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) {
        setIsSupported(false);
        setError("Web Audio API is not supported in this browser.");
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      streamRef.current = stream;

      const audioContext = new AudioContextClass();
      audioContextRef.current = audioContext;

      const analyser = audioContext.createAnalyser();
      analyser.fftSize = fftSize;
      analyser.smoothingTimeConstant = 0.4;
      analyserRef.current = analyser;

      const source = audioContext.createMediaStreamSource(stream);
      source.connect(analyser);
      sourceRef.current = source;

      setIsListening(true);
      setError(null);
      
      stateRef.current.lastFrameTime = performance.now();
      analyzeAudio();
      
    } catch (err: any) {
      console.error("[AI_SELF_REPAIR_DIAGNOSTIC] VAD Init Error:", err);
      setError(err.message || "Failed to access microphone for VAD.");
      setIsListening(false);
    }
  }, [analyzeAudio, fftSize]);

  useEffect(() => {
    return () => {
      stopVAD();
    };
  }, [stopVAD]);

  return {
    isListening,
    isSpeaking,
    volume,
    noiseFloor,
    isSupported,
    error,
    startVAD,
    stopVAD
  };
}
