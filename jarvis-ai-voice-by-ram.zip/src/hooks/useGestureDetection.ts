import { useState, useEffect, useRef } from 'react';

export function useGestureDetection(velocityThreshold = 1500, cooldownMs = 2500) {
  const [isGestureDetected, setIsGestureDetected] = useState(false);
  const lastPos = useRef<{x: number, y: number, time: number} | null>(null);
  const cooldownRef = useRef(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (cooldownRef.current) return;

      const now = performance.now();
      const x = e.clientX;
      const y = e.clientY;

      if (lastPos.current) {
        const dt = now - lastPos.current.time;
        // Only measure rapid, continuous movements (avoid jumping if mouse left and re-entered)
        if (dt > 0 && dt < 100) {
          const dx = x - lastPos.current.x;
          const dy = y - lastPos.current.y;
          const distance = Math.hypot(dx, dy);
          const velocity = (distance / dt) * 1000; // pixels per second

          if (velocity > velocityThreshold) {
            setIsGestureDetected(true);
            cooldownRef.current = true;
            
            // Turn off the scanning flag after animation completes
            setTimeout(() => {
              setIsGestureDetected(false);
            }, 1500); // 1.5s animation
            
            // Allow triggering again after cooldown
            setTimeout(() => {
              cooldownRef.current = false;
            }, cooldownMs);
          }
        }
      }
      
      lastPos.current = { x, y, time: now };
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [velocityThreshold, cooldownMs]);

  return isGestureDetected;
}
