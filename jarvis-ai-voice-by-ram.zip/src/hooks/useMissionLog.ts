import { useState, useCallback } from 'react';

export type LogType = 'USER' | 'AI' | 'SYSTEM' | 'WARNING';

export interface LogEntry {
  id: string;
  time: string;
  type: LogType;
  message: string;
}

export function useMissionLog() {
  const [logs, setLogs] = useState<LogEntry[]>([]);

  const addLog = useCallback((type: LogType, message: string) => {
    const now = new Date();
    const time = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
    setLogs(prev => {
      // Don't add duplicate consecutive logs for pure noise filtering
      if (prev.length > 0 && prev[prev.length - 1].message === message) return prev;
      return [...prev, { id: Math.random().toString(36).substr(2, 9), time, type, message }].slice(-50); // Keep last 50
    });
  }, []);

  return { logs, addLog };
}
