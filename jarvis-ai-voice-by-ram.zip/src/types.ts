export type AppView = 'dashboard' | 'chat' | 'settings' | 'memory' | 'tactical';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  isStreaming?: boolean;
  files?: AttachedFile[];
}

export interface AttachedFile {
  name: string;
  type: string;
  url?: string;
  data?: string; // base64
}

export interface ChatSession {
  id: string;
  title: string;
  updatedAt: number;
  messages: ChatMessage[];
}

export interface AppSettings {
  assistantName: string;
  userName: string;
  personality: string;
  responseLength: 'concise' | 'normal' | 'detailed';
  voiceEnabled: boolean;
  voiceSelection: string;
  speechSpeed: number;
  theme: 'dark' | 'light' | 'jarvis';
  wakeWordEnabled: boolean;
  memoryEnabled: boolean;
}

export interface MemoryItem {
  id: string;
  content: string;
  createdAt: number;
}

export type AICoreState = 'IDLE' | 'LISTENING' | 'THINKING' | 'SPEAKING' | 'ERROR';
