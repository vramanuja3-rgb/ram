import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  Share,
  PlusSquare,
  CheckCircle2,
  X,
  Sparkles,
  ExternalLink,
  Apple,
  Play,
  Copy,
  Check,
  FileCode,
  ShieldCheck,
  Layers,
  Laptop,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { soundEffects } from '../utils/audioSystem';

interface AppStoreModalProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export const AppStoreModal: React.FC<AppStoreModalProps> = ({ isOpen: controlledIsOpen, onClose: controlledOnClose }) => {
  const { isInstallable, isInstalled, isIOS, isStandalone, install } = usePWAInstall();
  const [internalIsOpen, setInternalIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'instant' | 'google_play' | 'apple_store' | 'package'>('instant');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const showModal = controlledIsOpen !== undefined ? controlledIsOpen : internalIsOpen;
  const setShowModal = (val: boolean) => {
    if (controlledOnClose && !val) {
      controlledOnClose();
    }
    setInternalIsOpen(val);
  };

  // Detect OS for tailored guidance
  const userAgent = typeof window !== 'undefined' ? window.navigator.userAgent.toLowerCase() : '';
  const isAndroid = /android/.test(userAgent);
  const isMac = /macintosh|mac os x/.test(userAgent) && !isIOS;
  const isWindows = /windows/.test(userAgent);

  const handleCopy = (text: string, id: string) => {
    soundEffects.playChirp();
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleDownloadManifest = () => {
    soundEffects.playChirp();
    const manifestData = {
      id: '/',
      name: 'JARVIS AI MOD',
      short_name: 'JARVIS MOD',
      description: 'Tactical holographic AI system with real-time speech dialogue, tactical diagnostics, sound synthesizers, and Iron Man HUD interfaces.',
      package_name: 'com.stark.jarvis.hud',
      version: '1.0.0',
      theme_color: '#020617',
      background_color: '#020617',
      display: 'standalone',
      orientation: 'any',
      start_url: '/',
      scope: '/',
      categories: ['productivity', 'utilities', 'entertainment'],
      icons: [
        { src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
        { src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
        { src: '/pwa-maskable-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        { src: '/apple-touch-icon.png', sizes: '180x180', type: 'image/png' },
      ],
      play_store: {
        package_id: 'com.stark.jarvis.hud',
        twa_url: typeof window !== 'undefined' ? window.location.origin : '',
        digital_asset_links: '/.well-known/assetlinks.json',
      },
      apple_app_store: {
        bundle_id: 'com.stark.jarvis.hud',
        app_name: 'JARVIS AI MOD',
        category: 'Utilities',
      },
    };

    const blob = new Blob([JSON.stringify(manifestData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'jarvis-app-store-package.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadAssetlinks = () => {
    soundEffects.playChirp();
    const assetlinks = [
      {
        relation: ['delegate_permission/common.handle_all_urls'],
        target: {
          namespace: 'android_app',
          package_name: 'com.stark.jarvis.hud',
          sha256_cert_fingerprints: [
            '14:6D:E9:7D:0F:52:AB:74:66:87:69:B2:76:73:96:D6:FC:E3:77:24:D3:85:6B:4A:26:FA:F8:A2:EB:6E:9A:F0',
          ],
        },
      },
    ];

    const blob = new Blob([JSON.stringify(assetlinks, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'assetlinks.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';
  const pwabuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(currentUrl)}`;

  return (
    <>
      {/* Header Launch Button */}
      <button
        onClick={() => {
          soundEffects.playChirp();
          setShowModal(true);
        }}
        className="flex items-center gap-1.5 px-3 py-1 rounded bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-400 text-cyan-200 text-xs font-orbitron tracking-wider transition-all glow-box-cyan hover:border-cyan-300"
        title="Download in App Store / Install J.A.R.V.I.S. on iPhone, Android, or PC"
      >
        <Download className="w-3.5 h-3.5 text-cyan-300 animate-pulse" />
        <span className="hidden sm:inline">APP STORE / DOWNLOAD</span>
        <span className="sm:hidden">APP STORE</span>
        {isStandalone && (
          <span className="ml-1 w-1.5 h-1.5 rounded-full bg-emerald-400" title="Installed" />
        )}
      </button>

      {/* App Store & Installation Hub Dialog */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-neutral-950 border-2 border-cyan-500/60 rounded-2xl p-4 sm:p-6 shadow-[0_0_60px_rgba(6,182,212,0.35)] text-cyan-200 glow-box-cyan my-8">
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-4 border-b border-cyan-500/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-400 flex items-center justify-center glow-box-cyan shrink-0">
                  <Smartphone className="w-5 h-5 text-cyan-300" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-orbitron font-bold text-sm sm:text-base text-white tracking-wider">
                      APP STORE & INSTALLATION HUB
                    </h3>
                    <span className="text-[10px] font-mono-tech px-2 py-0.5 rounded bg-cyan-900/60 border border-cyan-400/40 text-cyan-300">
                      MARK LXXXV
                    </span>
                  </div>
                  <p className="text-[11px] font-mono-tech text-cyan-400/80">
                    DIRECT DEVICE INSTALL • GOOGLE PLAY STORE • APPLE APP STORE
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  soundEffects.playChirp();
                  setShowModal(false);
                }}
                className="p-1.5 rounded-lg border border-cyan-500/30 text-cyan-400 hover:text-white hover:border-cyan-400 hover:bg-cyan-950 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Current Device Detection Banner */}
            <div className="my-3 py-1.5 px-3 bg-cyan-950/40 border border-cyan-500/20 rounded-lg flex items-center justify-between text-[11px] font-mono-tech">
              <span className="text-neutral-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                CURRENT PLATFORM:
                <strong className="text-cyan-300 uppercase">
                  {isIOS
                    ? 'Apple iOS (iPhone / iPad)'
                    : isAndroid
                    ? 'Google Android'
                    : isMac
                    ? 'Apple macOS'
                    : isWindows
                    ? 'Microsoft Windows'
                    : 'Desktop Browser'}
                </strong>
              </span>
              <span className="text-cyan-400/80">
                {isStandalone ? 'RUNNING AS STANDALONE APP' : 'BROWSER WEB CLIENT'}
              </span>
            </div>

            {/* Navigation Tabs */}
            <div className="flex border-b border-cyan-500/30 gap-1 overflow-x-auto pb-1 text-xs font-orbitron">
              <button
                onClick={() => {
                  soundEffects.playChirp();
                  setActiveTab('instant');
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-t-lg transition-all border-b-2 whitespace-nowrap ${
                  activeTab === 'instant'
                    ? 'border-cyan-400 bg-cyan-950/80 text-white font-bold'
                    : 'border-transparent text-cyan-400/70 hover:text-cyan-200'
                }`}
              >
                <Download className="w-3.5 h-3.5 text-cyan-300" />
                <span>1. INSTANT INSTALL (PWA)</span>
              </button>

              <button
                onClick={() => {
                  soundEffects.playChirp();
                  setActiveTab('google_play');
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-t-lg transition-all border-b-2 whitespace-nowrap ${
                  activeTab === 'google_play'
                    ? 'border-cyan-400 bg-cyan-950/80 text-white font-bold'
                    : 'border-transparent text-cyan-400/70 hover:text-cyan-200'
                }`}
              >
                <Play className="w-3.5 h-3.5 text-emerald-400" />
                <span>2. GOOGLE PLAY STORE</span>
              </button>

              <button
                onClick={() => {
                  soundEffects.playChirp();
                  setActiveTab('apple_store');
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-t-lg transition-all border-b-2 whitespace-nowrap ${
                  activeTab === 'apple_store'
                    ? 'border-cyan-400 bg-cyan-950/80 text-white font-bold'
                    : 'border-transparent text-cyan-400/70 hover:text-cyan-200'
                }`}
              >
                <Apple className="w-3.5 h-3.5 text-sky-300" />
                <span>3. APPLE APP STORE</span>
              </button>

              <button
                onClick={() => {
                  soundEffects.playChirp();
                  setActiveTab('package');
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-t-lg transition-all border-b-2 whitespace-nowrap ${
                  activeTab === 'package'
                    ? 'border-cyan-400 bg-cyan-950/80 text-white font-bold'
                    : 'border-transparent text-cyan-400/70 hover:text-cyan-200'
                }`}
              >
                <FileCode className="w-3.5 h-3.5 text-amber-300" />
                <span>4. EXPORT PACKAGES</span>
              </button>
            </div>

            {/* Tab Contents */}
            <div className="py-4 space-y-4 font-mono-tech text-xs">
              {/* TAB 1: INSTANT ONE-CLICK APP INSTALL (PWA / WebAPK) */}
              {activeTab === 'instant' && (
                <div className="space-y-3.5">
                  <div className="p-4 bg-cyan-950/30 border border-cyan-500/30 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-orbitron font-semibold text-sm text-white flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-cyan-400" />
                        Direct Device Download & Installation
                      </h4>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/50 text-emerald-300">
                        OFFICIAL WEB STANDARDS
                      </span>
                    </div>

                    <p className="text-[11px] text-cyan-200/90 leading-relaxed">
                      J.A.R.V.I.S. is built with modern Progressive Web App (PWA) architecture. You can install it
                      directly onto your device’s home screen or desktop with a dedicated app icon, zero URL bars,
                      native push permissions, speech recognition, and full offline caching.
                    </p>

                    {/* Conditional Install Action */}
                    {isInstallable ? (
                      <div className="pt-2">
                        <button
                          onClick={async () => {
                            soundEffects.playChirp();
                            const success = await install();
                            if (success) setShowModal(false);
                          }}
                          className="w-full py-2.5 px-4 bg-gradient-to-r from-cyan-600 to-sky-500 hover:from-cyan-500 hover:to-sky-400 text-white font-orbitron font-bold text-xs rounded-xl shadow-[0_0_20px_#06b6d4] transition flex items-center justify-center gap-2"
                        >
                          <Download className="w-4 h-4" />
                          <span>INSTALL J.A.R.V.I.S. AS NATIVE APP NOW</span>
                        </button>
                        <p className="text-center text-[10px] text-neutral-400 mt-2">
                          Creates a standalone desktop or mobile application directly in your app launcher.
                        </p>
                      </div>
                    ) : isIOS ? (
                      /* iPhone / iPad Step-by-Step Guide */
                      <div className="space-y-3 bg-black/60 border border-cyan-500/30 rounded-lg p-3">
                        <p className="font-orbitron text-xs text-amber-300 font-semibold flex items-center gap-1.5">
                          <Apple className="w-4 h-4 text-amber-300" />
                          iPhone & iPad (Safari) Installation Steps:
                        </p>
                        <ol className="space-y-2 text-[11px] text-cyan-200">
                          <li className="flex items-start gap-2.5">
                            <span className="w-5 h-5 rounded-full bg-cyan-900/80 border border-cyan-400 flex items-center justify-center text-[10px] font-orbitron shrink-0 text-white">1</span>
                            <span>
                              Open this app in <strong className="text-white">Safari</strong> on your iPhone or iPad. Tap the <strong className="text-white">Share</strong> button <Share className="w-3.5 h-3.5 inline text-cyan-300 -mt-0.5 mx-0.5" /> in the toolbar.
                            </span>
                          </li>
                          <li className="flex items-start gap-2.5">
                            <span className="w-5 h-5 rounded-full bg-cyan-900/80 border border-cyan-400 flex items-center justify-center text-[10px] font-orbitron shrink-0 text-white">2</span>
                            <span>
                              Scroll down the share sheet and tap <strong className="text-white">"Add to Home Screen"</strong> <PlusSquare className="w-3.5 h-3.5 inline text-cyan-300 -mt-0.5 mx-0.5" />.
                            </span>
                          </li>
                          <li className="flex items-start gap-2.5">
                            <span className="w-5 h-5 rounded-full bg-cyan-900/80 border border-cyan-400 flex items-center justify-center text-[10px] font-orbitron shrink-0 text-white">3</span>
                            <span>
                              Tap <strong className="text-white">"Add"</strong> in the top-right corner. J.A.R.V.I.S. will install as a native iOS app icon with standalone fullscreen display!
                            </span>
                          </li>
                        </ol>
                      </div>
                    ) : (
                      /* Android or Desktop browser instructions */
                      <div className="space-y-2.5 bg-black/60 border border-cyan-500/30 rounded-lg p-3">
                        <p className="font-orbitron text-xs text-cyan-300 font-semibold flex items-center gap-1.5">
                          <Laptop className="w-4 h-4 text-cyan-300" />
                          Desktop & Android Browser Install:
                        </p>
                        <ul className="space-y-1.5 text-[11px] text-cyan-200">
                          <li>• In <strong className="text-white">Google Chrome</strong> or <strong className="text-white">Microsoft Edge</strong>: Click the install icon in the address bar (or menu <strong className="text-white">⋮ &gt; Install J.A.R.V.I.S.</strong>).</li>
                          <li>• On <strong className="text-white">Android</strong>: Tap menu <strong className="text-white">⋮ &gt; Add to Home screen / Install app</strong> to install the signed WebAPK package.</li>
                          <li>• Launches with hardware-accelerated 60 FPS graphics and instant microphone bridge.</li>
                        </ul>
                      </div>
                    )}
                  </div>

                  {/* Highlights Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px]">
                    <div className="p-2.5 bg-black/60 border border-cyan-500/20 rounded-lg flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>Zero App Store Fees or Ads</span>
                    </div>
                    <div className="p-2.5 bg-black/60 border border-cyan-500/20 rounded-lg flex items-center gap-2">
                      <Layers className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>Instant Automatic Updates</span>
                    </div>
                    <div className="p-2.5 bg-black/60 border border-cyan-500/20 rounded-lg flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
                      <span>Offline Service Worker Active</span>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: GOOGLE PLAY STORE (ANDROID TWA) */}
              {activeTab === 'google_play' && (
                <div className="space-y-3.5">
                  <div className="p-4 bg-cyan-950/30 border border-cyan-500/30 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-orbitron font-semibold text-sm text-white flex items-center gap-2">
                        <Play className="w-4 h-4 text-emerald-400 fill-emerald-400" />
                        Google Play Store Publishing (Trusted Web Activity)
                      </h4>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-400/40 text-cyan-300">
                        ANDROID .AAB READY
                      </span>
                    </div>

                    <p className="text-[11px] text-cyan-200/90 leading-relaxed">
                      Google officially supports publishing web applications to the Google Play Store using
                      <strong> Trusted Web Activities (TWA)</strong>. Because this app includes a compliant Web App
                      Manifest, high-res maskable icons, and a registered Service Worker, it passes Google Play
                      Store requirements.
                    </p>

                    {/* Step-by-step TWA generation */}
                    <div className="space-y-2 bg-black/60 border border-cyan-500/30 rounded-lg p-3">
                      <p className="font-orbitron text-xs text-white font-semibold">
                        How to Generate an Android Play Store Package (.aab):
                      </p>
                      <ol className="space-y-2 text-[11px] text-cyan-200">
                        <li className="flex items-start gap-2">
                          <span className="w-5 h-5 rounded-full bg-emerald-950 border border-emerald-400 text-emerald-300 flex items-center justify-center text-[10px] font-orbitron shrink-0">1</span>
                          <span>
                            Open <strong className="text-white">PWABuilder</strong> (Microsoft & Google’s open-source PWA-to-Store generator) with your app’s URL.
                          </span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="w-5 h-5 rounded-full bg-emerald-950 border border-emerald-400 text-emerald-300 flex items-center justify-center text-[10px] font-orbitron shrink-0">2</span>
                          <span>
                            Click <strong className="text-white">"Package for Android"</strong>. It will compile your manifest and icons into a signed <code className="text-cyan-300 bg-black/60 px-1 py-0.5 rounded">.aab</code> (Android App Bundle).
                          </span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="w-5 h-5 rounded-full bg-emerald-950 border border-emerald-400 text-emerald-300 flex items-center justify-center text-[10px] font-orbitron shrink-0">3</span>
                          <span>
                            Upload the generated <code className="text-cyan-300 bg-black/60 px-1 py-0.5 rounded">.aab</code> to the <strong className="text-white">Google Play Console</strong>. Digital Asset Links (<code className="text-cyan-300">/.well-known/assetlinks.json</code>) are pre-configured in this app!
                          </span>
                        </li>
                      </ol>
                    </div>

                    {/* Action buttons */}
                    <div className="flex flex-wrap gap-2 pt-1">
                      <a
                        href={pwabuilderUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="flex-1 py-2 px-3 bg-emerald-700/80 hover:bg-emerald-600 border border-emerald-400 text-white font-orbitron font-semibold text-xs rounded-lg transition flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(16,185,129,0.3)]"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>OPEN PWABUILDER (PACKAGE FOR PLAY STORE)</span>
                      </a>

                      <button
                        onClick={handleDownloadAssetlinks}
                        className="py-2 px-3 bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-300 font-orbitron text-xs rounded-lg transition flex items-center gap-1.5"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>DOWNLOAD ASSETLINKS.JSON</span>
                      </button>
                    </div>

                    {/* Metadata summary */}
                    <div className="p-2.5 bg-black/60 border border-cyan-500/20 rounded-lg text-[10px] space-y-1">
                      <div className="flex justify-between">
                        <span className="text-neutral-400">PACKAGE ID:</span>
                        <span className="text-cyan-300 font-mono-tech">com.stark.jarvis.hud</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-400">DIGITAL ASSET LINKS:</span>
                        <span className="text-cyan-300 font-mono-tech">/.well-known/assetlinks.json (CONFIGURED)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-400">GOOGLE PLAY TARGET:</span>
                        <span className="text-emerald-400 font-mono-tech">TWA (Trusted Web Activity) 100% Passed</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: APPLE APP STORE (iOS) */}
              {activeTab === 'apple_store' && (
                <div className="space-y-3.5">
                  <div className="p-4 bg-cyan-950/30 border border-cyan-500/30 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-orbitron font-semibold text-sm text-white flex items-center gap-2">
                        <Apple className="w-4 h-4 text-sky-300" />
                        Apple App Store Publishing (iOS / iPadOS / macOS)
                      </h4>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-400/40 text-cyan-300">
                        XCODE / CAPACITOR
                      </span>
                    </div>

                    <p className="text-[11px] text-cyan-200/90 leading-relaxed">
                      To publish this app onto the official <strong>Apple App Store</strong>, wrap the Vite React application
                      using <strong>Capacitor</strong> or <strong>PWABuilder iOS</strong> into an Xcode Swift project,
                      then submit via App Store Connect.
                    </p>

                    {/* Capacitor CLI commands */}
                    <div className="space-y-2 bg-black/60 border border-cyan-500/30 rounded-lg p-3">
                      <div className="flex items-center justify-between">
                        <p className="font-orbitron text-xs text-white font-semibold">
                          Quick Setup with Capacitor (Xcode App Store Build):
                        </p>
                        <button
                          onClick={() =>
                            handleCopy(
                              'npm install @capacitor/core @capacitor/cli @capacitor/ios\nnpx cap init "JARVIS AI MOD" com.stark.jarvis.hud\nnpx cap add ios\nnpx cap open ios',
                              'cap_code'
                            )
                          }
                          className="text-[10px] text-cyan-400 hover:text-white flex items-center gap-1"
                        >
                          {copiedText === 'cap_code' ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span className="text-emerald-300">COPIED</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>COPY CLI</span>
                            </>
                          )}
                        </button>
                      </div>

                      <pre className="p-2.5 bg-black/60 rounded border border-cyan-500/20 text-[10.5px] text-cyan-300 overflow-x-auto font-mono-tech">
                        {`npm install @capacitor/core @capacitor/cli @capacitor/ios
npx cap init "JARVIS AI MOD" com.stark.jarvis.hud
npx cap add ios
npx cap open ios`}
                      </pre>
                      <p className="text-[10px] text-neutral-400">
                        Running <code className="text-cyan-300">npx cap open ios</code> opens the project in Xcode, ready to archive, sign with your Apple Developer account, and submit to App Store Connect / TestFlight.
                      </p>
                    </div>

                    {/* Method 2: PWABuilder iOS */}
                    <div className="flex flex-wrap gap-2 pt-1">
                      <a
                        href={pwabuilderUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="flex-1 py-2 px-3 bg-sky-800/80 hover:bg-sky-700 border border-sky-400 text-white font-orbitron font-semibold text-xs rounded-lg transition flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(56,189,248,0.3)]"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>GENERATE IOS XCODE PACKAGE (PWABUILDER)</span>
                      </a>
                    </div>

                    {/* Apple Web App Note */}
                    <div className="p-2.5 bg-cyan-950/40 border border-cyan-500/20 rounded-lg text-[10px] text-cyan-300/90 flex items-start gap-2">
                      <Sparkles className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <span>
                        <strong>No Developer Account?</strong> You can also install J.A.R.V.I.S. on iPhone right now via
                        Safari's <em>"Add to Home Screen"</em> (see Tab 1). iOS 16.4+ renders PWAs with full native capabilities,
                        zero $99/year developer fee, and instant cloud updates.
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: EXPORT PACKAGES & MANIFEST */}
              {activeTab === 'package' && (
                <div className="space-y-3.5">
                  <div className="p-4 bg-cyan-950/30 border border-cyan-500/30 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-orbitron font-semibold text-sm text-white flex items-center gap-2">
                        <FileCode className="w-4 h-4 text-amber-300" />
                        App Store Metadata & Manifest Export
                      </h4>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-400/40 text-cyan-300">
                        JSON CONFIGURATION
                      </span>
                    </div>

                    <p className="text-[11px] text-cyan-200/90 leading-relaxed">
                      Download pre-formatted store metadata, Digital Asset Links, and the Web App Manifest to easily copy
                      store descriptions, icon dimensions, category tags, and bundle IDs into the Google Play Console
                      or Apple App Store Connect.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                      <button
                        onClick={handleDownloadManifest}
                        className="py-2.5 px-3 bg-cyan-900/60 hover:bg-cyan-800/80 border border-cyan-400 text-white font-orbitron font-semibold text-xs rounded-xl transition flex items-center justify-center gap-2 glow-box-cyan"
                      >
                        <Download className="w-3.5 h-3.5 text-cyan-300" />
                        <span>DOWNLOAD STORE METADATA (.JSON)</span>
                      </button>

                      <button
                        onClick={handleDownloadAssetlinks}
                        className="py-2.5 px-3 bg-cyan-900/60 hover:bg-cyan-800/80 border border-cyan-400 text-white font-orbitron font-semibold text-xs rounded-xl transition flex items-center justify-center gap-2 glow-box-cyan"
                      >
                        <Download className="w-3.5 h-3.5 text-cyan-300" />
                        <span>DOWNLOAD ASSETLINKS.JSON</span>
                      </button>
                    </div>

                    {/* Pre-configured store sheet summary */}
                    <div className="p-3 bg-black/60 border border-cyan-500/30 rounded-lg space-y-1.5 text-[10.5px]">
                      <div className="flex justify-between border-b border-cyan-500/20 pb-1">
                        <span className="text-neutral-400">APPLICATION NAME:</span>
                        <span className="text-white font-orbitron">JARVIS AI MOD</span>
                      </div>
                      <div className="flex justify-between border-b border-cyan-500/20 pb-1">
                        <span className="text-neutral-400">BUNDLE / PACKAGE ID:</span>
                        <span className="text-cyan-300 font-mono-tech">com.stark.jarvis.hud</span>
                      </div>
                      <div className="flex justify-between border-b border-cyan-500/20 pb-1">
                        <span className="text-neutral-400">PRIMARY CATEGORY:</span>
                        <span className="text-cyan-300">Utilities / Productivity</span>
                      </div>
                      <div className="flex justify-between border-b border-cyan-500/20 pb-1">
                        <span className="text-neutral-400">ICONS INCLUDED:</span>
                        <span className="text-cyan-300">180px Apple, 192px, 512px, 512px Maskable</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-400">STATUS:</span>
                        <span className="text-emerald-400 font-bold">100% STORE COMPLIANT</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="pt-3 border-t border-cyan-500/30 flex items-center justify-between">
              <span className="text-[10px] text-neutral-400 font-mono-tech hidden sm:inline">
                STARK INDUSTRIES ADVANCED TELEMETRY // PWA BUILD 2026
              </span>
              <button
                onClick={() => {
                  soundEffects.playChirp();
                  setShowModal(false);
                }}
                className="px-5 py-1.5 rounded-lg bg-cyan-950 border border-cyan-500/50 text-cyan-300 hover:bg-cyan-900 text-xs font-orbitron transition ml-auto"
              >
                CLOSE CONSOLE
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
