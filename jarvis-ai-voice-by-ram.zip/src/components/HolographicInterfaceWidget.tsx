import React, { useState, useEffect, useRef } from 'react';
import { HologramCore } from './HologramCore';
import { Mic, MicOff, Settings, Maximize, Video, Scan, Info, Cpu, Wifi, Layers, X } from 'lucide-react';
import { JarvisWaveform } from './JarvisWaveform';

interface Props {
  coreState: string;
  isListening: boolean;
  isSpeaking: boolean;
  transcript: string;
  onToggleListen: () => void;
  onOpenSettings: () => void;
}

export const HolographicInterfaceWidget: React.FC<Props> = ({
  coreState,
  isListening,
  isSpeaking,
  transcript,
  onToggleListen,
  onOpenSettings
}) => {
  const [arMode, setArMode] = useState(false);
  const [projectionMode, setProjectionMode] = useState(false);
  const [pyramidMode, setPyramidMode] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);

  // Toggle Fullscreen for Projection Mode
    const toggleProjectionMode = () => {
    if (!document.fullscreenElement) {
      // Always set the UI state
      setProjectionMode(true);
      
      // Attempt fullscreen, but don't require it
      document.documentElement.requestFullscreen().catch(err => {
        console.warn("Fullscreen API not available or blocked (requires user gesture). Continuing in windowed mode.");
      });
    } else {
      document.exitFullscreen().catch(err => {});
      setProjectionMode(false);
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setProjectionMode(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  
  useEffect(() => {
    const handleProjectionMode = () => {
      toggleProjectionMode();
    };
    
    const handleCalibrate = () => {
      setPyramidMode(true);
    };

    window.addEventListener('jarvis-projection-mode', handleProjectionMode);
    window.addEventListener('jarvis-calibrate-display', handleCalibrate);

    return () => {
      window.removeEventListener('jarvis-projection-mode', handleProjectionMode);
      window.removeEventListener('jarvis-calibrate-display', handleCalibrate);
    };
  }, [toggleProjectionMode]);


  // Handle AR Mode Camera
  useEffect(() => {
    if (arMode) {
      navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
        .then(newStream => {
          setStream(newStream);
          if (videoRef.current) {
            videoRef.current.srcObject = newStream;
          }
        })
        .catch(err => {
          console.error("Camera access denied or unavailable", err);
          setArMode(false);
        });
    } else {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
        setStream(null);
      }
    }
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [arMode]);

  const primaryColor = coreState === 'LISTENING' ? 'text-emerald-400 border-emerald-500' : coreState === 'ERROR' ? 'text-red-500 border-red-500' : 'text-cyan-400 border-cyan-500';
  const shadowColor = coreState === 'LISTENING' ? 'rgba(52,211,153,0.5)' : coreState === 'ERROR' ? 'rgba(239,68,68,0.5)' : 'rgba(6,182,212,0.5)';

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center relative overflow-hidden font-sans text-neutral-100 ${projectionMode ? 'bg-black' : 'bg-neutral-950'}`}>
      
      
      {/* Pyramid Projection Mode */}
      {pyramidMode && (
        <div className="absolute inset-0 bg-black z-[100] flex items-center justify-center overflow-hidden pointer-events-auto">
           <button onClick={() => setPyramidMode(false)} className="absolute top-8 right-8 z-[110] p-4 rounded-full bg-neutral-900/50 text-neutral-500 hover:text-cyan-400 transition-colors">
             <X className="w-8 h-8" />
           </button>
           
           <div className="relative w-[min(100vw,100vh)] h-[min(100vw,100vh)] scale-[0.85]">
              {/* Top (Rotated 180) */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[40%] h-[40%] rotate-180 origin-center">
                <HologramCore coreState={coreState} isSpeaking={isSpeaking} />
              </div>
              {/* Bottom (Rotated 0) */}
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[40%] h-[40%]">
                <HologramCore coreState={coreState} isSpeaking={isSpeaking} />
              </div>
              {/* Left (Rotated 90) */}
              <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[40%] h-[40%] rotate-90 origin-center">
                <HologramCore coreState={coreState} isSpeaking={isSpeaking} />
              </div>
              {/* Right (Rotated -90) */}
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-[40%] h-[40%] -rotate-90 origin-center">
                <HologramCore coreState={coreState} isSpeaking={isSpeaking} />
              </div>
              
              {/* Center deadzone */}
              <div className="absolute inset-0 m-auto w-[20%] h-[20%] border border-cyan-500/20 rounded-sm bg-cyan-950/10 pointer-events-none flex items-center justify-center">
                 <div className="w-1 h-1 bg-cyan-500 rounded-full animate-pulse" />
              </div>
           </div>
        </div>
      )}

      {/* AR Background Video */}
      {arMode && (
        <video 
          ref={videoRef} 
          autoPlay 
          playsInline 
          muted 
          className="absolute inset-0 w-full h-full object-cover z-0 opacity-40 mix-blend-screen"
        />
      )}

      {/* Grid Background (Hidden in Projection Mode) */}
      {!projectionMode && !arMode && (
        <div className="absolute inset-0 z-0 opacity-10" style={{
          backgroundImage: `linear-gradient(rgba(6,182,212,0.2) 1px, transparent 1px), linear-gradient(90deg, rgba(6,182,212,0.2) 1px, transparent 1px)`,
          backgroundSize: '40px 40px',
          backgroundPosition: 'center center'
        }} />
      )}

      {/* Main 3D Hologram Canvas */}
      <div className="absolute inset-0 z-10 flex items-center justify-center pointer-events-auto">
         <div className={`w-full h-full max-w-6xl max-h-[80vh] transition-all duration-1000 ${projectionMode ? 'scale-125' : 'scale-100'}`}>
            <HologramCore coreState={coreState} isSpeaking={isSpeaking} />
         </div>
      </div>

      {/* 2D Holographic Overlays - Hidden in strict Projection Mode if desired, but we'll keep minimal UI for effect */}
      <div className={`absolute inset-0 z-20 pointer-events-none p-6 flex flex-col justify-between transition-opacity duration-500 ${projectionMode ? 'opacity-50' : 'opacity-100'}`}>
        
        {/* Top HUD */}
        <div className="flex justify-between items-start w-full">
           <div className="flex flex-col gap-2">
              <div className={`text-3xl font-bold tracking-[0.5em] uppercase ${primaryColor} drop-shadow-[0_0_15px_${shadowColor}]`}>
                 JARVIS
              </div>
              <div className="text-xs font-mono tracking-widest text-cyan-500/70 uppercase">
                 Volumetric Spatial Engine v4.2
              </div>
           </div>

           {!projectionMode && (
             <div className="flex gap-4 pointer-events-auto">
               <button onClick={() => setArMode(!arMode)} className={`p-2 rounded-full border transition-all ${arMode ? 'bg-cyan-500/20 border-cyan-500 text-cyan-400' : 'bg-neutral-900/50 border-neutral-800 text-neutral-500 hover:text-cyan-400'}`} title="AR Camera Mode">
                 <Video className="w-5 h-5" />
               </button>
               <button onClick={() => setPyramidMode(!pyramidMode)} className={`p-2 rounded-full border transition-all ${pyramidMode ? 'bg-cyan-500/20 border-cyan-500 text-cyan-400' : 'bg-neutral-900/50 border-neutral-800 text-neutral-500 hover:text-cyan-400'}`} title="Pyramid Projection Mode">
                 <Layers className="w-5 h-5" />
               </button>
               <button onClick={toggleProjectionMode} className="p-2 rounded-full bg-neutral-900/50 border border-neutral-800 text-neutral-500 hover:text-cyan-400 transition-all" title="Projection Mode">
                 <Maximize className="w-5 h-5" />
               </button>
               <button onClick={onOpenSettings} className="p-2 rounded-full bg-neutral-900/50 border border-neutral-800 text-neutral-500 hover:text-cyan-400 transition-all">
                 <Settings className="w-5 h-5" />
               </button>
             </div>
           )}
        </div>

        {/* Side Panels (Hidden in projection to keep it clean) */}
        {!projectionMode && (
          <div className="flex justify-between w-full flex-1 items-center px-4">
             {/* Left floating panel */}
             <div className="w-64 bg-cyan-950/20 backdrop-blur-sm border border-cyan-500/20 rounded-lg p-4 flex flex-col gap-4">
                <div className="text-xs font-bold tracking-widest text-cyan-400 border-b border-cyan-500/30 pb-2 flex items-center gap-2 uppercase">
                   <Cpu className="w-4 h-4" /> System Core
                </div>
                <div className="space-y-3 font-mono text-[10px] text-cyan-300">
                   <div className="flex justify-between"><span>CPU Threads</span> <span>8 Active</span></div>
                   <div className="flex justify-between"><span>Memory</span> <span>16.4 GB allocated</span></div>
                   <div className="flex justify-between"><span>Neural Net</span> <span>Online</span></div>
                   <div className="flex justify-between"><span>Render Engine</span> <span>WebGL</span></div>
                </div>
             </div>

             {/* Right floating panel */}
             <div className="w-64 bg-cyan-950/20 backdrop-blur-sm border border-cyan-500/20 rounded-lg p-4 flex flex-col gap-4">
                <div className="text-xs font-bold tracking-widest text-cyan-400 border-b border-cyan-500/30 pb-2 flex items-center gap-2 uppercase">
                   <Wifi className="w-4 h-4" /> Telemetry
                </div>
                <div className="space-y-3 font-mono text-[10px] text-cyan-300">
                   <div className="flex justify-between"><span>Latency</span> <span>12ms</span></div>
                   <div className="flex justify-between"><span>Packet Loss</span> <span>0.0%</span></div>
                   <div className="flex justify-between"><span>Uplink</span> <span>Encrypted</span></div>
                   <div className="flex justify-between text-emerald-400"><span>Status</span> <span>Nominal</span></div>
                </div>
             </div>
          </div>
        )}

        {/* Bottom Area (Transcript and Audio) */}
        <div className="flex flex-col items-center w-full pb-8">
           <div className="w-full max-w-2xl h-16 mix-blend-screen mb-4">
              <JarvisWaveform
                 isActive={isListening || isSpeaking || coreState === 'THINKING'}
                 isListening={isListening}
                 isSpeaking={isSpeaking}
              />
           </div>
           
           <div className="h-12 flex items-center justify-center">
              {transcript ? (
                 <div className={`text-sm ${primaryColor} max-w-xl text-center font-mono italic px-4 py-2 bg-cyan-950/40 rounded-full border border-cyan-500/20 backdrop-blur-md`}>
                    &gt; {transcript}
                 </div>
              ) : (
                 <div className="text-sm text-cyan-700/50 max-w-md text-center font-mono">
                    &gt; Awaiting Voice Input
                 </div>
              )}
           </div>

           {!projectionMode && (
             <div className="pointer-events-auto mt-6">
                <button
                  onClick={onToggleListen}
                  className={`p-4 rounded-full border transition-all ${
                    isListening 
                      ? 'bg-cyan-500/20 border-cyan-500 text-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.3)]' 
                      : 'bg-neutral-900/80 border-neutral-800 text-neutral-500 hover:text-cyan-400'
                  }`}
                >
                  {isListening ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
                </button>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};
