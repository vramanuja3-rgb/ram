import React from 'react';
import { AICoreState } from '../types';

interface AICoreProps {
  state: AICoreState;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const AICore: React.FC<AICoreProps> = ({ state, size = 'md' }) => {
  const sizeMap = {
    sm: 'w-16 h-16',
    md: 'w-32 h-32',
    lg: 'w-48 h-48',
    xl: 'w-64 h-64'
  };

  const ringSizes = {
    sm: 'w-24 h-24',
    md: 'w-48 h-48',
    lg: 'w-64 h-64',
    xl: 'w-96 h-96'
  };

  let coreColor = 'bg-cyan-500';
  let glowColor = 'shadow-cyan-500/50';
  let pulseAnim = 'animate-pulse';
  let ringAnim = 'animate-[spin_10s_linear_infinite]';

  switch (state) {
    case 'LISTENING':
      coreColor = 'bg-cyan-400';
      glowColor = 'shadow-cyan-400/80';
      pulseAnim = 'animate-[ping_1.5s_cubic-bezier(0,0,0.2,1)_infinite]';
      ringAnim = 'animate-[spin_4s_linear_infinite]';
      break;
    case 'THINKING':
      coreColor = 'bg-purple-500';
      glowColor = 'shadow-purple-500/60';
      pulseAnim = 'animate-pulse';
      ringAnim = 'animate-[spin_2s_linear_infinite]';
      break;
    case 'SPEAKING':
      coreColor = 'bg-cyan-300';
      glowColor = 'shadow-cyan-300/80';
      pulseAnim = 'animate-[pulse_0.5s_ease-in-out_infinite]';
      ringAnim = 'animate-[spin_6s_linear_infinite]';
      break;
    case 'ERROR':
      coreColor = 'bg-red-500';
      glowColor = 'shadow-red-500/80';
      pulseAnim = 'animate-pulse';
      ringAnim = 'animate-none';
      break;
    case 'IDLE':
    default:
      coreColor = 'bg-cyan-600';
      glowColor = 'shadow-cyan-600/40';
      pulseAnim = 'animate-[pulse_3s_ease-in-out_infinite]';
      ringAnim = 'animate-[spin_12s_linear_infinite]';
      break;
  }

  return (
    <div className="relative flex items-center justify-center">
      {/* Outer rotating ring */}
      <div className={`absolute ${ringSizes[size]} rounded-full border border-dashed border-cyan-500/30 ${ringAnim}`} />
      
      {/* Middle rotating ring (reverse) */}
      <div className={`absolute ${ringSizes[size]} scale-75 rounded-full border-2 border-transparent border-t-cyan-500/50 border-b-cyan-500/50 animate-[spin_8s_linear_infinite_reverse]`} />
      
      {/* Inner Core */}
      <div className={`relative ${sizeMap[size]} rounded-full ${coreColor} opacity-20 blur-xl ${pulseAnim}`} />
      <div className={`absolute ${sizeMap[size]} rounded-full border border-white/20 bg-gradient-to-tr from-black/80 to-transparent flex items-center justify-center overflow-hidden backdrop-blur-sm shadow-[0_0_30px_rgba(0,0,0,0.5)] ${glowColor}`}>
        <div className={`w-1/2 h-1/2 rounded-full ${coreColor} ${pulseAnim} blur-sm`} />
      </div>

      {state === 'SPEAKING' && (
        <div className={`absolute ${sizeMap[size]} scale-150 rounded-full border border-cyan-400/40 animate-[ping_1s_cubic-bezier(0,0,0.2,1)_infinite]`} />
      )}
    </div>
  );
};
