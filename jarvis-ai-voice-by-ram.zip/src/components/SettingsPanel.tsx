import React from 'react';
import { X, Mic, Home, Save } from 'lucide-react';
import { AppSettings } from '../types';

interface SettingsPanelProps {
  settings: AppSettings;
  onUpdateSettings: (s: AppSettings) => void;
  onClose: () => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({ settings, onUpdateSettings, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[85vh]">
        
        <div className="flex justify-between items-center p-6 border-b border-neutral-800">
          <h2 className="text-xl font-semibold text-neutral-100 tracking-wide">System Configuration</h2>
          <button onClick={onClose} className="p-2 text-neutral-400 hover:text-white rounded-full hover:bg-neutral-800 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          
          {/* Voice Engine */}
          <section>
            <h3 className="text-sm font-medium text-neutral-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Mic className="w-4 h-4" /> Voice Engine
            </h3>
            <div className="space-y-4">
              <label className="flex items-center justify-between p-4 bg-neutral-950 rounded-xl border border-neutral-800/50">
                <div>
                  <div className="text-neutral-200 font-medium">Wake Word Detection</div>
                  <div className="text-sm text-neutral-500">Continuously listen for "Jarvis"</div>
                </div>
                <input 
                  type="checkbox" 
                  checked={settings.wakeWordEnabled} 
                  onChange={(e) => onUpdateSettings({ ...settings, wakeWordEnabled: e.target.checked })}
                  className="w-5 h-5 accent-cyan-500 rounded bg-neutral-800 border-none"
                />
              </label>

              <label className="flex items-center justify-between p-4 bg-neutral-950 rounded-xl border border-neutral-800/50">
                <div>
                  <div className="text-neutral-200 font-medium">Voice Output</div>
                  <div className="text-sm text-neutral-500">Enable natural speech synthesis</div>
                </div>
                <input 
                  type="checkbox" 
                  checked={settings.voiceEnabled} 
                  onChange={(e) => onUpdateSettings({ ...settings, voiceEnabled: e.target.checked })}
                  className="w-5 h-5 accent-cyan-500 rounded bg-neutral-800 border-none"
                />
              </label>
            </div>
          </section>

          {/* Smart Home */}
          <section>
            <h3 className="text-sm font-medium text-neutral-400 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Home className="w-4 h-4" /> Smart Home Connections
            </h3>
            
            <div className="flex justify-between items-center p-4 bg-red-950/30 border border-red-900/50 rounded-xl mb-4">
              <div>
                <div className="text-red-400 font-bold tracking-widest uppercase">EMERGENCY STOP</div>
                <div className="text-xs text-red-400/70">Instantly disable all device control actions</div>
              </div>
              <button 
                onClick={() => alert("EMERGENCY STOP ENGAGED. All smart home endpoints have been severed.")}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg uppercase tracking-widest text-sm shadow-[0_0_15px_rgba(220,38,38,0.5)] transition-all"
              >
                ENGAGE
              </button>
            </div>
            <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-800/50">
              <div className="text-neutral-200 font-medium mb-1">Local Network Provider</div>
              <div className="text-sm text-green-500 mb-4 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                Connected (Simulated Native Core)
              </div>
              <p className="text-xs text-neutral-500 leading-relaxed">
                Currently running in sandbox mode. Smart home integrations (Matter, Home Assistant) are mocked via the simulated control layer. No external API keys are required for this prototype.
              </p>
            </div>
          </section>

        </div>
        
        <div className="p-6 border-t border-neutral-800 bg-neutral-900/50 flex justify-end">
          <button 
            onClick={onClose}
            className="flex items-center gap-2 px-6 py-2.5 bg-neutral-100 hover:bg-white text-neutral-900 rounded-lg font-medium transition-colors"
          >
            <Save className="w-4 h-4" /> Save & Close
          </button>
        </div>

      </div>
    </div>
  );
};
