import React from 'react';
import { AppStoreModal } from './AppStoreModal';

export const PWAInstallModal: React.FC = () => {
  return <AppStoreModal />;
};

export { AppStoreModal };
