import React, { useState, useEffect } from 'react';
import { MapPin, Wind, Thermometer, Crosshair, Globe } from 'lucide-react';

export const GeoLocationHUDWidget: React.FC = () => {
  const [location, setLocation] = useState<{lat: number, lon: number} | null>(null);
  const [weather, setWeather] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          setLocation({ lat: latitude, lon: longitude });
          
          try {
            // Fetch weather using free Open-Meteo API
            const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true`);
            const data = await res.json();
            if (data.current_weather) {
              setWeather(data.current_weather);
            }
          } catch (err) {
            console.error("Weather fetch failed", err);
          }
          setLoading(false);
        },
        (err) => {
          console.error(err);
          setError("GPS Signal Lost");
          setLoading(false);
        }
      );
    } else {
      setError("GPS Module Offline");
      setLoading(false);
    }
  }, []);

  return (
    <div className="absolute top-24 left-6 z-40 w-64 pointer-events-none select-none">
      <div className="relative p-4 rounded-lg bg-black/40 backdrop-blur-md border border-cyan-500/30 shadow-[0_0_15px_rgba(6,182,212,0.15)] overflow-hidden font-mono">
        {/* Holographic Scanlines */}
        <div className="absolute inset-0 bg-[linear-gradient(transparent_50%,rgba(6,182,212,0.05)_50%)] bg-[length:100%_4px] pointer-events-none opacity-50 mix-blend-screen" />
        
        {/* Header */}
        <div className="flex justify-between items-center border-b border-cyan-500/30 pb-2 mb-3 text-cyan-400">
          <span className="text-[10px] tracking-widest uppercase font-bold flex items-center gap-2">
            <Globe className="w-3 h-3 animate-pulse" />
            Orbital Telemetry
          </span>
          <div className="flex items-center gap-1">
            <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${loading ? 'bg-cyan-500' : error ? 'bg-red-500' : 'bg-green-400 shadow-[0_0_8px_rgba(74,222,128,0.8)]'}`} />
            <span className="text-[8px] uppercase text-neutral-500">{loading ? 'SCAN' : error ? 'ERR' : 'SYNC'}</span>
          </div>
        </div>

        {/* Content */}
        <div className="flex flex-col gap-3">
          {loading ? (
            <div className="text-xs text-cyan-500/70 uppercase tracking-widest animate-pulse flex items-center gap-2">
              <Crosshair className="w-4 h-4 animate-spin" /> Acquiring Satellites...
            </div>
          ) : error ? (
            <div className="text-xs text-red-400 uppercase tracking-widest animate-pulse">
              {error}
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-2 text-[10px] uppercase tracking-wider text-neutral-400">
                <div className="flex flex-col bg-neutral-900/50 p-2 rounded border border-cyan-500/10 relative overflow-hidden">
                  <div className="absolute inset-0 bg-cyan-500/5" />
                  <span className="text-cyan-500/50 mb-1 z-10 flex items-center gap-1"><MapPin className="w-3 h-3" /> LAT</span>
                  <span className="text-cyan-400 font-bold z-10">{location?.lat.toFixed(4)}&deg;</span>
                </div>
                <div className="flex flex-col bg-neutral-900/50 p-2 rounded border border-cyan-500/10 relative overflow-hidden">
                  <div className="absolute inset-0 bg-cyan-500/5" />
                  <span className="text-cyan-500/50 mb-1 z-10 flex items-center gap-1"><MapPin className="w-3 h-3" /> LON</span>
                  <span className="text-cyan-400 font-bold z-10">{location?.lon.toFixed(4)}&deg;</span>
                </div>
              </div>

              {weather && (
                <div className="flex justify-between items-center bg-neutral-900/50 p-2 rounded border border-cyan-500/10 mt-1 text-xs text-neutral-300 relative overflow-hidden">
                   <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(6,182,212,0.05)_0%,transparent_100%)] pointer-events-none" />
                  <div className="flex items-center gap-2 z-10">
                    <Thermometer className="w-4 h-4 text-orange-400" />
                    <span className="font-bold text-cyan-400">{weather.temperature}&deg;C</span>
                  </div>
                  <div className="flex items-center gap-2 z-10">
                    <Wind className="w-4 h-4 text-cyan-400" />
                    <span className="font-bold text-cyan-400">{weather.windspeed} km/h</span>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
