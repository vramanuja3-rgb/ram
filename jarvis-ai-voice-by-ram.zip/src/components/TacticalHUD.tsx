import React, { useState, useEffect, useRef } from 'react';
import { AppView, AICoreState } from '../types';
import { Target, Activity, Zap, Shield, Cpu, Waves, X, Mic, Square } from 'lucide-react';
import { JarvisWaveform } from './JarvisWaveform';

interface TacticalHUDProps {
  onNavigate: (view: AppView) => void;
  coreState: AICoreState;
  isListening: boolean;
  onToggleListen: () => void;
  onStop: () => void;
  assistantName: string;
}

export const TacticalHUD: React.FC<TacticalHUDProps> = ({
  onNavigate,
  coreState,
  isListening,
  onToggleListen,
  onStop,
  assistantName
}) => {
  const [logs, setLogs] = useState<string[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Generate random logs
    const interval = setInterval(() => {
      const msgs = [
        "Scanning localized grid...",
        "Biometric sensors nominal.",
        "Rerouting power to main thrusters.",
        "Checking orbital satellite uplink.",
        "Repulsor array standing by.",
        "Threat detection active.",
        "Thermal shielding optimal.",
        "AI cognitive sub-routines engaged."
      ];
      const newMsg = `[${new Date().toISOString().substring(11, 19)}] ${msgs[Math.floor(Math.random() * msgs.length)]}`;
      setLogs(prev => [...prev.slice(-15), newMsg]);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="flex-1 flex flex-col h-full bg-black relative overflow-hidden font-rajdhani">
      {/* HUD Overlay Scanlines & Vignette */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,transparent_30%,rgba(0,0,0,0.8)_100%)] z-20" />
      <div className="absolute inset-0 pointer-events-none opacity-10 bg-[linear-gradient(rgba(0,255,255,0.1)_1px,transparent_1px)] bg-[size:100%_4px] z-20" />

      {/* Header / Exit Button */}
      <div className="absolute top-6 right-6 z-30">
        <button
          onClick={() => onNavigate('dashboard')}
          className="flex items-center gap-2 px-4 py-2 bg-cyan-950/40 border border-cyan-500/40 text-cyan-400 rounded hover:bg-cyan-900/60 transition-colors backdrop-blur uppercase tracking-widest text-xs font-bold"
        >
          <X className="w-4 h-4" /> Exit Tactical Mode
        </button>
      </div>

      <div className="absolute top-6 left-6 z-30 text-cyan-400">
        <h1 className="font-orbitron text-2xl font-bold tracking-[0.2em] uppercase glow-cyan">
          {assistantName} <span className="font-light text-cyan-600">HUD</span>
        </h1>
        <div className="text-xs font-mono tracking-widest uppercase mt-1 opacity-80">Mark LXXXV Interface</div>
      </div>

      {/* Main Grid */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 p-6 pt-24 z-10 relative max-w-7xl mx-auto w-full h-full">
        
        {/* Left Column: Diagnostics & Radar */}
        <div className="flex flex-col gap-6 h-full">
          {/* Radar */}
          <div className="h-64 border border-cyan-500/20 bg-cyan-950/10 rounded-2xl relative overflow-hidden flex items-center justify-center backdrop-blur-md">
            <div className="absolute top-3 left-3 text-xs font-mono text-cyan-500 uppercase tracking-widest flex items-center gap-2">
              <Target className="w-4 h-4" /> Sector Scan
            </div>
            
            {/* Radar Rings */}
            <div className="relative w-48 h-48 rounded-full border border-cyan-500/30 flex items-center justify-center">
              <div className="absolute w-32 h-32 rounded-full border border-cyan-500/30" />
              <div className="absolute w-16 h-16 rounded-full border border-cyan-500/30" />
              
              {/* Radar Sweep */}
              <div className="absolute top-1/2 left-1/2 w-[50%] h-0.5 bg-gradient-to-r from-cyan-400 to-transparent origin-left animate-[spin_4s_linear_infinite]" />
              
              {/* Radar Blips */}
              <div className="absolute top-10 left-10 w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)] animate-pulse" />
              <div className="absolute bottom-16 right-12 w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)] animate-pulse" />
            </div>
          </div>

          {/* System Status */}
          <div className="flex-1 border border-cyan-500/20 bg-cyan-950/10 rounded-2xl p-4 backdrop-blur-md flex flex-col">
            <div className="text-xs font-mono text-cyan-500 uppercase tracking-widest flex items-center gap-2 mb-4">
              <Activity className="w-4 h-4" /> Diagnostics
            </div>
            
            <div className="space-y-4 font-mono text-sm">
              <div>
                <div className="flex justify-between text-cyan-400 mb-1">
                  <span>Core Temp</span>
                  <span>4200 K</span>
                </div>
                <div className="h-1 bg-cyan-950 rounded-full overflow-hidden">
                  <div className="h-full bg-cyan-400 w-[65%]" />
                </div>
              </div>
              
              <div>
                <div className="flex justify-between text-cyan-400 mb-1">
                  <span>Shield Integrity</span>
                  <span>88%</span>
                </div>
                <div className="h-1 bg-cyan-950 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 w-[88%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-red-400 mb-1">
                  <span>Thruster Output</span>
                  <span>MAX</span>
                </div>
                <div className="h-1 bg-cyan-950 rounded-full overflow-hidden">
                  <div className="h-full bg-red-500 w-[95%] animate-pulse" />
                </div>
              </div>
            </div>

            <div className="mt-auto pt-4 border-t border-cyan-500/20">
              <div className="grid grid-cols-2 gap-2 text-xs font-mono text-center">
                <div className="p-2 border border-cyan-500/30 rounded bg-cyan-900/20 text-cyan-300">
                  <Zap className="w-4 h-4 mx-auto mb-1" /> ACTIVE
                </div>
                <div className="p-2 border border-cyan-500/30 rounded bg-cyan-900/20 text-cyan-300">
                  <Shield className="w-4 h-4 mx-auto mb-1" /> ARMED
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Center Column: Arc Reactor / AI Core */}
        <div className="flex flex-col h-full items-center justify-center relative border border-cyan-500/20 bg-cyan-950/5 rounded-2xl backdrop-blur-sm p-4">
          <div className="absolute top-3 left-3 text-xs font-mono text-cyan-500 uppercase tracking-widest flex items-center gap-2">
            <Cpu className="w-4 h-4" /> Reactor Core
          </div>

          {/* Central Reactor Visual */}
          <div className="relative w-64 h-64 flex items-center justify-center">
            {/* Outer Ring */}
            <div className="absolute w-full h-full rounded-full border-4 border-dashed border-cyan-500/40 animate-[spin_10s_linear_infinite]" />
            <div className="absolute w-full h-full rounded-full border-2 border-cyan-400/20" />
            
            {/* Middle Ring */}
            <div className="absolute w-48 h-48 rounded-full border-[12px] border-cyan-900/40 border-t-cyan-400/60 border-b-cyan-400/60 animate-[spin_6s_linear_infinite_reverse] shadow-[0_0_30px_rgba(6,182,212,0.3)]" />
            
            {/* Inner Ring */}
            <div className="absolute w-32 h-32 rounded-full border border-cyan-300/50 flex items-center justify-center animate-[spin_4s_linear_infinite]">
               <div className="w-24 h-24 border-2 border-dotted border-cyan-200/60 rounded-full" />
            </div>

            {/* The Core */}
            <div className={`absolute w-20 h-20 rounded-full flex items-center justify-center backdrop-blur-md shadow-[0_0_50px_rgba(34,211,238,0.8)] z-10 transition-colors duration-500
              ${coreState === 'LISTENING' ? 'bg-cyan-400/80 animate-ping' : 
                coreState === 'THINKING' ? 'bg-purple-500/80 animate-pulse' : 
                coreState === 'SPEAKING' ? 'bg-cyan-300/90' : 
                coreState === 'ERROR' ? 'bg-red-500/80 animate-pulse' : 
                'bg-cyan-500/60'}`}
            >
              <div className="w-10 h-10 bg-white rounded-full blur-[2px]" />
            </div>
          </div>
          
          <div className="mt-8 text-center uppercase tracking-[0.3em] font-orbitron font-bold text-cyan-400 text-sm">
             Status: {coreState}
          </div>

          {/* Audio Input / HUD Interaction */}
          <div className="absolute bottom-6 w-full px-8">
             <div className="h-16 border border-cyan-500/30 rounded-xl bg-black/60 backdrop-blur flex items-center justify-between px-4">
                <div className="w-1/2 h-8">
                  <JarvisWaveform isActive={isListening || coreState === 'SPEAKING'} isListening={isListening} isSpeaking={coreState === 'SPEAKING'} />
                </div>
                
                <div className="flex gap-2">
                  <button 
                    onClick={onToggleListen}
                    className={`p-3 rounded-full transition-colors ${isListening ? 'bg-red-500/20 text-red-400 border border-red-500/50 animate-pulse' : 'bg-cyan-900/40 text-cyan-400 hover:bg-cyan-800/60 border border-cyan-500/30'}`}
                  >
                    <Mic className="w-5 h-5" />
                  </button>
                  
                  {coreState === 'SPEAKING' || coreState === 'THINKING' ? (
                    <button onClick={onStop} className="p-3 rounded-full bg-cyan-900/40 text-cyan-400 hover:bg-cyan-800/60 border border-cyan-500/30">
                      <Square className="w-5 h-5 fill-current" />
                    </button>
                  ) : null}
                </div>
             </div>
          </div>

        </div>

        {/* Right Column: Mission Logs */}
        <div className="flex flex-col h-full border border-cyan-500/20 bg-cyan-950/10 rounded-2xl p-4 backdrop-blur-md overflow-hidden relative">
          <div className="absolute top-3 left-3 text-xs font-mono text-cyan-500 uppercase tracking-widest flex items-center gap-2 mb-4">
            <Waves className="w-4 h-4" /> Terminal Feed
          </div>

          <div className="mt-8 flex-1 overflow-y-auto font-mono text-[11px] sm:text-xs text-cyan-400/80 space-y-1.5 scrollbar-thin" ref={scrollRef}>
            {logs.map((log, i) => (
              <div key={i} className="animate-in fade-in slide-in-from-bottom-2">
                {log}
              </div>
            ))}
          </div>
          
          <div className="h-12 border-t border-cyan-500/20 mt-4 flex items-center">
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse mr-2" />
            <span className="text-xs font-mono text-cyan-300 uppercase tracking-widest">Awaiting Directives...</span>
          </div>
        </div>

      </div>
    </div>
  );
};
