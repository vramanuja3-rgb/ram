import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Sphere, Box, Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';

const ParticleRing = ({ radius, count, speed, color }: { radius: number; count: number; speed: number; color: string }) => {
  const pointsRef = useRef<THREE.Points>(null);
  
  const [positions, phases] = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const phs = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      const theta = Math.random() * Math.PI * 2;
      const r = radius + (Math.random() - 0.5) * 0.2;
      pos[i * 3] = Math.cos(theta) * r;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 0.5;
      pos[i * 3 + 2] = Math.sin(theta) * r;
      phs[i] = Math.random() * Math.PI * 2;
    }
    return [pos, phs];
  }, [count, radius]);

  useFrame((state) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y = state.clock.elapsedTime * speed;
      const positions = pointsRef.current.geometry.attributes.position.array as Float32Array;
      for (let i = 0; i < count; i++) {
        // slight vertical undulation
        positions[i * 3 + 1] += Math.sin(state.clock.elapsedTime * 2 + phases[i]) * 0.005;
      }
      pointsRef.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  return (
    <Points ref={pointsRef} positions={positions}>
      <PointMaterial transparent color={color} size={0.05} sizeAttenuation={true} depthWrite={false} blending={THREE.AdditiveBlending} />
    </Points>
  );
};

const RotatingGeometricCore = ({ isSpeaking, coreState }: { isSpeaking: boolean; coreState: string }) => {
  const outerGroup = useRef<THREE.Group>(null);
  const innerMesh = useRef<THREE.Mesh>(null);
  const middleMesh = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (outerGroup.current) {
      outerGroup.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.5) * 0.2;
      outerGroup.current.rotation.y += 0.01;
    }
    if (innerMesh.current) {
      innerMesh.current.rotation.y -= 0.02;
      innerMesh.current.rotation.z += 0.01;
      
      // Pulse scale when speaking
      if (isSpeaking) {
        const scale = 1 + Math.sin(state.clock.elapsedTime * 15) * 0.1;
        innerMesh.current.scale.set(scale, scale, scale);
      } else {
        innerMesh.current.scale.lerp(new THREE.Vector3(1, 1, 1), 0.1);
      }
    }
    if (middleMesh.current) {
      middleMesh.current.rotation.x += 0.015;
      middleMesh.current.rotation.y -= 0.01;
    }
  });

  const coreColor = coreState === 'LISTENING' ? '#10b981' : coreState === 'ERROR' ? '#ef4444' : '#06b6d4'; // Cyan by default

  return (
    <group ref={outerGroup}>
      {/* Inner glowing sphere */}
      <Sphere ref={innerMesh} args={[1, 32, 32]}>
        <meshBasicMaterial color={coreColor} wireframe transparent opacity={0.3} blending={THREE.AdditiveBlending} />
      </Sphere>
      
      {/* Middle Icosahedron */}
      <mesh ref={middleMesh}>
        <icosahedronGeometry args={[1.5, 1]} />
        <meshBasicMaterial color={coreColor} wireframe transparent opacity={0.15} blending={THREE.AdditiveBlending} />
      </mesh>

      {/* Particle Rings */}
      <ParticleRing radius={2.2} count={300} speed={0.2} color={coreColor} />
      <ParticleRing radius={2.5} count={200} speed={-0.15} color={coreColor} />
      <ParticleRing radius={3.0} count={400} speed={0.1} color={coreColor} />
    </group>
  );
};

interface HologramCoreProps {
  coreState: string;
  isSpeaking: boolean;
}

export const HologramCore: React.FC<HologramCoreProps> = ({ coreState, isSpeaking }) => {
  return (
    <Canvas camera={{ position: [0, 0, 8], fov: 45 }} gl={{ alpha: true, antialias: true }}>
      <ambientLight intensity={0.5} />
      <RotatingGeometricCore isSpeaking={isSpeaking} coreState={coreState} />
      <OrbitControls enableZoom={true} enablePan={false} autoRotate={false} />
    </Canvas>
  );
};
