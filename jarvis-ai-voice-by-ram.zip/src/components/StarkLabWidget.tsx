import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Settings, Activity, Cpu, Wifi, Database, Crosshair, ShieldAlert, Zap, Terminal, Server, Globe } from 'lucide-react';
import { JarvisWaveform } from './JarvisWaveform';
import { ArcReactor } from './ArcReactor';
import { LineChart, Line, ResponsiveContainer, YAxis } from 'recharts';

interface Props {
  coreState: string;
  isListening: boolean;
  isSpeaking: boolean;
  transcript: string;
  onToggleListen: () => void;
  onOpenSettings: () => void;
}

export const StarkLabWidget: React.FC<Props> = ({
  coreState,
  isListening,
  isSpeaking,
  transcript,
  onToggleListen,
  onOpenSettings
}) => {
  const [dataPoints, setDataPoints] = useState<any[]>([]);
  const [hexLogs, setHexLogs] = useState<string[]>([]);

  // Generate random scrolling data
  useEffect(() => {
    const interval = setInterval(() => {
      setDataPoints(prev => {
        const next = [...prev, { value1: Math.random() * 100, value2: Math.random() * 50 + 50 }];
        if (next.length > 20) next.shift();
        return next;
      });

      setHexLogs(prev => {
        const next = [...prev, `0x${Math.floor(Math.random()*16777215).toString(16).toUpperCase().padStart(6, '0')} : ${Math.random() > 0.5 ? 'OK' : 'SYNC'}`];
        if (next.length > 15) next.shift();
        return next;
      });
    }, 500);
    return () => clearInterval(interval);
  }, []);

  const primaryColor = coreState === 'LISTENING' ? 'text-emerald-400' : coreState === 'ERROR' ? 'text-red-500' : 'text-cyan-400';
  const borderColor = coreState === 'LISTENING' ? 'border-emerald-500/50' : coreState === 'ERROR' ? 'border-red-500/50' : 'border-cyan-500/50';

  return (
    <div className="min-h-screen bg-[#020617] overflow-hidden flex flex-col items-center justify-center font-sans perspective-[2000px]">
      
      <style>{`
        .radar-sweep {
          background: conic-gradient(from 0deg, transparent 70%, rgba(6, 182, 212, 0.5) 100%);
          border-radius: 50%;
          animation: spin 4s linear infinite;
        }
        @keyframes spin { 100% { transform: rotate(360deg); } }
        .glass-panel {
          background: rgba(8, 51, 68, 0.15);
          backdrop-filter: blur(8px);
          border: 1px solid rgba(6, 182, 212, 0.2);
          box-shadow: 0 0 20px rgba(6, 182, 212, 0.1), inset 0 0 20px rgba(6, 182, 212, 0.05);
        }
        .crt-scan {
          background: linear-gradient(to bottom, transparent 50%, rgba(6, 182, 212, 0.05) 51%);
          background-size: 100% 4px;
        }
      `}</style>

      {/* Background Holographic Atmosphere */}
      <div className="absolute inset-0 z-0">
         <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-cyan-900/20 via-[#020617] to-[#020617]" />
         <div className="absolute inset-0 opacity-20 crt-scan" />
         <div className="absolute inset-0 opacity-10" style={{
            backgroundImage: `linear-gradient(rgba(6,182,212,0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(6,182,212,0.4) 1px, transparent 1px)`,
            backgroundSize: '40px 40px',
            backgroundPosition: 'center center'
         }} />
         {/* Floating glowing orbs simulating out-of-focus background holograms */}
         <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-600/10 rounded-full blur-[100px]" />
         <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[120px]" />
      </div>

      {/* Panoramic Wraparound Desk Layout */}
      <div 
        className="relative z-10 flex items-stretch justify-center w-full max-w-[100vw] h-[75vh] px-4" 
        style={{ transformStyle: 'preserve-3d', perspective: '1500px' }}
      >
        
        {/* Panel 1: Far Left (Network / Logs) */}
        <div 
          className="glass-panel flex-1 min-w-[220px] rounded-xl p-4 flex flex-col gap-4 text-cyan-500 overflow-hidden"
          style={{ transform: 'rotateY(35deg) translateZ(-150px) translateX(80px)' }}
        >
          <div className="flex items-center gap-2 border-b border-cyan-500/30 pb-2">
            <Server className="w-4 h-4" />
            <span className="text-xs font-bold tracking-widest uppercase">Global Uplink</span>
          </div>
          <div className="flex-1 font-mono text-[10px] space-y-1 flex flex-col justify-end">
             {hexLogs.map((log, i) => (
                <div key={i} className="opacity-80 flex justify-between">
                  <span>{log.split(':')[0]}</span>
                  <span className={log.includes('OK') ? 'text-emerald-400' : 'text-cyan-300'}>{log.split(':')[1]}</span>
                </div>
             ))}
          </div>
          <div className="h-1 bg-cyan-950 rounded-full overflow-hidden mt-4">
             <div className="h-full bg-cyan-400 w-[78%] animate-pulse shadow-[0_0_10px_rgba(6,182,212,0.8)]" />
          </div>
        </div>

        {/* Panel 2: Left (Arc Reactor Core) */}
        <div 
          className="glass-panel flex-1 min-w-[280px] rounded-xl p-4 flex flex-col gap-4 text-cyan-500"
          style={{ transform: 'rotateY(18deg) translateZ(-30px) translateX(30px)' }}
        >
          <div className="flex items-center justify-between border-b border-cyan-500/30 pb-2">
            <span className="text-xs font-bold tracking-widest uppercase">Mark VI Core</span>
            <Zap className="w-4 h-4" />
          </div>
          <div className="flex-1 relative flex items-center justify-center">
             <div className="w-48 h-48">
                <ArcReactor />
             </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[10px] font-mono mt-4">
             <div className="bg-cyan-950/40 p-2 rounded border border-cyan-500/20 text-center">
                <div className="text-cyan-700 mb-1">PALLADIUM</div>
                <div className="text-cyan-300">94.2%</div>
             </div>
             <div className="bg-cyan-950/40 p-2 rounded border border-cyan-500/20 text-center">
                <div className="text-cyan-700 mb-1">OUTPUT</div>
                <div className="text-cyan-300">3.2 GJ/s</div>
             </div>
          </div>
        </div>

        {/* Panel 3: Center (Main JARVIS Interface) */}
        <div 
          className={`glass-panel flex-[1.5] min-w-[450px] rounded-2xl p-8 flex flex-col items-center justify-between z-20 ${borderColor} border-2`}
          style={{ transform: 'rotateY(0deg) translateZ(50px)', boxShadow: '0 0 40px rgba(6,182,212,0.2)' }}
        >
           <div className="w-full flex justify-between items-start">
             <button onClick={onOpenSettings} className="p-2 rounded-full text-cyan-700 hover:text-cyan-400 hover:bg-cyan-900/30 transition-all">
                <Settings className="w-5 h-5" />
             </button>
             <div className="flex flex-col items-center">
               <div className={`text-4xl font-bold tracking-[0.5em] uppercase drop-shadow-[0_0_15px_rgba(6,182,212,0.8)] ${primaryColor}`}>
                 JARVIS
               </div>
               <div className="text-[10px] font-mono tracking-widest text-cyan-600 uppercase mt-1">
                 Just A Rather Very Intelligent System
               </div>
             </div>
             <div className="w-9" /> {/* Spacer for centering */}
           </div>

           <div className="w-full h-40 my-8 mix-blend-screen relative">
              <div className="absolute inset-0 flex items-center justify-center">
                 <div className={`w-64 h-64 rounded-full border border-cyan-500/10 animate-[spin_10s_linear_infinite]`} />
                 <div className={`absolute w-56 h-56 rounded-full border border-cyan-500/20 border-dashed animate-[spin_15s_linear_infinite_reverse]`} />
              </div>
              <JarvisWaveform
                 isActive={isListening || isSpeaking || coreState === 'THINKING'}
                 isListening={isListening}
                 isSpeaking={isSpeaking}
              />
           </div>

           <div className="w-full flex flex-col items-center gap-6">
              <div className="h-16 flex items-center justify-center w-full">
                 {transcript ? (
                    <div className={`text-sm ${primaryColor} text-center font-mono italic px-6 py-3 bg-cyan-950/40 rounded-lg border ${borderColor} backdrop-blur-md w-full truncate`}>
                       &gt; {transcript}
                    </div>
                 ) : (
                    <div className="text-sm text-cyan-800/70 text-center font-mono tracking-widest uppercase">
                       [ Awaiting Voice Directive ]
                    </div>
                 )}
              </div>
              <button
                onClick={onToggleListen}
                className={`p-5 rounded-full border-2 transition-all ${
                  isListening 
                    ? 'bg-cyan-500/20 border-emerald-500 text-emerald-400 shadow-[0_0_30px_rgba(52,211,153,0.3)]' 
                    : 'bg-[#020617]/80 border-cyan-800 text-cyan-600 hover:text-cyan-400 hover:border-cyan-500'
                }`}
              >
                {isListening ? <Mic className="w-7 h-7" /> : <MicOff className="w-7 h-7" />}
              </button>
           </div>
        </div>

        {/* Panel 4: Right (Telemetry / Radar) */}
        <div 
          className="glass-panel flex-1 min-w-[280px] rounded-xl p-4 flex flex-col gap-4 text-cyan-500"
          style={{ transform: 'rotateY(-18deg) translateZ(-30px) translateX(-30px)' }}
        >
          <div className="flex items-center justify-between border-b border-cyan-500/30 pb-2">
            <span className="text-xs font-bold tracking-widest uppercase">Tactical Sweep</span>
            <Crosshair className="w-4 h-4" />
          </div>
          
          <div className="flex-1 relative flex items-center justify-center">
            {/* Radar Animation */}
            <div className="relative w-48 h-48 rounded-full border border-cyan-500/30 overflow-hidden flex items-center justify-center">
               <div className="absolute inset-0 bg-[radial-gradient(circle,rgba(6,182,212,0.1)_0%,transparent_70%)]" />
               <div className="absolute w-full h-full radar-sweep origin-center" />
               
               {/* Grid lines */}
               <div className="absolute w-full h-[1px] bg-cyan-500/20" />
               <div className="absolute h-full w-[1px] bg-cyan-500/20" />
               <div className="absolute w-32 h-32 rounded-full border border-cyan-500/20" />
               <div className="absolute w-16 h-16 rounded-full border border-cyan-500/20" />

               {/* Random blips */}
               <div className="absolute top-10 left-12 w-1.5 h-1.5 bg-cyan-300 rounded-full shadow-[0_0_5px_#67e8f9] animate-pulse" />
               <div className="absolute bottom-16 right-10 w-1.5 h-1.5 bg-emerald-400 rounded-full shadow-[0_0_5px_#34d399]" />
            </div>
          </div>

          <div className="h-24 w-full mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={dataPoints}>
                <Line type="monotone" dataKey="value1" stroke="#22d3ee" strokeWidth={2} dot={false} isAnimationActive={false} />
                <Line type="monotone" dataKey="value2" stroke="#0ea5e9" strokeWidth={1} dot={false} isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Panel 5: Far Right (Systems / Suit) */}
        <div 
          className="glass-panel flex-1 min-w-[220px] rounded-xl p-4 flex flex-col gap-4 text-cyan-500 overflow-hidden"
          style={{ transform: 'rotateY(-35deg) translateZ(-150px) translateX(-80px)' }}
        >
          <div className="flex items-center gap-2 border-b border-cyan-500/30 pb-2">
            <ShieldAlert className="w-4 h-4" />
            <span className="text-xs font-bold tracking-widest uppercase">Armor Status</span>
          </div>
          <div className="flex-1 flex flex-col gap-6 justify-center">
             {[
               { label: 'HULL INTEGRITY', val: '98%', color: 'bg-emerald-400', w: '98%' },
               { label: 'LIFE SUPPORT', val: '100%', color: 'bg-cyan-400', w: '100%' },
               { label: 'REPULSORS', val: '85%', color: 'bg-cyan-400', w: '85%' },
               { label: 'WEAPONS', val: 'OFFLINE', color: 'bg-red-500', w: '20%' }
             ].map(stat => (
               <div key={stat.label} className="flex flex-col gap-1">
                 <div className="flex justify-between text-[10px] font-mono">
                   <span className="text-cyan-600">{stat.label}</span>
                   <span className={stat.color.replace('bg-', 'text-')}>{stat.val}</span>
                 </div>
                 <div className="w-full h-1 bg-cyan-950 rounded overflow-hidden">
                    <div className={`h-full ${stat.color} shadow-[0_0_10px_currentColor]`} style={{ width: stat.w }} />
                 </div>
               </div>
             ))}
          </div>
        </div>

      </div>
    </div>
  );
};
