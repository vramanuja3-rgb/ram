import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';

interface RepulsorEffectProps {
  isActive: boolean;
  onComplete?: () => void;
}

export const RepulsorEffect: React.FC<RepulsorEffectProps> = ({ isActive, onComplete }) => {
  useEffect(() => {
    if (isActive) {
      // Trigger laser-plasma particle shockwave
      confetti({
        particleCount: 80,
        spread: 120,
        origin: { y: 0.5, x: 0.5 },
        colors: ['#38bdf8', '#00f0ff', '#ffffff', '#e0f2fe'],
        disableForReducedMotion: true,
        ticks: 200,
        gravity: 0.4,
        scalar: 1.2,
      });

      const timer = setTimeout(() => {
        onComplete?.();
      }, 900);

      return () => clearTimeout(timer);
    }
  }, [isActive, onComplete]);

  if (!isActive) return null;

  return (
    <div className="fixed inset-0 z-50 pointer-events-none flex items-center justify-center overflow-hidden">
      {/* Intense White/Cyan Screen Flash */}
      <div className="absolute inset-0 bg-cyan-400/40 animate-ping duration-300" />
      <div className="absolute inset-0 bg-radial from-white/90 via-cyan-400/30 to-transparent animate-pulse" />

      {/* Expanding Concentric Plasma Shockwaves */}
      <div className="relative flex items-center justify-center">
        <div className="w-96 h-96 rounded-full border-4 border-white shadow-[0_0_80px_#00f0ff] animate-ping" />
        <div className="absolute w-[600px] h-[600px] rounded-full border-2 border-cyan-300 shadow-[0_0_60px_#38bdf8] animate-ping duration-700" />
        <div className="absolute font-orbitron font-black text-2xl text-white tracking-widest drop-shadow-[0_0_20px_#00f0ff]">
          REPULSOR DISCHARGE 100%
        </div>
      </div>
    </div>
  );
};
