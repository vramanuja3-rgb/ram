import React, { useState, useEffect } from 'react';
import { Battery, BatteryCharging, Zap, Activity, AlertTriangle, ShieldAlert } from 'lucide-react';

export const SystemStatusWidget: React.FC = () => {
  const [batteryLevel, setBatteryLevel] = useState<number>(98.5);
  const [isCharging, setIsCharging] = useState<boolean>(false);
  const [isSupported, setIsSupported] = useState<boolean>(true);

  // Simulated sci-fi metrics for the holographic feel
  const [voltage, setVoltage] = useState(450);
  const [powerDraw, setPowerDraw] = useState(1.2);
  const [coreTemp, setCoreTemp] = useState(3400);

  useEffect(() => {
    // 1. Attempt to connect to real device battery API
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        const updateBattery = () => {
          setBatteryLevel(battery.level * 100);
          setIsCharging(battery.charging);
        };
        
        updateBattery();
        battery.addEventListener('levelchange', updateBattery);
        battery.addEventListener('chargingchange', updateBattery);
      }).catch(() => {
        setIsSupported(false);
      });
    } else {
      setIsSupported(false);
    }

    // 2. Real-time fluctuations for the sci-fi HUD elements
    const interval = setInterval(() => {
      setVoltage(445 + Math.random() * 12);
      setPowerDraw(1.0 + Math.random() * 0.8);
      setCoreTemp(3395 + Math.random() * 15);
      
      // If unsupported, fake a slow drain for visual effect
      if (!('getBattery' in navigator)) {
        setBatteryLevel(prev => Math.max(0, prev - 0.05));
      }
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const isLowPower = batteryLevel < 20 && !isCharging;
  const isCritical = batteryLevel < 5 && !isCharging;

  return (
    <div className="absolute bottom-6 left-6 z-40 w-64 pointer-events-none select-none">
      {/* Holographic Container */}
      <div className={`relative p-4 rounded-lg bg-black/40 backdrop-blur-md border ${isCritical ? 'border-red-500/50 shadow-[0_0_20px_rgba(239,68,68,0.2)]' : isLowPower ? 'border-orange-500/50' : 'border-cyan-500/30 shadow-[0_0_15px_rgba(6,182,212,0.15)]'} overflow-hidden`}>
        
        {/* Holographic Scanlines */}
        <div className="absolute inset-0 bg-[linear-gradient(transparent_50%,rgba(6,182,212,0.05)_50%)] bg-[length:100%_4px] pointer-events-none opacity-50 mix-blend-screen" />
        
        {/* Header */}
        <div className={`flex justify-between items-center border-b pb-2 mb-3 ${isCritical ? 'border-red-500/30 text-red-400' : 'border-cyan-500/30 text-cyan-400'}`}>
          <span className="text-[10px] font-mono tracking-widest uppercase font-bold flex items-center gap-2">
            {isCritical ? <ShieldAlert className="w-3 h-3 animate-pulse" /> : <Activity className="w-3 h-3" />}
            {isSupported ? 'Local Device Link' : 'Suit Telemetry'}
          </span>
          <div className="flex items-center gap-1">
            <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${isCharging ? 'bg-green-400 shadow-[0_0_8px_rgba(74,222,128,0.8)]' : isCritical ? 'bg-red-500' : 'bg-cyan-400'}`} />
            <span className="text-[8px] font-mono uppercase text-neutral-500">{isCharging ? 'AC IN' : 'BATT'}</span>
          </div>
        </div>
        
        {/* Main Battery Display */}
        <div className="flex flex-col gap-3 font-mono">
          <div className="flex flex-col gap-1">
            <div className="flex justify-between items-center text-xs">
              <span className={`flex items-center gap-2 ${isCritical ? 'text-red-400' : 'text-neutral-300'}`}>
                {isCharging ? <BatteryCharging className="w-4 h-4 text-green-400" /> : <Battery className="w-4 h-4" />}
                {isCharging ? 'Charging' : 'Core Power'}
              </span>
              <span className={`font-bold ${isCritical ? 'text-red-500 animate-pulse' : isLowPower ? 'text-orange-400' : 'text-cyan-400'}`}>
                {batteryLevel.toFixed(1)}%
              </span>
            </div>
            
            {/* Custom Battery Bar */}
            <div className={`w-full h-1.5 bg-neutral-900 rounded-full overflow-hidden border ${isCritical ? 'border-red-900/50' : 'border-cyan-900/50'}`}>
              <div 
                className={`h-full transition-all duration-1000 ${
                  isCharging ? 'bg-green-400 shadow-[0_0_10px_rgba(74,222,128,0.5)]' : 
                  isCritical ? 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.8)]' : 
                  isLowPower ? 'bg-orange-500' : 
                  'bg-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.8)]'
                }`}
                style={{ width: `${batteryLevel}%` }}
              />
            </div>
          </div>

          {/* Sub Metrics */}
          <div className="grid grid-cols-2 gap-2 mt-2">
            <div className="flex flex-col bg-neutral-900/50 p-2 rounded border border-white/5">
              <span className={`text-[9px] uppercase tracking-wider ${isCritical ? 'text-red-500/70' : 'text-cyan-500/70'}`}>I/O Draw</span>
              <span className={`text-xs flex items-center gap-1 ${isCritical ? 'text-red-400' : 'text-neutral-200'}`}>
                <Zap className="w-3 h-3" /> {powerDraw.toFixed(2)} kW
              </span>
            </div>
            <div className="flex flex-col bg-neutral-900/50 p-2 rounded border border-white/5">
              <span className={`text-[9px] uppercase tracking-wider ${isCritical ? 'text-red-500/70' : 'text-cyan-500/70'}`}>Voltage</span>
              <span className={`text-xs ${isCritical ? 'text-red-400' : 'text-neutral-200'}`}>
                {voltage.toFixed(0)} V
              </span>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  );
};
