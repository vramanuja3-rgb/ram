import React from 'react';

export const ArcReactor = () => {
  return (
    <svg viewBox="0 0 500 500" className="w-full h-full drop-shadow-[0_0_25px_rgba(34,211,238,0.8)]">
      <defs>
        <filter id="glow-cyan" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="12" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
        <filter id="glow-white" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="15" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
        <filter id="glow-outer" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="25" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
        <linearGradient id="metal-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0f172a" />
          <stop offset="50%" stopColor="#020617" />
          <stop offset="100%" stopColor="#0f172a" />
        </linearGradient>
        <radialGradient id="cyan-core" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#cffafe" />
          <stop offset="40%" stopColor="#22d3ee" />
          <stop offset="100%" stopColor="#0891b2" />
        </radialGradient>
      </defs>

      {/* Ambient back glow (purple/blue mix like the image) */}
      <circle cx="250" cy="250" r="230" fill="#3b82f6" filter="url(#glow-outer)" opacity="0.3" />
      <circle cx="250" cy="250" r="210" fill="#8b5cf6" filter="url(#glow-outer)" opacity="0.2" />

      {/* Outer Ring */}
      <circle cx="250" cy="250" r="220" fill="none" stroke="#020617" strokeWidth="15" />

      {/* Cyan Background Base */}
      <circle cx="250" cy="250" r="205" fill="url(#cyan-core)" filter="url(#glow-cyan)" />

      {/* Dark Mechanical Spokes */}
      <g fill="url(#metal-gradient)">
        <rect x="0" y="225" width="500" height="50" />
        <rect x="0" y="225" width="500" height="50" transform="rotate(60 250 250)" />
        <rect x="0" y="225" width="500" height="50" transform="rotate(120 250 250)" />
      </g>

      {/* Inner Dark Circle */}
      <circle cx="250" cy="250" r="145" fill="url(#metal-gradient)" />
      {/* Inner Cyan Ring (Subtle) */}
      <circle cx="250" cy="250" r="135" fill="none" stroke="#22d3ee" strokeWidth="4" opacity="0.5" filter="url(#glow-cyan)" />

      {/* Outer Dark Triangle */}
      <polygon points="250,425 98.5,162.5 401.5,162.5" fill="url(#metal-gradient)" stroke="#020617" strokeWidth="5" />

      {/* Cyan Triangle */}
      <polygon points="250,395 124.4,177.5 375.6,177.5" fill="url(#cyan-core)" stroke="#67e8f9" strokeWidth="6" filter="url(#glow-cyan)" />

      {/* Inner Dark Triangle */}
      <polygon points="250,350 163.4,200 336.6,200" fill="url(#metal-gradient)" />

      {/* White Core Triangle */}
      <polygon points="250,310 198,220 302,220" fill="#ffffff" filter="url(#glow-white)" />

      {/* Extra Core Flare */}
      <circle cx="250" cy="250" r="60" fill="#ffffff" filter="url(#glow-white)" opacity="0.9" className="animate-pulse" />
      <circle cx="250" cy="250" r="30" fill="#ffffff" filter="url(#glow-white)" />
    </svg>
  );
};
