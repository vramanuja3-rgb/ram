import React, { useState, useEffect, useCallback } from 'react';
import { Bot, Map, Music, Video, Image as ImageIcon, Mic, Activity, Upload, Check, Radio } from 'lucide-react';
import { soundEffects } from '../utils/audioSystem';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export const AdvancedAILab: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'chat' | 'media' | 'audio' | 'performance'>('performance');

  return (
    <div className="flex flex-col h-full bg-cyan-950/10 border border-cyan-500/30 rounded-xl overflow-hidden relative">
      {/* Sci-fi Overlay Background */}
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 pointer-events-none" />

      {/* Header Tabs */}
      <div className="flex items-center gap-2 p-2 border-b border-cyan-500/30 bg-black/60 relative z-10 flex-wrap">
        {[
          { id: 'performance', label: 'PERFORMANCE', icon: Activity },
          { id: 'chat', label: 'NEURAL CHAT', icon: Bot },
          { id: 'media', label: 'MEDIA SYNTHESIS', icon: ImageIcon },
          { id: 'audio', label: 'LIVE COMMS', icon: Mic },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                soundEffects.playChirp();
                setActiveTab(tab.id as any);
              }}
              className={`flex-1 min-w-[100px] flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-[10px] sm:text-xs font-orbitron font-bold tracking-wider transition-all ${
                isActive
                  ? 'bg-cyan-500/30 border border-cyan-400 text-white glow-box-cyan'
                  : 'text-cyan-400/70 hover:text-cyan-200 hover:bg-cyan-950/40 border border-transparent'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto p-4 relative z-10 scrollbar-thin scrollbar-thumb-cyan-500/50 scrollbar-track-transparent">
        {activeTab === 'performance' && <SystemPerformanceModule />}
        {activeTab === 'chat' && <ChatbotModule />}
        {activeTab === 'media' && <MediaSynthesisModule />}
        {activeTab === 'audio' && <LiveAudioModule />}
      </div>
    </div>
  );
};

// Submodules (Basic placeholders with futuristic styling, we'll flesh them out)

const ChatbotModule = () => {
  const [prompt, setPrompt] = useState("");
  const [useMaps, setUseMaps] = useState(false);
  const [history, setHistory] = useState<{role: string, text: string}[]>([]);
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!prompt.trim()) return;
    const userMsg = prompt;
    setPrompt("");
    setHistory(prev => [...prev, { role: "user", text: userMsg }]);
    setLoading(true);

    try {
      const res = await fetch("/api/jarvis/advanced-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: userMsg, useMaps, history }),
      });
      if (!res.ok) { console.warn("[JARVIS] HTTP error " + res.status); return; }
      const data = await res.json();
      setHistory(prev => [...prev, { role: "model", text: data.text || "No response." }]);
    } catch (err) {
      setHistory(prev => [...prev, { role: "system", text: "Error connecting to AI Core." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      <div className="flex-1 bg-black/60 border border-cyan-500/20 rounded p-4 overflow-y-auto space-y-4 font-mono-tech text-sm">
        {history.length === 0 && (
          <div className="text-cyan-400/50 text-center mt-10">Advanced Neural Chat Standing By. Initiate sequence...</div>
        )}
        {history.map((msg, idx) => (
          <div key={idx} className={`p-3 rounded border ${msg.role === 'user' ? 'bg-cyan-900/20 border-cyan-500/40 text-cyan-200 text-right ml-12' : 'bg-black/60 border-cyan-700/40 text-cyan-400 mr-12'}`}>
            <div className="text-[9px] font-orbitron mb-1 opacity-70">
              {msg.role === 'user' ? 'OPERATOR' : 'J.A.R.V.I.S.'}
            </div>
            <div>{msg.text}</div>
          </div>
        ))}
        {loading && <div className="text-cyan-300 animate-pulse">Processing...</div>}
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={() => setUseMaps(!useMaps)}
          className={`p-2 rounded border transition-all ${useMaps ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300' : 'bg-black/60 border-cyan-500/30 text-cyan-400/50 hover:bg-cyan-900/30'}`}
          title="Toggle Google Maps Grounding"
        >
          <Map className="w-5 h-5" />
        </button>
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          placeholder="Enter neural directive..."
          className="flex-1 bg-black/60 border border-cyan-500/40 rounded px-3 py-2 text-cyan-300 placeholder-cyan-700 font-mono-tech focus:outline-none focus:border-cyan-300 glow-focus"
        />
        <button
          onClick={sendMessage}
          disabled={loading}
          className="px-4 py-2 bg-cyan-950 hover:bg-cyan-900 border border-cyan-400 text-cyan-300 rounded font-orbitron font-bold"
        >
          SEND
        </button>
      </div>
    </div>
  );
};

const MediaSynthesisModule = () => {
  const [prompt, setPrompt] = useState("");
  const [mediaType, setMediaType] = useState<'image' | 'video' | 'music'>('image');
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [referenceImage, setReferenceImage] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        setReferenceImage(base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  const pollVideoStatus = useCallback(async (operationName: string) => {
    try {
      const res = await fetch("/api/jarvis/video-status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ operationName }),
      });
      if (!res.ok) { console.warn("[JARVIS] HTTP error"); }
      const data = await res.json();
      if (data.done) {
        setResult({ type: 'video', src: `/api/jarvis/video-download?operationName=${operationName}` });
      } else {
        setTimeout(() => pollVideoStatus(operationName), 10000); // Poll every 10s
      }
    } catch (err) {
      console.warn("[JARVIS Auto-Recovery] Polling error", err);
    }
  }, []);

  const generateMedia = async () => {
    if (!prompt.trim() && !referenceImage) return;
    setLoading(true);
    setResult(null);
    try {
      if (mediaType === 'image') {
        const res = await fetch("/api/jarvis/image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt }),
        });
        if (!res.ok) { console.warn("[JARVIS] HTTP error"); }
        const data = await res.json();
        setResult({ type: 'image', src: `data:${data.mimeType};base64,${data.image}` });
        setLoading(false);
      } else if (mediaType === 'music') {
        const res = await fetch("/api/jarvis/music", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt }),
        });
        if (!res.ok) { console.warn("[JARVIS] HTTP error"); }
        const data = await res.json();
        setResult({ type: 'music', src: `data:${data.mimeType};base64,${data.audio}` });
        setLoading(false);
      } else if (mediaType === 'video') {
        const res = await fetch("/api/jarvis/video", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt, imageBase64: referenceImage }),
        });
        if (!res.ok) { console.warn("[JARVIS] HTTP error"); }
        const data = await res.json();
        setResult({ type: 'video_operation', name: data.operationName });
        pollVideoStatus(data.operationName);
      }
    } catch (err) {
      console.warn("[JARVIS Auto-Recovery] ", err);
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      <div className="flex gap-2">
        {['image', 'video', 'music'].map(t => (
          <button
            key={t}
            onClick={() => setMediaType(t as any)}
            className={`flex-1 py-1 border rounded text-xs font-orbitron ${mediaType === t ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200' : 'bg-black/60 border-cyan-500/20 text-cyan-600'}`}
          >
            {t.toUpperCase()} SYNTHESIS
          </button>
        ))}
      </div>
      
      {mediaType === 'video' && (
        <div className="flex gap-2 items-center bg-black/60 border border-cyan-500/20 p-2 rounded text-xs text-cyan-400/80">
          <Upload className="w-4 h-4" />
          <span className="font-mono-tech">Reference Image (Optional):</span>
          <input type="file" accept="image/*" onChange={handleImageUpload} className="max-w-[200px]" />
          {referenceImage && <span className="text-emerald-400 ml-auto flex items-center gap-1"><Check className="w-3 h-3" /> LOADED</span>}
        </div>
      )}

      <div className="flex-1 bg-black/60 border border-cyan-500/20 rounded p-4 flex flex-col items-center justify-center overflow-y-auto">
        {loading && mediaType !== 'video' ? (
          <div className="text-cyan-400 animate-pulse font-mono-tech flex flex-col items-center gap-2">
            <Radio className="w-8 h-8 animate-ping" />
            Synthesizing Request...
          </div>
        ) : result ? (
          result.type === 'image' ? (
            <img src={result.src} className="max-w-full max-h-64 object-contain rounded border border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.3)]" alt="Synthesized" />
          ) : result.type === 'music' ? (
            <div className="w-full max-w-md bg-cyan-950/40 p-4 rounded-xl border border-cyan-500/50">
              <div className="flex items-center gap-3 mb-4 text-cyan-300 font-orbitron font-bold">
                <Music className="w-5 h-5" />
                <span>LYRIA AUDIO PLAYBACK</span>
              </div>
              <audio controls src={result.src} className="w-full" autoPlay />
            </div>
          ) : result.type === 'video' ? (
            <video controls src={result.src} className="max-w-full max-h-64 rounded border border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.3)]" autoPlay loop />
          ) : result.type === 'video_operation' ? (
            <div className="text-center font-mono-tech text-cyan-300">
              <div className="text-emerald-400 mb-2 flex items-center justify-center gap-2">
                <Radio className="w-4 h-4 animate-spin" />
                Video Synthesis Initiated...
              </div>
              <div className="text-[10px] opacity-70">Operation ID: {result.name}</div>
              <div className="text-[10px] text-cyan-400 mt-2">Polling for status every 10s. This takes approx 1-2 minutes.</div>
            </div>
          ) : null
        ) : (
          <div className="opacity-50 text-center font-mono-tech flex flex-col items-center">
            <div className="mb-2 text-3xl flex justify-center text-cyan-500">
              {mediaType === 'image' && <ImageIcon />}
              {mediaType === 'video' && <Video />}
              {mediaType === 'music' && <Music />}
            </div>
            Awaiting {mediaType} synthesis parameters...
          </div>
        )}
      </div>

      <div className="flex gap-2">
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder={`Enter ${mediaType} prompt...`}
          className="flex-1 bg-black/60 border border-cyan-500/40 rounded px-3 py-2 text-cyan-300 font-mono-tech focus:outline-none focus:border-cyan-300"
        />
        <button onClick={generateMedia} disabled={loading && mediaType !== 'video'} className="px-4 bg-cyan-950 hover:bg-cyan-900 border border-cyan-400 text-cyan-300 rounded font-orbitron font-bold transition-colors">
          EXECUTE
        </button>
      </div>
    </div>
  );
};

function pcmToBase64(pcmData: Float32Array) {
  const buffer = new ArrayBuffer(pcmData.length * 2);
  const view = new DataView(buffer);
  for (let i = 0; i < pcmData.length; i++) {
    const s = Math.max(-1, Math.min(1, pcmData[i]));
    view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true); // little-endian
  }
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunkSize)));
  }
  return btoa(binary);
}

const LiveAudioModule = () => {
  const [isLive, setIsLive] = useState(false);
  const wsRef = React.useRef<WebSocket | null>(null);
  const inputCtxRef = React.useRef<AudioContext | null>(null);
  const outputCtxRef = React.useRef<AudioContext | null>(null);
  const nextStartTimeRef = React.useRef<number>(0);
  const streamRef = React.useRef<MediaStream | null>(null);

  const startLive = async () => {
    try {
      const wsUrl = location.protocol === 'https:' ? `wss://${location.host}/live` : `ws://${location.host}/live`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      const inputCtx = new window.AudioContext({ sampleRate: 16000 });
      const outputCtx = new window.AudioContext({ sampleRate: 24000 });
      inputCtxRef.current = inputCtx;
      outputCtxRef.current = outputCtx;
      nextStartTimeRef.current = 0;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const source = inputCtx.createMediaStreamSource(stream);
      const processor = inputCtx.createScriptProcessor(4096, 1, 1);
      source.connect(processor);
      processor.connect(inputCtx.destination);

      processor.onaudioprocess = (e) => {
        if (ws.readyState === WebSocket.OPEN) {
          const base64 = pcmToBase64(e.inputBuffer.getChannelData(0));
          ws.send(JSON.stringify({ audio: base64 }));
        }
      };

      ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.audio) {
          const binary = atob(msg.audio);
          const buffer = new ArrayBuffer(binary.length);
          const view = new Uint8Array(buffer);
          for (let i = 0; i < binary.length; i++) {
            view[i] = binary.charCodeAt(i);
          }
          const int16Array = new Int16Array(buffer);
          const float32Array = new Float32Array(int16Array.length);
          for (let i = 0; i < int16Array.length; i++) {
            float32Array[i] = int16Array[i] / 32768;
          }
          const audioBuffer = outputCtx.createBuffer(1, float32Array.length, 24000);
          audioBuffer.getChannelData(0).set(float32Array);
          
          const sourceNode = outputCtx.createBufferSource();
          sourceNode.buffer = audioBuffer;
          sourceNode.connect(outputCtx.destination);
          
          const currentTime = outputCtx.currentTime;
          if (nextStartTimeRef.current < currentTime) {
            nextStartTimeRef.current = currentTime + 0.1;
          }
          sourceNode.start(nextStartTimeRef.current);
          nextStartTimeRef.current += audioBuffer.duration;
        }
        if (msg.interrupted) {
          nextStartTimeRef.current = outputCtx.currentTime;
        }
      };

      setIsLive(true);
    } catch (err) {
      console.warn("[JARVIS Auto-Recovery] Live start error", err);
    }
  };

  const stopLive = () => {
    wsRef.current?.close();
    inputCtxRef.current?.close();
    outputCtxRef.current?.close();
    streamRef.current?.getTracks().forEach(t => t.stop());
    setIsLive(false);
  };

  return (
    <div className="flex flex-col items-center justify-center h-full p-4 text-center space-y-6">
      <div className={`w-24 h-24 rounded-full border-4 ${isLive ? 'border-red-500/80 glow-box-red' : 'border-cyan-500/30 glow-box-cyan'} flex items-center justify-center relative bg-black/60 transition-all`}>
        <Mic className={`w-10 h-10 ${isLive ? 'text-red-400' : 'text-cyan-400'}`} />
        {isLive && <div className="absolute inset-0 rounded-full border-2 border-red-400 animate-ping opacity-50" />}
      </div>
      <div>
        <h3 className="font-orbitron font-bold text-lg text-cyan-300">LIVE AUDIO COMMS</h3>
        <p className="text-sm font-mono-tech text-cyan-400/70 mt-2">
          Real-time, ultra-low latency voice bridge with the Gemini Live API.
        </p>
      </div>
      {!isLive ? (
        <button onClick={startLive} className="px-6 py-3 bg-red-900/40 hover:bg-red-900/80 border border-red-500 text-red-300 rounded-lg font-orbitron font-bold tracking-widest transition-all shadow-[0_0_15px_rgba(239,68,68,0.3)]">
          INITIATE LIVE SESSION
        </button>
      ) : (
        <button onClick={stopLive} className="px-6 py-3 bg-neutral-800 hover:bg-neutral-700 border border-neutral-400 text-neutral-300 rounded-lg font-orbitron font-bold tracking-widest transition-all">
          TERMINATE CONNECTION
        </button>
      )}
    </div>
  );
};

const SystemPerformanceModule = () => {
  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    // Generate initial data
    const initialData = Array.from({ length: 30 }, (_, i) => ({
      time: i,
      cpu: Math.floor(Math.random() * 40) + 10,
      memory: Math.floor(Math.random() * 30) + 40,
      network: Math.floor(Math.random() * 50) + 20,
    }));
    setData(initialData);

    const interval = setInterval(() => {
      setData((prevData) => {
        if (prevData.length === 0) return prevData;
        const newData = [...prevData.slice(1)];
        const last = newData[newData.length - 1];
        
        // Random walk for smooth transitions
        let nextCpu = last.cpu + (Math.random() * 14 - 7);
        let nextMem = last.memory + (Math.random() * 8 - 4);
        let nextNet = last.network + (Math.random() * 20 - 10);
        
        // Clamp values
        nextCpu = Math.max(0, Math.min(100, nextCpu));
        nextMem = Math.max(0, Math.min(100, nextMem));
        nextNet = Math.max(0, Math.min(100, nextNet));

        newData.push({
          time: last.time + 1,
          cpu: Math.round(nextCpu),
          memory: Math.round(nextMem),
          network: Math.round(nextNet),
        });
        
        return newData;
      });
    }, 1500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col h-full space-y-4">
      <div className="flex justify-between items-center px-2">
        <h3 className="font-orbitron font-bold text-lg text-cyan-300 tracking-widest">REAL-TIME TELEMETRY</h3>
        <div className="flex gap-4 text-xs font-mono-tech">
          <span className="text-cyan-400">CPU: {data[data.length - 1]?.cpu ?? 0}%</span>
          <span className="text-emerald-400">MEM: {data[data.length - 1]?.memory ?? 0}%</span>
          <span className="text-amber-400">NET: {data[data.length - 1]?.network ?? 0}%</span>
        </div>
      </div>
      <div className="flex-1 bg-black/60 border border-cyan-500/20 rounded-lg p-4 relative overflow-hidden">
        {/* Glow effect under chart */}
        <div className="absolute inset-0 bg-cyan-900/10 blur-xl pointer-events-none" />
        
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#06b6d4" opacity={0.15} vertical={false} />
            <XAxis 
              dataKey="time" 
              hide 
            />
            <YAxis 
              stroke="#06b6d4" 
              opacity={0.5} 
              tick={{ fill: '#06b6d4', fontSize: 10, fontFamily: 'monospace' }} 
              domain={[0, 100]}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              contentStyle={{ backgroundColor: 'rgba(0, 0, 0, 0.8)', border: '1px solid rgba(6, 182, 212, 0.5)', borderRadius: '4px', fontFamily: 'monospace', fontSize: '12px' }}
              itemStyle={{ color: '#22d3ee' }}
              labelStyle={{ display: 'none' }}
            />
            <Legend 
              wrapperStyle={{ fontSize: '10px', fontFamily: 'monospace', color: '#22d3ee' }}
              iconType="circle"
            />
            <Line 
              type="monotone" 
              dataKey="cpu" 
              name="CPU USAGE"
              stroke="#22d3ee" 
              strokeWidth={2} 
              dot={false}
              isAnimationActive={false}
              style={{ filter: 'drop-shadow(0px 0px 4px rgba(34, 211, 238, 0.5))' }}
            />
            <Line 
              type="monotone" 
              dataKey="memory" 
              name="MEMORY ALLOC"
              stroke="#34d399" 
              strokeWidth={2} 
              dot={false}
              isAnimationActive={false}
              style={{ filter: 'drop-shadow(0px 0px 4px rgba(52, 211, 153, 0.5))' }}
            />
            <Line 
              type="monotone" 
              dataKey="network" 
              name="NETWORK I/O"
              stroke="#fbbf24" 
              strokeWidth={2} 
              dot={false}
              isAnimationActive={false}
              style={{ filter: 'drop-shadow(0px 0px 4px rgba(251, 191, 36, 0.5))' }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
