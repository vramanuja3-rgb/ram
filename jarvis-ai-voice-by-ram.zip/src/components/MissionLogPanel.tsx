import React, { useEffect, useRef } from 'react';
import { Terminal, X, ShieldAlert, Cpu, User, Zap } from 'lucide-react';
import { LogEntry } from '../hooks/useMissionLog';

interface MissionLogPanelProps {
  logs: LogEntry[];
  isOpen: boolean;
  onClose: () => void;
}

export const MissionLogPanel: React.FC<MissionLogPanelProps> = ({ logs, isOpen, onClose }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs, isOpen]);

  const getIcon = (type: string) => {
    switch (type) {
      case 'WARNING': return <ShieldAlert className="w-3 h-3 text-red-500" />;
      case 'SYSTEM': return <Cpu className="w-3 h-3 text-cyan-500" />;
      case 'USER': return <User className="w-3 h-3 text-yellow-500" />;
      case 'AI': return <Zap className="w-3 h-3 text-blue-400" />;
      default: return <Terminal className="w-3 h-3 text-neutral-500" />;
    }
  };

  const getColor = (type: string) => {
    switch (type) {
      case 'WARNING': return 'text-red-400 border-red-500/20 bg-red-500/5';
      case 'SYSTEM': return 'text-cyan-400 border-cyan-500/20 bg-cyan-500/5';
      case 'USER': return 'text-yellow-400 border-yellow-500/20 bg-yellow-500/5';
      case 'AI': return 'text-blue-400 border-blue-500/20 bg-blue-500/5';
      default: return 'text-neutral-400 border-neutral-500/20 bg-neutral-500/5';
    }
  };

  return (
    <div className={`absolute right-0 top-0 bottom-0 w-80 bg-black/80 backdrop-blur-md border-l border-cyan-500/30 shadow-[-10px_0_30px_rgba(6,182,212,0.1)] z-50 flex flex-col font-mono transform transition-transform duration-300 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
      {/* Header */}
      <div className="p-4 border-b border-cyan-500/30 flex justify-between items-center bg-cyan-900/20">
        <div className="flex items-center gap-2 text-cyan-400">
          <Terminal className="w-4 h-4" />
          <span className="text-xs font-bold tracking-widest uppercase">Mission Log</span>
        </div>
        <button onClick={onClose} className="text-cyan-500 hover:text-cyan-300 transition-colors">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Log Stream */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 flex flex-col gap-2 custom-scrollbar">
        {logs.length === 0 ? (
          <div className="text-xs text-cyan-500/50 text-center mt-4 uppercase tracking-widest">
            Log empty. Awaiting events.
          </div>
        ) : (
          logs.map((log) => (
            <div key={log.id} className={`p-2 rounded border text-xs flex flex-col gap-1 ${getColor(log.type)}`}>
              <div className="flex items-center gap-2 opacity-80">
                {getIcon(log.type)}
                <span className="text-[10px] tracking-widest">{log.time}</span>
                <span className="text-[10px] uppercase font-bold ml-auto">{log.type}</span>
              </div>
              <div className="pl-5 break-words">
                {log.message}
              </div>
            </div>
          ))
        )}
      </div>
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(0, 0, 0, 0.2);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(6, 182, 212, 0.3);
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(6, 182, 212, 0.6);
        }
      `}</style>
    </div>
  );
};
