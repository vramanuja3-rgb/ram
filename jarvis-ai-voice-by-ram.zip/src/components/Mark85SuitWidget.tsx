import React from 'react';
import { Settings, Mic, MicOff, Zap, Shield, Crosshair, Activity, Cpu } from 'lucide-react';
import { JarvisWaveform } from './JarvisWaveform';
import { ArcReactor } from './ArcReactor';
import { SystemStatusWidget } from './SystemStatusWidget';
import { GeoLocationHUDWidget } from './GeoLocationHUDWidget';
import { MissionLogPanel } from './MissionLogPanel';
import { useMissionLog } from '../hooks/useMissionLog';
import { FileText } from 'lucide-react';
import { useGestureDetection } from '../hooks/useGestureDetection';

interface Mark85SuitWidgetProps {
  coreState: string;
  isListening: boolean;
  isSpeaking: boolean;
  onToggleListen: () => void;
  onOpenSettings: () => void;
  transcript: string;
}

export const Mark85SuitWidget: React.FC<Mark85SuitWidgetProps> = ({

  coreState,
  isListening,
  isSpeaking,
  onToggleListen,
  onOpenSettings,
  transcript
}) => {
  const isScanning = useGestureDetection(2000, 3000);
  const [isLogOpen, setIsLogOpen] = React.useState(false);
  const { logs, addLog } = useMissionLog();

  // Auto-log effects
  React.useEffect(() => { addLog('SYSTEM', 'HUD Initialized. Awaiting directives.'); }, []);
  React.useEffect(() => { if (transcript && transcript !== '[VAD: Analyzing ambient noise...]') addLog('USER', transcript); }, [transcript]);
  React.useEffect(() => { if (coreState !== 'IDLE') addLog('SYSTEM', `Core State Shift: ${coreState}`); }, [coreState]);
  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center relative overflow-hidden font-sans text-neutral-100">
      

      {/* Gesture Scan Overlay */}
      <style>{`
        @keyframes hud-scan {
          0% { transform: translateY(-10vh); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translateY(110vh); opacity: 0; }
        }
        .animate-hud-scan {
          animation: hud-scan 1.5s cubic-bezier(0.4, 0, 0.2, 1) forwards;
        }

      `}</style>

      {isScanning && (
        <div className="absolute inset-0 pointer-events-none z-50 overflow-hidden flex flex-col">
          <div className="w-full h-1 bg-cyan-400 shadow-[0_0_30px_10px_rgba(6,182,212,0.6)] animate-hud-scan relative">
             {/* Scan trail */}
             <div className="absolute bottom-full left-0 w-full h-32 bg-gradient-to-t from-cyan-500/20 to-transparent" />
          </div>
        </div>
      )}

      {/* Background Grid & Hexagons */}
      <div className="absolute inset-0 z-0 opacity-20" style={{
        backgroundImage: `linear-gradient(rgba(6,182,212,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(6,182,212,0.1) 1px, transparent 1px)`,
        backgroundSize: '40px 40px',
        backgroundPosition: 'center center'
      }} />

      {/* Settings Button */}
      <button 
        onClick={onOpenSettings}
        className="absolute top-6 right-6 p-2 rounded-full bg-neutral-900/50 hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors z-50"
      >
        <Settings className="w-5 h-5" />
      </button>

      {/* Main Suit Dashboard */}
      <div className="w-full max-w-7xl px-8 flex flex-col lg:flex-row items-center justify-between gap-12 z-10">
        
        {/* Left Panel: Systems Diagnostics */}
        <div className="flex flex-col gap-6 w-80">
          <div className="text-xs font-bold tracking-[0.3em] uppercase text-cyan-400 border-b border-cyan-500/30 pb-2 flex items-center justify-between">
            <span>Armor Diagnostics</span>
            <Shield className="w-4 h-4" />
          </div>

          {/* Stat Bars */}
          <div className="space-y-4">
            {[
              { label: 'Nanotech Integrity', value: 98, icon: <Cpu className="w-4 h-4" /> },
              { label: 'Life Support', value: 100, icon: <Activity className="w-4 h-4" /> },
              { label: 'Targeting Systems', value: 85, icon: <Crosshair className="w-4 h-4" /> },
              { label: 'Repulsor Output', value: 92, icon: <Zap className="w-4 h-4" /> }
            ].map((stat) => (
              <div key={stat.label} className="flex flex-col gap-1">
                <div className="flex justify-between text-xs font-medium uppercase tracking-wider text-neutral-400">
                  <span className="flex items-center gap-2">{stat.icon} {stat.label}</span>
                  <span className="text-cyan-500">{stat.value}%</span>
                </div>
                <div className="w-full h-1.5 bg-neutral-900 rounded-full overflow-hidden border border-cyan-500/10">
                  <div 
                    className="h-full bg-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.8)] transition-all duration-1000" 
                    style={{ width: `${stat.value}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 p-4 bg-cyan-500/5 border border-cyan-500/20 rounded-lg">
            <div className="text-xs text-cyan-400 font-mono tracking-widest uppercase mb-2">Mark VI Status</div>
            <div className="text-sm text-neutral-300">
              Nanoparticle shielding active. Flight systems nominal.
              Awaiting further directives.
            </div>
          </div>
        </div>

        {/* Center: HUD / Audio / Transcript */}
        <div className="flex-1 flex flex-col items-center justify-center gap-8 min-w-[300px]">
           
           <div className="text-2xl font-bold tracking-[0.5em] uppercase text-cyan-400 drop-shadow-[0_0_15px_rgba(6,182,212,0.5)]">
             MARK VI
           </div>

           {/* Voice Waveform */}
           <div className="w-full h-32 mix-blend-screen my-8 border-y border-cyan-500/20 py-4 relative">
              <div className="absolute inset-0 bg-cyan-500/5 animate-pulse" />
              <JarvisWaveform
                  isActive={isListening || isSpeaking || coreState === 'THINKING'}
                 isListening={isListening}
                 isSpeaking={isSpeaking}
              />
           </div>
           
           {/* Status Label */}
           <div className="flex flex-col items-center gap-2">
              <div className="text-xs font-medium uppercase tracking-[0.2em] text-neutral-500">
                 {coreState === 'IDLE' ? 'System Standby' :
                  coreState === 'LISTENING' ? 'Audio Matrix Active' :
                  coreState === 'THINKING' ? 'Processing Directives' :
                  coreState === 'SPEAKING' ? 'Transmitting' :
                  coreState === 'ERROR' ? 'System Error' : 'System Standby'}
              </div>
              
              <div className="h-12 flex items-center justify-center">
                {transcript ? (
                   <div className="text-sm text-cyan-400 max-w-md text-center font-mono italic">
                      &gt; {transcript}
                   </div>
                ) : (
                   <div className="text-sm text-neutral-600 max-w-md text-center font-mono">
                      &gt; _
                   </div>
                )}
              </div>
           </div>
        </div>

        {/* Right Side: Arc Reactor */}
        <div className="flex flex-col gap-6 w-80 items-center">
           <div className="text-xs font-bold tracking-[0.3em] uppercase text-cyan-400 border-b border-cyan-500/30 pb-2 w-full text-center">
              RT Core Power
           </div>
           
           <div className="relative w-64 h-64 flex items-center justify-center mt-4">
              {/* Energy field behind reactor */}
              <div className="absolute inset-0 rounded-full bg-cyan-500/20 blur-3xl animate-[pulse_2s_infinite]" />
              <div className="scale-75">
                <ArcReactor />
              </div>
           </div>

           <div className="w-full grid grid-cols-2 gap-4 mt-4">
              <div className="bg-neutral-900 border border-neutral-800 p-3 rounded flex flex-col items-center justify-center">
                 <div className="text-[10px] text-neutral-500 uppercase tracking-widest">Output</div>
                 <div className="text-cyan-400 font-mono font-bold mt-1">3.0 GJ/s</div>
              </div>
              <div className="bg-neutral-900 border border-neutral-800 p-3 rounded flex flex-col items-center justify-center">
                 <div className="text-[10px] text-neutral-500 uppercase tracking-widest">Temp</div>
                 <div className="text-cyan-400 font-mono font-bold mt-1">3,400 °C</div>
              </div>
           </div>
        </div>
      </div>

      <GeoLocationHUDWidget />
      <SystemStatusWidget />

      {/* Manual Control */}
      <div className="absolute bottom-8 flex gap-4 z-20">
        <button
          onClick={onToggleListen}
          className={`p-4 rounded-full border transition-all ${
            isListening 
              ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-500 shadow-[0_0_20px_rgba(14,165,233,0.2)]' 
              : 'bg-neutral-900 border-neutral-800 text-neutral-500 hover:text-neutral-300'
          }`}
        >
          {isListening ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
        </button>
      </div>

    </div>
  );
};
