import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Copy, Check } from 'lucide-react';
import 'katex/dist/katex.min.css';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  return (
    <div className="markdown-body prose prose-invert prose-cyan max-w-none">
      <ReactMarkdown
        remarkPlugins={[remarkGfm, remarkMath]}
        rehypePlugins={[rehypeKatex]}
        components={{
          code({ node, inline, className, children, ...props }: any) {
            const match = /language-(\w+)/.exec(className || '');
            const [isCopied, setIsCopied] = React.useState(false);

            const handleCopy = () => {
              navigator.clipboard.writeText(String(children).replace(/\n$/, ''));
              setIsCopied(true);
              setTimeout(() => setIsCopied(false), 2000);
            };

            if (!inline && match) {
              return (
                <div className="relative group rounded-md overflow-hidden my-4 border border-cyan-500/20">
                  <div className="flex items-center justify-between px-4 py-1 bg-cyan-950/40 border-b border-cyan-500/20 text-xs font-mono text-cyan-300">
                    <span>{match[1]}</span>
                    <button
                      onClick={handleCopy}
                      className="p-1 hover:bg-cyan-500/20 rounded transition-colors text-cyan-400 hover:text-cyan-200"
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  <SyntaxHighlighter
                    {...props}
                    style={vscDarkPlus as any}
                    language={match[1]}
                    PreTag="div"
                    className="!m-0 text-[13px]"
                    customStyle={{ background: 'rgba(0, 0, 0, 0.4)', padding: '1rem' }}
                  >
                    {String(children).replace(/\n$/, '')}
                  </SyntaxHighlighter>
                </div>
              );
            }
            return (
              <code {...props} className={`${className} bg-cyan-950/30 text-cyan-300 px-1.5 py-0.5 rounded text-[13px] font-mono border border-cyan-500/20`}>
                {children}
              </code>
            );
          }
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
};
