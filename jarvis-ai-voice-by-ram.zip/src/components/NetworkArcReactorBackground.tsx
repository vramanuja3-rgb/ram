import React, { useState, useEffect } from 'react';
import { Zap, Activity, Wifi, WifiOff } from 'lucide-react';

export const NetworkArcReactorBackground: React.FC = () => {
  const [networkPercent, setNetworkPercent] = useState<number>(100);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  useEffect(() => {
    const updateNetwork = () => {
      setIsOnline(navigator.onLine);
      if (!navigator.onLine) {
        setNetworkPercent(0);
        return;
      }
      
      const conn = (navigator as any).connection;
      if (conn) {
        // downlink is usually 0-10 Mbps
        const downlink = conn.downlink || 10;
        let p = (downlink / 10) * 100;
        if (p > 100) p = 100;
        if (p < 25) p = 25;
        setNetworkPercent(p);
      } else {
        // Fallback if connection API not available
        setNetworkPercent(100);
      }
    };

    updateNetwork();
    
    window.addEventListener('online', updateNetwork);
    window.addEventListener('offline', updateNetwork);
    if ((navigator as any).connection) {
      (navigator as any).connection.addEventListener('change', updateNetwork);
    }
    
    // Simulate slight fluctuations
    const interval = setInterval(() => {
      if (!navigator.onLine) return;
      setNetworkPercent(prev => {
        const conn = (navigator as any).connection;
        const base = conn ? Math.min((conn.downlink || 10) / 10 * 100, 100) : 100;
        const fluctuation = (Math.random() - 0.5) * 5; // +/- 2.5%
        let next = base + fluctuation;
        if (next > 100) next = 100;
        if (next < 25) next = 25;
        return next;
      });
    }, 2000);

    return () => {
      window.removeEventListener('online', updateNetwork);
      window.removeEventListener('offline', updateNetwork);
      if ((navigator as any).connection) {
        (navigator as any).connection.removeEventListener('change', updateNetwork);
      }
      clearInterval(interval);
    };
  }, []);

  // Determine state
  let stateColor = 'from-cyan-400 to-sky-700 border-cyan-200/80';
  let glowColor = 'shadow-[0_0_80px_rgba(6,182,212,0.6)]';
  let innerGlow = 'from-white via-cyan-400 to-sky-950 shadow-[0_0_50px_rgba(6,182,212,0.9)]';
  let speed = '18s';
  let statusText = 'HIGH';
  let textColor = 'text-cyan-400';
  let pulseClass = 'arc-pulse';

  if (!isOnline) {
    stateColor = 'from-red-600 to-red-900 border-red-500/80';
    glowColor = 'shadow-[0_0_20px_rgba(239,68,68,0.3)]';
    innerGlow = 'from-neutral-400 via-red-900 to-black shadow-[0_0_10px_rgba(239,68,68,0.5)]';
    speed = '60s';
    statusText = 'OFFLINE';
    textColor = 'text-red-500';
    pulseClass = '';
  } else if (networkPercent >= 75) {
    statusText = 'HIGH (75-100%)';
    speed = '12s';
  } else if (networkPercent >= 50) {
    stateColor = 'from-amber-400 to-orange-700 border-amber-200/80';
    glowColor = 'shadow-[0_0_60px_rgba(245,158,11,0.5)]';
    innerGlow = 'from-white via-amber-400 to-orange-950 shadow-[0_0_40px_rgba(245,158,11,0.7)]';
    statusText = 'MEDIUM (50-74%)';
    textColor = 'text-amber-400';
    speed = '20s';
  } else {
    stateColor = 'from-rose-500 to-red-800 border-rose-300/80';
    glowColor = 'shadow-[0_0_40px_rgba(244,63,94,0.4)]';
    innerGlow = 'from-rose-100 via-rose-500 to-red-950 shadow-[0_0_30px_rgba(244,63,94,0.6)]';
    statusText = 'LOW (25-49%)';
    textColor = 'text-rose-400';
    speed = '30s';
  }

  return (
    <div className="fixed inset-0 pointer-events-none z-0 flex items-center justify-center overflow-hidden opacity-25 mix-blend-screen">
      <div className={`relative flex items-center justify-center w-[800px] h-[800px] rounded-full ${glowColor} transition-all duration-1000`}>
        
        {/* Network Status Text floating near reactor */}
        <div className={`absolute top-[65%] flex flex-col items-center gap-1 font-orbitron font-bold tracking-widest ${textColor} transition-colors duration-1000 opacity-70`}>
          {isOnline ? <Wifi className="w-8 h-8" /> : <WifiOff className="w-8 h-8" />}
          <div className="text-xl">NETWORK UPLINK: {statusText}</div>
          {isOnline && <div className="text-sm font-mono-tech">{networkPercent.toFixed(1)}% SIGNAL</div>}
        </div>

        {/* Outer ring with notches */}
        <div className="absolute inset-0 rounded-full border border-current opacity-20 border-dashed animate-spin" style={{ animationDuration: '60s' }} />
        <div className="absolute inset-10 rounded-full border-2 border-current opacity-10" />

        {/* Magnetic Ring Coils */}
        <div
          className="absolute inset-20 rounded-full transition-transform animate-spin"
          style={{ animationDuration: speed }}
        >
          {Array.from({ length: 12 }).map((_, i) => (
            <div
              key={i}
              className={`absolute top-1/2 left-1/2 w-8 h-12 -ml-4 -mt-6 bg-gradient-to-b ${stateColor} border rounded-sm shadow-sm opacity-80`}
              style={{
                transform: `rotate(${i * 30}deg) translateY(-300px)`,
              }}
            />
          ))}
        </div>

        {/* Middle Triangle Stabilizer / Magnetic Flux Ring */}
        <div
          className="absolute inset-32 rounded-full border-4 border-dashed border-current opacity-30 animate-spin"
          style={{ animationDuration: '40s', animationDirection: 'reverse' }}
        />

        {/* Glowing Arc Core */}
        <div className={`relative w-[300px] h-[300px] rounded-full flex items-center justify-center bg-radial ${innerGlow} ${pulseClass} transition-all duration-1000`}>
          {/* Triangular internal lattice */}
          <div className="w-[180px] h-[180px] border-4 border-white/60 rotate-45 flex items-center justify-center">
            <div className="w-[120px] h-[120px] border-2 border-white/40 rotate-45 bg-white/10 backdrop-blur-md flex items-center justify-center">
              <Activity className="w-16 h-16 text-white/80 animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
