import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initSelfRepairMonitor, SelfRepairErrorBoundary } from './utils/selfRepair';

// Initialize global error monitoring for AI diagnostics
initSelfRepairMonitor();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <SelfRepairErrorBoundary>
      <App />
    </SelfRepairErrorBoundary>
  </StrictMode>,
);
