import React, { Component, ErrorInfo, ReactNode } from 'react';

const DIAGNOSTIC_PREFIX = '[AI_SELF_REPAIR_DIAGNOSTIC]';

/**
 * Initializes global event listeners to catch and format uncaught errors
 * and unhandled promise rejections for AI agent diagnosis.
 */
export function initSelfRepairMonitor() {
  if (typeof window === 'undefined') return;

  window.addEventListener('error', (event) => {
    console.error(`${DIAGNOSTIC_PREFIX} Uncaught Error:`, {
      message: event.message,
      filename: event.filename,
      lineno: event.lineno,
      colno: event.colno,
      error: event.error?.stack || event.error,
    });
  });

  window.addEventListener('unhandledrejection', (event) => {
    console.error(`${DIAGNOSTIC_PREFIX} Unhandled Promise Rejection:`, {
      reason: event.reason?.stack || event.reason,
    });
  });
}

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

/**
 * A React Error Boundary that catches component tree crashes,
 * prevents the entire app from white-screening, and logs the
 * stack trace with the diagnostic prefix.
 */
export class SelfRepairErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error(`${DIAGNOSTIC_PREFIX} React Component Error:`, {
      error: error.stack || error.toString(),
      componentStack: errorInfo.componentStack,
    });
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-black text-red-500 flex flex-col items-center justify-center p-8 font-mono">
          <h1 className="text-2xl font-bold mb-4 tracking-widest uppercase">System Malfunction Detected</h1>
          <p className="mb-4 text-neutral-400">The self-repair monitor has caught a fatal render error.</p>
          <div className="bg-neutral-900 p-4 rounded text-sm w-full max-w-2xl overflow-auto border border-red-900 shadow-[0_0_20px_rgba(220,38,38,0.2)]">
            <pre className="whitespace-pre-wrap">{this.state.error?.toString()}</pre>
          </div>
          <button 
            className="mt-8 px-6 py-2 border border-red-900/50 hover:bg-red-900/20 text-red-400 rounded transition-colors uppercase tracking-widest text-sm font-bold"
            onClick={() => window.location.reload()}
          >
            Reboot System
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
