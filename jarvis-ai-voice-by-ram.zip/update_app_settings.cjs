const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

const settingsState = `  const [settings, setSettings] = useState<any>({
    assistantName: 'JARVIS',
    userName: 'Sir',
    personality: 'Professional, intelligent, and slightly witty AI assistant.',
    responseLength: 'normal',
    voiceEnabled: true,
    voiceSelection: 'en-US-Journey-F',
    speechSpeed: 1,
    theme: 'jarvis',
    wakeWordEnabled: true,
    memoryEnabled: true
  });`;

content = content.replace('const [showSettings, setShowSettings] = useState(false);', \`const [showSettings, setShowSettings] = useState(false);\n\${settingsState}\`);

content = content.replace('<SettingsPanel isOpen={showSettings} onClose={() => setShowSettings(false)} />', '<SettingsPanel isOpen={showSettings} onClose={() => setShowSettings(false)} settings={settings} onUpdateSettings={setSettings} />');

fs.writeFileSync('src/App.tsx', content);
