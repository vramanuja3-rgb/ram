const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');
code = code.replace(
  'server: { middlewareMode: true, hmr: { server } },',
  'server: { middlewareMode: true, hmr: process.env.DISABLE_HMR === "true" ? false : { server } },'
);
fs.writeFileSync('server.ts', code);
