const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Add refs for state to fix stale closures
content = content.replace(
  'const [isAwake, setIsAwake] = useState(false);',
  'const [isAwake, setIsAwake] = useState(false);\n  const isAwakeRef = useRef(false);\n  const wakeWordEnabledRef = useRef(settings.wakeWordEnabled);'
);

// Update wakeWordEnabledRef when settings change
const settingsEffect = `
  useEffect(() => {
    wakeWordEnabledRef.current = settings.wakeWordEnabled;
  }, [settings.wakeWordEnabled]);
`;

content = content.replace('useEffect(() => {', settingsEffect + '\n  useEffect(() => {');

// Fix the logic in onresult
const newOnResult = `
      recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        
        setInterimTranscript(interim);

        if (final) {
          const transcript = final.trim();
          const lower = transcript.toLowerCase();
          
          if (lower.includes('jarvis') || lower.includes('hey jarvis')) {
             const command = lower.split('jarvis')[1]?.trim() || transcript.replace(/^(hey )?jarvis[, ]*/i, '').trim();
             if (command) {
                isAwakeRef.current = false;
                handleVoiceCommand(command);
             } else {
                soundEffects.playChirp();
                isAwakeRef.current = true;
             }
          } else if (isAwakeRef.current || !wakeWordEnabledRef.current) {
             isAwakeRef.current = false;
             handleVoiceCommand(transcript);
          }
        }
      };
`;

content = content.replace(/recognition\.onresult = \(event: any\) => \{[\s\S]*?^\s*\};\n/m, newOnResult);

fs.writeFileSync('src/App.tsx', content);
