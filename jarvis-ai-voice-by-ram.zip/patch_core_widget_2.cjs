const fs = require('fs');

const content = `import React from 'react';
import { Settings, Mic, MicOff, Power, Brain } from 'lucide-react';
import { JarvisWaveform } from './JarvisWaveform';

interface JarvisCoreWidgetProps {
  coreState: string;
  isListening: boolean;
  isSpeaking: boolean;
  onToggleListen: () => void;
  onOpenSettings: () => void;
  transcript: string;
}

export const JarvisCoreWidget: React.FC<JarvisCoreWidgetProps> = ({
  coreState,
  isListening,
  isSpeaking,
  onToggleListen,
  onOpenSettings,
  transcript
}) => {
  return (
    <div className="min-h-screen bg-neutral-950 flex flex-col items-center justify-center relative overflow-hidden font-sans text-neutral-100">
      
      {/* Settings Button */}
      <button 
        onClick={onOpenSettings}
        className="absolute top-6 right-6 p-2 rounded-full bg-neutral-900/50 hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors z-50"
      >
        <Settings className="w-5 h-5" />
      </button>

      {/* Main Orb / Visualizer */}
      <div className="relative w-80 h-80 flex items-center justify-center">
        
        {/* Glow effects based on state */}
        <div className={\`absolute inset-0 rounded-full blur-3xl transition-opacity duration-1000 \${
           isSpeaking ? 'bg-yellow-400/30 opacity-100' :
           isListening ? 'bg-yellow-500/20 opacity-100' :
           coreState === 'THINKING' ? 'bg-yellow-300/30 opacity-100' :
           coreState === 'ERROR' ? 'bg-red-500/20 opacity-100' :
           'bg-yellow-600/5 opacity-50'
        }\`} />

        {/* Arc Reactor Rings (Yellow) */}
        <div className="absolute w-72 h-72 rounded-full border-4 border-dashed border-yellow-500/40 animate-[spin_12s_linear_infinite]" />
        <div className="absolute w-56 h-56 rounded-full border-2 border-yellow-400/30 animate-[spin_15s_linear_infinite_reverse]" />
        <div className="absolute w-40 h-40 rounded-full bg-yellow-500/20 blur-xl animate-pulse" />
        
        {/* Rotating Brain */}
        <div className="absolute flex items-center justify-center">
          <Brain className="w-20 h-20 text-yellow-400/80 animate-[spin_8s_linear_infinite]" />
        </div>

        {/* The Waveform overlaid in the center */}
        <div className="absolute inset-0 flex items-center justify-center mix-blend-screen drop-shadow-[0_0_10px_rgba(253,224,71,0.8)]">
           <div className="w-full h-24">
             <JarvisWaveform 
                isActive={isListening || isSpeaking || coreState === 'THINKING'}
                isListening={isListening}
                isSpeaking={isSpeaking}
             />
           </div>
        </div>
      </div>

      {/* Status Label */}
      <div className="mt-12 flex flex-col items-center gap-2 z-10">
         <div className="text-xs font-medium uppercase tracking-[0.2em] text-neutral-500">
            {coreState === 'IDLE' ? 'System Standby' :
             coreState === 'LISTENING' ? 'Awaiting Input' :
             coreState === 'THINKING' ? 'Processing' :
             coreState === 'SPEAKING' ? 'Transmitting' :
             coreState === 'ERROR' ? 'System Error' : 'System Standby'}
         </div>
         {transcript && (
            <div className="text-sm text-neutral-400 max-w-md text-center italic">
               "{transcript}"
            </div>
         )}
      </div>

      {/* Manual Control (Emergency / Override) */}
      <div className="absolute bottom-8 flex gap-4 z-10">
        <button
          onClick={onToggleListen}
          className={\`p-4 rounded-full border transition-all \${
            isListening 
              ? 'bg-yellow-500/10 border-yellow-500/30 text-yellow-500 shadow-[0_0_20px_rgba(234,179,8,0.2)]' 
              : 'bg-neutral-900 border-neutral-800 text-neutral-500 hover:text-neutral-300'
          }\`}
        >
          {isListening ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
        </button>
      </div>

    </div>
  );
};
`;

fs.writeFileSync('src/components/JarvisCoreWidget.tsx', content);
