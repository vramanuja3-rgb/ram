const fs = require('fs');
let content = fs.readFileSync('src/components/Mark85SuitWidget.tsx', 'utf8');

// Add imports
if (!content.includes('MissionLogPanel')) {
  content = content.replace(
    "import { ThreatDetectionWidget } from './ThreatDetectionWidget';",
    "import { ThreatDetectionWidget } from './ThreatDetectionWidget';\nimport { MissionLogPanel } from './MissionLogPanel';\nimport { useMissionLog } from '../hooks/useMissionLog';\nimport { FileText } from 'lucide-react';"
  );
}

// Add state and hooks
if (!content.includes('useMissionLog()')) {
  content = content.replace(
    "  const [isCombatMode, setIsCombatMode] = React.useState(false);",
    "  const [isCombatMode, setIsCombatMode] = React.useState(false);\n  const [isLogOpen, setIsLogOpen] = React.useState(false);\n  const { logs, addLog } = useMissionLog();\n\n  // Auto-log effects\n  React.useEffect(() => { addLog('SYSTEM', 'HUD Initialized. Awaiting directives.'); }, []);\n  React.useEffect(() => { if (transcript && transcript !== '[VAD: Analyzing ambient noise...]') addLog('USER', transcript); }, [transcript]);\n  React.useEffect(() => { if (isCombatMode) addLog('WARNING', 'THREAT DETECTED: Combat Mode Engaged'); else addLog('SYSTEM', 'Combat Mode Disengaged'); }, [isCombatMode]);\n  React.useEffect(() => { if (coreState !== 'IDLE') addLog('SYSTEM', `Core State Shift: ${coreState}`); }, [coreState]);"
  );
}

// Add UI Elements
if (!content.includes('<MissionLogPanel')) {
  content = content.replace(
    "      {/* Manual Control Toggle for Threat Sensors */}",
    `      {/* Mission Log Toggle Button */}
      <button 
        onClick={() => setIsLogOpen(true)}
        className="absolute top-20 right-6 p-2 rounded-full bg-neutral-900/50 hover:bg-neutral-800 text-cyan-400 hover:text-cyan-300 transition-colors z-40 border border-cyan-500/20"
      >
        <FileText className="w-5 h-5" />
      </button>

      <MissionLogPanel logs={logs} isOpen={isLogOpen} onClose={() => setIsLogOpen(false)} />

      {/* Manual Control Toggle for Threat Sensors */}`
  );
}

fs.writeFileSync('src/components/Mark85SuitWidget.tsx', content);
