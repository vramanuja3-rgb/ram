export interface SmartDevice {
  id: string;
  name: string;
  room: string;
  type: string;
  state: Record<string, any>;
  capabilities: string[];
}

export interface SmartHomeProvider {
  getDevices(): Promise<SmartDevice[]>;
  getDeviceState(deviceId: string): Promise<Record<string, any>>;
  controlDevice(deviceId: string, action: string, parameters: Record<string, any>): Promise<Record<string, any>>;
}

export class MockSmartHomeProvider implements SmartHomeProvider {
  private devices: SmartDevice[] = [
    {
      id: 'light-1',
      name: 'Living Room Main Light',
      room: 'Living Room',
      type: 'LIGHT',
      state: { on: false, brightness: 100 },
      capabilities: ['on', 'off', 'set_brightness']
    },
    {
      id: 'light-2',
      name: 'Bedroom Light',
      room: 'Bedroom',
      type: 'LIGHT',
      state: { on: false, brightness: 100 },
      capabilities: ['on', 'off', 'set_brightness']
    },
    {
      id: 'thermostat-1',
      name: 'Main Thermostat',
      room: 'Hallway',
      type: 'THERMOSTAT',
      state: { temperature: 72, mode: 'cool' },
      capabilities: ['set_temperature', 'set_mode']
    },
    {
      id: 'lock-1',
      name: 'Front Door Lock',
      room: 'Entryway',
      type: 'LOCK',
      state: { locked: true },
      capabilities: ['lock', 'unlock']
    }
  ];

  async getDevices(): Promise<SmartDevice[]> {
    return this.devices;
  }

  async getDeviceState(deviceId: string): Promise<Record<string, any>> {
    const device = this.devices.find(d => d.id === deviceId);
    if (!device) throw new Error(`Device not found: ${deviceId}`);
    return device.state;
  }

  async controlDevice(deviceId: string, action: string, parameters: Record<string, any>): Promise<Record<string, any>> {
    const device = this.devices.find(d => d.id === deviceId);
    if (!device) throw new Error(`Device not found: ${deviceId}`);
    
    if (action === 'on') device.state.on = true;
    else if (action === 'off') device.state.on = false;
    else if (action === 'set_brightness') device.state.brightness = parameters.brightness;
    else if (action === 'set_temperature') device.state.temperature = parameters.temperature;
    else if (action === 'set_mode') device.state.mode = parameters.mode;
    else if (action === 'lock') device.state.locked = true;
    else if (action === 'unlock') device.state.locked = false;
    else throw new Error(`Unsupported action: ${action} for device ${device.type}`);

    return device.state;
  }
}
