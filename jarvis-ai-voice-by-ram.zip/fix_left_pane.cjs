const fs = require('fs');
let content = fs.readFileSync('src/components/LegacyHUD.tsx', 'utf8');

// Find everything from {/* Left pane: Dummy Diagnostics to match the old full-screen feel */}
// up to {/* Right pane: Voice Assistant HUD */}

const startIndex = content.indexOf('{/* Left pane: Dummy Diagnostics to match the old full-screen feel */}');
const endIndex = content.indexOf('{/* Right pane: Voice Assistant HUD */}');

const newLeftPane = `{/* Left pane: Dummy Diagnostics to match the old full-screen feel */}
        <div className="hidden lg:flex flex-col w-1/3 gap-4">
           <div className="flex-1 border border-cyan-500/30 bg-cyan-950/20 rounded-xl p-4 glow-box-cyan">
              <div className="font-orbitron text-cyan-300 text-sm tracking-widest mb-4">ARC REACTOR CORE</div>
              <div className="flex items-center justify-center h-48">
                 <div className="w-32 h-32 rounded-full border-4 border-dashed border-cyan-500/40 animate-[spin_10s_linear_infinite]" />
                 <div className="absolute w-24 h-24 rounded-full border-2 border-cyan-400/20" />
                 <div className="absolute w-16 h-16 rounded-full bg-cyan-500/40 blur-md animate-pulse" />
              </div>
           </div>

           <div className="flex-1 border border-cyan-500/30 bg-cyan-950/20 rounded-xl p-4 glow-box-cyan">
              <div className="font-orbitron text-cyan-300 text-sm tracking-widest mb-4">SYSTEM TELEMETRY</div>
              <div className="space-y-4 font-mono text-sm text-cyan-400">
                <div>
                  <div className="flex justify-between mb-1">
                    <span>CPU NEURAL NET</span>
                    <span>87%</span>
                  </div>
                  <div className="h-1 bg-cyan-400/20"><div className="h-full bg-cyan-400 w-[87%] shadow-[0_0_8px_rgba(34,211,238,0.8)]" /></div>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span>MEMORY ALLOCATION</span>
                    <span>42%</span>
                  </div>
                  <div className="h-1 bg-cyan-400/20"><div className="h-full bg-cyan-400 w-[42%]" /></div>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span>GLOBAL NETWORK</span>
                    <span>UPLINKED</span>
                  </div>
                  <div className="h-1 bg-cyan-400/20"><div className="h-full bg-cyan-400 w-full" /></div>
                </div>
              </div>
           </div>
           
           <div className="flex-1 border border-cyan-500/30 bg-cyan-950/20 rounded-xl p-4 glow-box-cyan flex flex-col">
              <div className="font-orbitron text-cyan-300 text-sm tracking-widest mb-4">HOME AUTOMATION</div>
              <div className="space-y-4 font-mono text-sm text-cyan-400 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between mb-1">
                    <span>LIVING ROOM LIGHTS</span>
                    <span className="text-green-400">ONLINE</span>
                  </div>
                  <div className="h-1 bg-cyan-400/20"><div className="h-full bg-green-400 w-full shadow-[0_0_8px_rgba(74,222,128,0.8)]" /></div>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span>NEST THERMOSTAT</span>
                    <span className="text-amber-400">72°F AUTO</span>
                  </div>
                  <div className="h-1 bg-cyan-400/20"><div className="h-full bg-amber-400 w-[60%] shadow-[0_0_8px_rgba(251,191,36,0.8)]" /></div>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span>ECHO SPEAKERS</span>
                    <span className="text-cyan-400">STANDBY</span>
                  </div>
                  <div className="h-1 bg-cyan-400/20"><div className="h-full bg-cyan-400 w-[10%]" /></div>
                </div>
              </div>
           </div>
        </div>

        `;

content = content.substring(0, startIndex) + newLeftPane + content.substring(endIndex);

fs.writeFileSync('src/components/LegacyHUD.tsx', content);
