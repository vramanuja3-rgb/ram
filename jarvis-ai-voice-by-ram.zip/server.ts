import express from "express";
import path from "path";
import http from "http";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import { MockSmartHomeProvider } from "./server/smartHome";

const app = express();
const PORT = 3000;
app.use(express.json({ limit: '50mb' }));

const smartHome = new MockSmartHomeProvider();

function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY environment variable is missing.");
  return new GoogleGenAI({ apiKey });
}

// Map the generic properties since Type from genai doesn't export deeply in all versions sometimes
const genaiTools = [{
  functionDeclarations: [
    {
      name: "get_devices",
      description: "Get a list of all connected smart home devices, their IDs, capabilities, and current state.",
    },
    {
      name: "control_device",
      description: "Control a smart home device. Use this to turn things on/off, change temperature, or lock doors.",
      parameters: {
        type: Type.OBJECT,
        properties: {
          deviceId: { type: Type.STRING, description: "The ID of the device to control." },
          action: { type: Type.STRING, description: "The action to perform: 'on', 'off', 'set_brightness', 'set_temperature', 'lock', 'unlock'." },
          value: { type: Type.NUMBER, description: "The numerical value if setting brightness or temperature." }
        },
        required: ["deviceId", "action"]
      }
    }
  ]
}];

app.post("/api/jarvis/assistant", async (req, res) => {
  try {
    const { prompt, files, history, settings, memories } = req.body;
    
    if (!prompt && (!files || files.length === 0)) {
      return res.status(400).json({ error: "Missing prompt or files." });
    }

    const ai = getGeminiClient();
    
    let systemInstruction = `You are a highly advanced personal AI assistant named JARVIS.
You have administrative access to the user's smart home network via tool calls.
You MUST use the provided tools to interact with devices. 
Do NOT pretend to do something. If asked to turn off lights, you must call control_device.
After calling a tool, use the result to confidently confirm the action to the user (e.g., "The living room lights have been turned off.").
Keep responses concise, natural, and conversational. Do not output markdown lists unless asked.
Memory Context:
${(memories || []).map((m: string) => "- " + m).join('\n')}`;

    const contents: any[] = [];
    
    if (history && history.length > 0) {
      for (const msg of history) {
        if (msg.role && msg.text) {
          contents.push({
            role: msg.role === 'model' ? 'model' : 'user',
            parts: [{ text: msg.text }]
          });
        }
      }
    }

    const parts: any[] = [];
    if (files && files.length > 0) {
      for (const f of files) {
        if (f.data && f.type) {
          parts.push({ inlineData: { data: f.data, mimeType: f.type } });
        }
      }
    }
    if (prompt) {
      parts.push({ text: prompt });
    }
    contents.push({ role: 'user', parts });

    // Function calling loop
    let keepRunning = true;
    let finalResponse = "";

    while (keepRunning) {
      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents,
        config: {
          systemInstruction,
          temperature: 0.7,
          tools: genaiTools
        }
      });

      const functionCalls = response.functionCalls;
      
      if (functionCalls && functionCalls.length > 0) {
        // AI decided to call a tool
        // Add the AI's tool request to history
        contents.push({
           role: 'model',
           parts: functionCalls.map(fc => ({ functionCall: fc }))
        });

        const functionResponses = [];
        
        for (const call of functionCalls) {
          try {
            if (call.name === 'get_devices') {
              const devices = await smartHome.getDevices();
              functionResponses.push({
                name: call.name,
                response: { devices }
              });
            } else if (call.name === 'control_device') {
              const { deviceId, action, value } = call.args;
              const params: any = {};
              if (action === 'set_brightness') params.brightness = value;
              if (action === 'set_temperature') params.temperature = value;
              
              const newState = await smartHome.controlDevice(deviceId, action, params);
              functionResponses.push({
                name: call.name,
                response: { status: 'success', deviceId, newState }
              });
            } else {
               functionResponses.push({
                name: call.name,
                response: { error: 'Unknown function' }
              });
            }
          } catch (e: any) {
            functionResponses.push({
              name: call.name,
              response: { error: e.message }
            });
          }
        }
        
        // Return function results back to the model
        contents.push({
          role: 'user',
          parts: functionResponses.map(fr => ({ functionResponse: fr }))
        });
        
      } else {
        finalResponse = response.text || "";
        keepRunning = false;
      }
    }

    res.json({ text: finalResponse });

  } catch (err: any) {
    console.error("AI Error:", err);
    res.status(500).json({ error: "System encountered an anomaly.", details: err.message });
  }
});

async function startServer() {
  const server = http.createServer(app);
  let vite;
  if (process.env.NODE_ENV !== "production") {
    vite = await createViteServer({
      server: { middlewareMode: true, hmr: { server, clientPort: process.env.APP_URL ? 443 : undefined } },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }
  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Command Center listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
