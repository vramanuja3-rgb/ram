const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Replace TacticalHUD import with LegacyHUD
content = content.replace("import { TacticalHUD } from './components/TacticalHUD';", "import { LegacyHUD } from './components/LegacyHUD';");

// Update speech logic to handle interim transcripts and wake word continuous listening
const newSpeechLogic = `
  const [interimTranscript, setInterimTranscript] = useState('');
  const [isAwake, setIsAwake] = useState(false);
  const recognitionRef = useRef<any>(null);
  const autoRestartRef = useRef<boolean>(false);

  useEffect(() => {
    // Load state from local storage
    const storedSettings = localStorage.getItem('jarvis_settings');
    if (storedSettings) setSettings(JSON.parse(storedSettings));
    const storedSessions = localStorage.getItem('jarvis_sessions');
    if (storedSessions) setSessions(JSON.parse(storedSessions));
    const storedMemories = localStorage.getItem('jarvis_memories');
    if (storedMemories) setMemories(JSON.parse(storedMemories));

    // Boot sequence
    setTimeout(() => setBooting(false), 2000);

    // Setup speech recognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        
        setInterimTranscript(interim);

        if (final) {
          const transcript = final.trim();
          const lower = transcript.toLowerCase();
          
          if (lower.includes('jarvis') || lower.includes('hey jarvis')) {
             const command = lower.split('jarvis')[1]?.trim() || transcript.replace(/^(hey )?jarvis[, ]*/i, '').trim();
             if (command) {
                // Sent command immediately after wake word
                handleVoiceCommand(command);
             } else {
                // Woke up but no command, play chirp and wait
                playChirp();
                setCoreState('LISTENING');
             }
          } else if (coreState === 'LISTENING' || !settings.wakeWordEnabled) {
             // If we were already listening specifically or wake word is off
             handleVoiceCommand(transcript);
          }
        }
      };

      recognition.onerror = (event: any) => {
        if (event.error !== 'no-speech') {
          setIsListening(false);
          autoRestartRef.current = false;
        }
      };

      recognition.onend = () => {
        if (autoRestartRef.current) {
          try {
            recognition.start();
          } catch (e) {}
        } else {
          setIsListening(false);
          if (coreState === 'LISTENING') setCoreState('IDLE');
        }
      };

      recognitionRef.current = recognition;
    }
  }, []); // Note: settings is read from ref if needed, or we just rely on latest state in the handler
`;

content = content.replace(/const \[isListening, setIsListening\] = useState\(false\);[\s\S]*?\}, \[\]\);/, newSpeechLogic);

// Ensure settings logic handles stale closures if needed (will do a simple fix by adding a handler outside useEffect)
const newHandler = `
  const handleVoiceCommand = (text: string) => {
    if (view !== 'chat' && view !== 'tactical') setView('chat');
    if (!currentSessionId) {
       // Create session logic is tied to state, we should let the main handleSendMessage deal with it
       handleSendMessage(text, []);
    } else {
       handleSendMessage(text, []);
    }
  };
`;

content = content.replace('const handleSendMessage = async', newHandler + '\n  const handleSendMessage = async');

// Update TacticalHUD render
const newTacticalRender = `        {view === 'tactical' && (
          <div className="flex-1 absolute inset-0 z-50 bg-black">
            <LegacyHUD 
              messages={currentSession?.messages || []}
              isListening={isListening}
              isSpeaking={coreState === 'SPEAKING'}
              transcript={""}
              interimTranscript={interimTranscript}
              onToggleListening={toggleListen}
              onSendMessage={(msg) => handleSendMessage(msg, [])}
              isAiProcessing={isAiProcessing}
              soundEnabled={settings.voiceEnabled}
              onToggleSound={() => setSettings(s => ({ ...s, voiceEnabled: !s.voiceEnabled }))}
              jarvisVoiceEnabled={settings.voiceEnabled}
              onToggleJarvisVoice={() => setSettings(s => ({ ...s, voiceEnabled: !s.voiceEnabled }))}
              onNavigate={setView}
            />
          </div>
        )}`;

content = content.replace(/\{view === 'tactical'[\s\S]*?<\/div>\n\s*\)\}/, newTacticalRender);

// Update toggleListen to manage autoRestartRef
content = content.replace(
  'const toggleListen = () => {',
  `const toggleListen = () => {
    if (!recognitionRef.current) {
      alert("Microphone access is required or unsupported by this browser.");
      return;
    }
    if (isListening) {
      autoRestartRef.current = false;
      recognitionRef.current.stop();
    } else {
      autoRestartRef.current = true; // Siri mode stays on
      try { recognitionRef.current.start(); } catch(e) {}
    }`
);

content = content.replace(/if \(isListening\) \{\n\s*recognitionRef.current.stop\(\);\n\s*\} else \{\n\s*recognitionRef.current.start\(\);\n\s*\}/, ""); // Clean up original

fs.writeFileSync('src/App.tsx', content);
