const fs = require('fs');

const code = `import React, { useRef, useEffect } from 'react';
import * as d3 from 'd3';

interface JarvisWaveformProps {
  isActive: boolean;
  isListening: boolean;
  isSpeaking: boolean;
}

export const JarvisWaveform: React.FC<JarvisWaveformProps> = ({ isActive, isListening, isSpeaking }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const dataRef = useRef<number[]>(Array(64).fill(2));
  const animationRef = useRef<number | null>(null);

  // Web Audio API refs
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    let active = true;
    if (isListening && !streamRef.current) {
      navigator.mediaDevices.getUserMedia({ audio: true })
        .then(stream => {
          if (!active) return;
          const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
          if (!AudioContextClass) return;
          
          const audioCtx = new AudioContextClass();
          const analyser = audioCtx.createAnalyser();
          analyser.fftSize = 256;
          
          const source = audioCtx.createMediaStreamSource(stream);
          source.connect(analyser);
          
          audioCtxRef.current = audioCtx;
          analyserRef.current = analyser;
          sourceRef.current = source;
          streamRef.current = stream;
        })
        .catch(err => {
          console.warn("Could not start microphone for visualizer", err);
        });
    } else if (!isListening && streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
      if (audioCtxRef.current) {
        audioCtxRef.current.close();
        audioCtxRef.current = null;
      }
      analyserRef.current = null;
      sourceRef.current = null;
    }
    return () => {
      active = false;
    };
  }, [isListening]);

  useEffect(() => {
    if (!svgRef.current) return;
    const svg = d3.select(svgRef.current);
    const width = 300;
    const height = 80;
    const numBins = 64;
    
    svg.selectAll('*').remove();
    
    const xScale = d3.scaleLinear().domain([0, numBins - 1]).range([0, width]);
    const yScale = d3.scaleLinear().domain([0, 100]).range([0, height / 2]);

    // Area generator for smooth paths
    const areaTop = d3.area<number>()
      .x((d, i) => xScale(i))
      .y0(height / 2)
      .y1(d => height / 2 - yScale(d))
      .curve(d3.curveBasis);

    const areaBottom = d3.area<number>()
      .x((d, i) => xScale(i))
      .y0(height / 2)
      .y1(d => height / 2 + yScale(d))
      .curve(d3.curveBasis);

    // Color logic
    const primaryColor = isListening ? '#34d399' : isSpeaking ? '#22d3ee' : '#0891b2';
    const secondaryColor = isListening ? '#059669' : isSpeaking ? '#0284c7' : '#164e63';

    // Defs for gradients
    const defs = svg.append('defs');
    
    // Top gradient
    const gradTop = defs.append('linearGradient')
      .attr('id', 'gradTop')
      .attr('x1', '0%').attr('y1', '100%')
      .attr('x2', '0%').attr('y2', '0%');
    gradTop.append('stop').attr('offset', '0%').attr('stop-color', primaryColor).attr('stop-opacity', 0.8);
    gradTop.append('stop').attr('offset', '100%').attr('stop-color', secondaryColor).attr('stop-opacity', 0.1);

    // Bottom gradient
    const gradBottom = defs.append('linearGradient')
      .attr('id', 'gradBottom')
      .attr('x1', '0%').attr('y1', '0%')
      .attr('x2', '0%').attr('y2', '100%');
    gradBottom.append('stop').attr('offset', '0%').attr('stop-color', primaryColor).attr('stop-opacity', 0.8);
    gradBottom.append('stop').attr('offset', '100%').attr('stop-color', secondaryColor).attr('stop-opacity', 0.1);

    // Center Line
    svg.append('line')
      .attr('x1', 0).attr('y1', height / 2)
      .attr('x2', width).attr('y2', height / 2)
      .attr('stroke', primaryColor)
      .attr('stroke-width', 1)
      .attr('opacity', 0.5);

    const pathTop = svg.append('path')
      .attr('fill', 'url(#gradTop)')
      .attr('stroke', primaryColor)
      .attr('stroke-width', 1.5)
      .style('filter', isActive ? \`drop-shadow(0px 0px 8px \${primaryColor})\` : 'none');

    const pathBottom = svg.append('path')
      .attr('fill', 'url(#gradBottom)')
      .attr('stroke', primaryColor)
      .attr('stroke-width', 1.5)
      .style('filter', isActive ? \`drop-shadow(0px 0px 8px \${primaryColor})\` : 'none');

    let time = 0;
    const freqData = new Uint8Array(128);

    const draw = () => {
      time += 0.05;
      
      let realAudioActive = false;
      if (isListening && analyserRef.current) {
         analyserRef.current.getByteFrequencyData(freqData);
         realAudioActive = true;
      }

      for (let i = 0; i < numBins; i++) {
        if (!isActive) {
          dataRef.current[i] = dataRef.current[i] * 0.85 + 1 * 0.15; // decay to flat
        } else if (isListening) {
          if (realAudioActive) {
            // Mirror from center
            const centerDist = Math.abs((numBins / 2) - i);
            const freqIndex = Math.min(63, Math.floor((1 - centerDist / (numBins / 2)) * 30 + 5)); // focus on low/mid 
            const val = freqData[freqIndex] || 0;
            const h = Math.max(1, (val / 255) * 90);
            dataRef.current[i] = dataRef.current[i] * 0.6 + h * 0.4;
          } else {
            const centerDist = Math.abs((numBins / 2) - i);
            const dampen = Math.max(0, 1 - (centerDist / (numBins / 2)));
            const base = Math.sin(time * 3 + i * 0.4) * 8 + 15;
            dataRef.current[i] = (base + Math.random() * 5) * dampen + 2;
          }
        } else if (isSpeaking) {
          const centerDist = Math.abs((numBins / 2) - i);
          const dampen = Math.max(0, 1 - (centerDist / (numBins / 2)));
          const base = Math.sin(time * 5 + i * 0.6) * 20 + 30;
          dataRef.current[i] = (base + Math.random() * 15) * dampen + 2;
        }
      }

      pathTop.attr('d', areaTop(dataRef.current) as string);
      pathBottom.attr('d', areaBottom(dataRef.current) as string);
      
      animationRef.current = requestAnimationFrame(draw);
    };

    animationRef.current = requestAnimationFrame(draw);

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [isActive, isListening, isSpeaking]);

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 300 80"
      preserveAspectRatio="none"
      className="w-full h-full drop-shadow-lg"
    />
  );
};
`;

fs.writeFileSync('src/components/JarvisWaveform.tsx', code);
