const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Set default view to tactical
content = content.replace("useState<AppView>('dashboard');", "useState<AppView>('tactical');");

// Add silenceTimerRef
content = content.replace(
  'const wakeWordEnabledRef = useRef(settings.wakeWordEnabled);',
  'const wakeWordEnabledRef = useRef(settings.wakeWordEnabled);\n  const silenceTimerRef = useRef<any>(null);'
);

// Completely replace the recognition.onresult logic
const newOnResult = `
      recognition.onresult = (event: any) => {
        let fullTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          fullTranscript += event.results[i][0].transcript;
        }
        
        setInterimTranscript(fullTranscript);

        if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);

        silenceTimerRef.current = setTimeout(() => {
          const transcript = fullTranscript.trim();
          if (!transcript) return;

          const lower = transcript.toLowerCase();
          
          if (lower.includes('jarvis') || lower.includes('hey jarvis')) {
             const command = lower.split('jarvis')[1]?.trim() || transcript.replace(/^(hey )?jarvis[, ]*/i, '').trim();
             if (command) {
                isAwakeRef.current = false;
                handleVoiceCommand(command);
             } else {
                soundEffects.playChirp();
                isAwakeRef.current = true;
             }
          } else if (isAwakeRef.current || !wakeWordEnabledRef.current) {
             isAwakeRef.current = false;
             handleVoiceCommand(transcript);
          }
          
          setInterimTranscript('');
          
          // Stop to reset the event.results array, onend will auto-restart it
          try { recognition.stop(); } catch(e) {}

        }, 1500);
      };
`;

content = content.replace(/recognition\.onresult = \(event: any\) => \{[\s\S]*?^\s*\};\n/m, newOnResult);

fs.writeFileSync('src/App.tsx', content);
