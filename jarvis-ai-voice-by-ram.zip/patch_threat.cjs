const fs = require('fs');
let content = fs.readFileSync('src/components/Mark85SuitWidget.tsx', 'utf8');

if (!content.includes('ThreatDetectionWidget')) {
  content = content.replace(
    "import { SystemStatusWidget } from './SystemStatusWidget';",
    "import { SystemStatusWidget } from './SystemStatusWidget';\nimport { ThreatDetectionWidget } from './ThreatDetectionWidget';"
  );
}

if (!content.includes('const [isCombatMode, setIsCombatMode] = React.useState(false);')) {
  content = content.replace(
    "  const isScanning = useGestureDetection(2000, 3000);",
    "  const isScanning = useGestureDetection(2000, 3000);\n  const [isCombatMode, setIsCombatMode] = React.useState(false);"
  );
}

if (!content.includes('<ThreatDetectionWidget isCombatModeGlobally={setIsCombatMode} />')) {
  content = content.replace(
    "      {/* Background Grid & Hexagons */}",
    "      <ThreatDetectionWidget isCombatModeGlobally={setIsCombatMode} />\n      {/* Background Grid & Hexagons */}"
  );
}

// Let's replace some static text-yellow-400 with a dynamic one for combat mode
content = content.replace(
  'className="text-2xl font-bold tracking-[0.5em] uppercase text-yellow-400 drop-shadow-[0_0_15px_rgba(250,204,21,0.5)]"',
  'className={`text-2xl font-bold tracking-[0.5em] uppercase ${isCombatMode ? "text-red-500 drop-shadow-[0_0_25px_rgba(239,68,68,0.8)]" : "text-yellow-400 drop-shadow-[0_0_15px_rgba(250,204,21,0.5)]"}`}'
);

content = content.replace(
  'MARK 85',
  '{isCombatMode ? "COMBAT MODE" : "MARK 85"}'
);

fs.writeFileSync('src/components/Mark85SuitWidget.tsx', content);
