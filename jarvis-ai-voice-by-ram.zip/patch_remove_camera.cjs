const fs = require('fs');

let content = fs.readFileSync('src/components/Mark85SuitWidget.tsx', 'utf8');

// Remove import
content = content.replace("import { ThreatDetectionWidget } from './ThreatDetectionWidget';\n", "");

// Remove state and effect
content = content.replace("  const [isCombatMode, setIsCombatMode] = React.useState(false);\n", "");
content = content.replace("  React.useEffect(() => { if (isCombatMode) addLog('WARNING', 'THREAT DETECTED: Combat Mode Engaged'); else addLog('SYSTEM', 'Combat Mode Disengaged'); }, [isCombatMode]);\n", "");

// Remove component usage
content = content.replace("      <ThreatDetectionWidget isCombatModeGlobally={setIsCombatMode} />\n", "");

// Revert text styling
content = content.replace(
  'className={`text-2xl font-bold tracking-[0.5em] uppercase ${isCombatMode ? "text-red-500 drop-shadow-[0_0_25px_rgba(239,68,68,0.8)]" : "text-yellow-400 drop-shadow-[0_0_15px_rgba(250,204,21,0.5)]"}`}',
  'className="text-2xl font-bold tracking-[0.5em] uppercase text-yellow-400 drop-shadow-[0_0_15px_rgba(250,204,21,0.5)]"'
);

// Revert text content
content = content.replace(
  '{isCombatMode ? "COMBAT MODE" : "MARK 85"}',
  'MARK 85'
);

fs.writeFileSync('src/components/Mark85SuitWidget.tsx', content);

// Now edit metadata.json
let meta = JSON.parse(fs.readFileSync('metadata.json', 'utf8'));
meta.requestFramePermissions = meta.requestFramePermissions.filter(p => p !== 'camera');
fs.writeFileSync('metadata.json', JSON.stringify(meta, null, 2));

