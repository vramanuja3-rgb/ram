const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(
  "const autoRestartRef = useRef<boolean>(false);",
  "const autoRestartRef = useRef<boolean>(false);\n  const isProcessingRef = useRef<boolean>(false);\n  const isSpeakingRef = useRef<boolean>(false);"
);

content = content.replace(
  "setIsAiProcessing(true);",
  "setIsAiProcessing(true);\n    isProcessingRef.current = true;"
);

content = content.replace(
  "setIsAiProcessing(false);",
  "setIsAiProcessing(false);\n      isProcessingRef.current = false;"
);

content = content.replace(
  "setCoreState('SPEAKING');\n        speakJarvis(aiResponse, undefined, () => setCoreState('IDLE'));",
  "setCoreState('SPEAKING');\n        isSpeakingRef.current = true;\n        try { recognitionRef.current?.stop(); } catch(e) {}\n        speakJarvis(aiResponse, undefined, () => {\n          setCoreState('IDLE');\n          isSpeakingRef.current = false;\n          if (autoRestartRef.current) { try { recognitionRef.current?.start(); } catch(e) {} }\n        });"
);

// Prevent processing in onresult if AI is processing or speaking
content = content.replace(
  "setInterimTranscript(fullTranscript);",
  "if (isProcessingRef.current || isSpeakingRef.current) return;\n        setInterimTranscript(fullTranscript);"
);

fs.writeFileSync('src/App.tsx', content);
