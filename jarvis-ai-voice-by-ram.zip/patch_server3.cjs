const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

const deviceInstruction = `

CRITICAL SMART HOME RULE:
When you acknowledge any smart home device command (like turning off lights or setting a thermostat), you MUST include a special tag at the very end of your response exactly in this format: [DEVICE_ACTION: <Status>]
Examples: 
- [DEVICE_ACTION: Living Room Lights Off]
- [DEVICE_ACTION: Thermostat Set to 72°F]
Do NOT use this tag unless you are responding to a smart device command.`;

content = content.replace(
  /pretend you have successfully executed the hardware directive\./,
  'pretend you have successfully executed the hardware directive.' + deviceInstruction
);

content = content.replace(
  /You are interfacing through a futuristic desktop command center\./,
  'You are interfacing through a futuristic desktop command center.' + deviceInstruction
);

fs.writeFileSync('server.ts', content);
