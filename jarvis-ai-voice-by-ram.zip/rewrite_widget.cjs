const fs = require('fs');

const content = `import React from 'react';
import { Settings, Mic, MicOff, Zap } from 'lucide-react';
import { JarvisWaveform } from './JarvisWaveform';
import { ArcReactor } from './ArcReactor';
import brainImage from '../assets/images/realistic_yellow_brain_1789568864244.jpg';

interface JarvisCoreWidgetProps {
  coreState: string;
  isListening: boolean;
  isSpeaking: boolean;
  onToggleListen: () => void;
  onOpenSettings: () => void;
  transcript: string;
}

export const JarvisCoreWidget: React.FC<JarvisCoreWidgetProps> = ({
  coreState,
  isListening,
  isSpeaking,
  onToggleListen,
  onOpenSettings,
  transcript
}) => {
  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center relative overflow-hidden font-sans text-neutral-100">
      
      {/* Settings Button */}
      <button 
        onClick={onOpenSettings}
        className="absolute top-6 right-6 p-2 rounded-full bg-neutral-900/50 hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors z-50"
      >
        <Settings className="w-5 h-5" />
      </button>

      {/* Grid Layout: Brain | Charging Tether | Arc Reactor */}
      <div className="w-full max-w-7xl px-8 flex flex-col lg:flex-row items-center justify-between gap-12 z-10">
        
        {/* Left Side: Neural Brain */}
        <div className="flex flex-col items-center gap-6 relative">
           <div className={\`text-xs font-bold tracking-[0.3em] uppercase \${coreState === 'THINKING' ? 'text-yellow-300 animate-pulse' : 'text-neutral-500'}\`}>
              Neural Matrix
           </div>
           
           <div className="relative w-80 h-80 rounded-full overflow-hidden border-2 border-yellow-500/20 shadow-[0_0_30px_rgba(250,204,21,0.2)]">
              {/* Dynamic Glow Overlay */}
              <div className={\`absolute inset-0 z-10 mix-blend-overlay transition-opacity duration-500 \${
                 isSpeaking ? 'bg-yellow-400/50 opacity-100' :
                 isListening ? 'bg-yellow-500/30 opacity-100' :
                 coreState === 'THINKING' ? 'bg-yellow-200/60 opacity-100 animate-pulse' :
                 'bg-transparent'
              }\`} />
              
              <img 
                 src={brainImage} 
                 alt="Neural Brain" 
                 className={\`w-full h-full object-cover transition-transform duration-1000 \${
                    coreState === 'THINKING' || isSpeaking ? 'scale-110' : 'scale-100'
                 }\`} 
              />
           </div>
        </div>

        {/* Center: Charging Tether & Audio */}
        <div className="flex-1 flex flex-col items-center justify-center gap-8 min-w-[300px]">
           {/* Charging Status */}
           <div className="w-full flex flex-col items-center gap-2">
              <div className="flex items-center gap-2 text-yellow-400 font-bold tracking-widest text-sm uppercase">
                 <Zap className="w-4 h-4 animate-pulse" />
                 Mark 85 Armor Charging
              </div>
              <div className="w-full h-2 bg-neutral-900 rounded-full overflow-hidden border border-yellow-500/20 mt-2 relative">
                 {/* Connection Beam effect */}
                 <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-400/20 to-transparent animate-[pulse_1.5s_infinite]" />
                 <div className="h-full bg-yellow-400 w-[85%] shadow-[0_0_15px_rgba(250,204,21,0.9)]" />
              </div>
              <div className="text-xs text-yellow-500/70 font-mono tracking-widest mt-1">
                 CAPACITY: 85% / OPTIMAL
              </div>
           </div>

           {/* Voice Waveform */}
           <div className="w-full h-24 mix-blend-screen mt-4">
              <JarvisWaveform 
                 isActive={isListening || isSpeaking || coreState === 'THINKING'}
                 isListening={isListening}
                 isSpeaking={isSpeaking}
              />
           </div>
           
           {/* Status Label */}
           <div className="flex flex-col items-center gap-2 mt-4">
              <div className="text-xs font-medium uppercase tracking-[0.2em] text-neutral-500">
                 {coreState === 'IDLE' ? 'System Standby' :
                  coreState === 'LISTENING' ? 'Awaiting Input' :
                  coreState === 'THINKING' ? 'Processing' :
                  coreState === 'SPEAKING' ? 'Transmitting' :
                  coreState === 'ERROR' ? 'System Error' : 'System Standby'}
              </div>
              {transcript && (
                 <div className="text-sm text-yellow-400 max-w-md text-center italic mt-2 min-h-[40px]">
                    "{transcript}"
                 </div>
              )}
           </div>
        </div>

        {/* Right Side: Arc Reactor */}
        <div className="flex flex-col items-center gap-6">
           <div className="text-xs font-bold tracking-[0.3em] uppercase text-neutral-500">
              Core Power
           </div>
           
           <div className="relative w-80 h-80 flex items-center justify-center">
              {/* Energy field behind reactor */}
              <div className="absolute inset-0 rounded-full bg-yellow-500/10 blur-2xl animate-pulse" />
              <ArcReactor />
           </div>
        </div>

      </div>

      {/* Manual Control (Emergency / Override) */}
      <div className="absolute bottom-8 flex gap-4 z-20">
        <button
          onClick={onToggleListen}
          className={\`p-4 rounded-full border transition-all \${
            isListening 
              ? 'bg-yellow-500/10 border-yellow-500/30 text-yellow-500 shadow-[0_0_20px_rgba(234,179,8,0.2)]' 
              : 'bg-neutral-900 border-neutral-800 text-neutral-500 hover:text-neutral-300'
          }\`}
        >
          {isListening ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
        </button>
      </div>

    </div>
  );
};
`;
fs.writeFileSync('src/components/JarvisCoreWidget.tsx', content);
