const fs = require('fs');

const arcReactorContent = `import React from 'react';

export const ArcReactor = () => {
  return (
    <svg viewBox="0 0 500 500" className="w-full h-full drop-shadow-[0_0_25px_rgba(34,211,238,0.6)]">
      <defs>
        {/* Glow Filters */}
        <filter id="core-glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="8" result="blur1" />
          <feGaussianBlur stdDeviation="20" result="blur2" />
          <feMerge>
            <feMergeNode in="blur2" />
            <feMergeNode in="blur1" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>

        <filter id="aura" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="15" result="blur1" />
          <feGaussianBlur stdDeviation="35" result="blur2" />
          <feMerge>
            <feMergeNode in="blur2" />
            <feMergeNode in="blur1" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>

        <linearGradient id="metal" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0f172a" />
          <stop offset="50%" stopColor="#1e293b" />
          <stop offset="100%" stopColor="#020617" />
        </linearGradient>

        <radialGradient id="center-flare" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="25%" stopColor="#cffafe" />
          <stop offset="55%" stopColor="#06b6d4" />
          <stop offset="100%" stopColor="transparent" />
        </radialGradient>
      </defs>

      {/* Atmospheric Purple/Blue Aura */}
      <circle cx="250" cy="250" r="210" fill="transparent" stroke="rgba(99, 102, 241, 0.5)" strokeWidth="30" filter="url(#aura)" />
      <circle cx="250" cy="250" r="190" fill="transparent" stroke="rgba(6, 182, 212, 0.6)" strokeWidth="40" filter="url(#aura)" />

      {/* Deep Dark Base */}
      <circle cx="250" cy="250" r="230" fill="#000000" />

      {/* Outer Cyan segmented Ring */}
      <g style={{ transformOrigin: '250px 250px' }} className="animate-[spin_30s_linear_infinite]">
        <circle cx="250" cy="250" r="175" fill="none" stroke="#a5f3fc" strokeWidth="45" filter="url(#core-glow)" />
        <circle cx="250" cy="250" r="175" fill="none" stroke="#ffffff" strokeWidth="12" opacity="0.9" />
        {/* Dark Notches to segment the outer ring */}
        {[...Array(12)].map((_, i) => (
          <line 
            key={i} 
            x1="250" y1="250" 
            x2={250 + 250 * Math.sin((i * 30 * Math.PI) / 180)} 
            y2={250 - 250 * Math.cos((i * 30 * Math.PI) / 180)} 
            stroke="#000000"
            strokeWidth="16"
          />
        ))}
      </g>

      {/* Mid Dark Ring Mask */}
      <circle cx="250" cy="250" r="150" fill="url(#metal)" />

      {/* Structural "X" shapes bordering the triangle */}
      {/* We will draw dark polygons overlaying the background */}
      <g fill="#000000">
        <polygon points="120,70 380,70 250,150" />
        <polygon points="50,220 180,450 200,280" />
        <polygon points="450,220 320,450 300,280" />
      </g>

      {/* Outer Triangular Frame (Dark Metallic) */}
      <polygon 
        points="250,390 371.24,180 128.76,180" 
        fill="url(#metal)" 
        stroke="#000000" 
        strokeWidth="10"
        strokeLinejoin="round"
      />
      {/* Cyan Glowing Border of the Frame */}
      <polygon 
        points="250,390 371.24,180 128.76,180" 
        fill="none" 
        stroke="#22d3ee" 
        strokeWidth="8"
        strokeLinejoin="round"
        filter="url(#core-glow)"
      />

      {/* Middle Cyan Triangular Band */}
      <polygon 
        points="250,335 323.6,207.5 176.4,207.5" 
        fill="none" 
        stroke="#a5f3fc" 
        strokeWidth="20"
        strokeLinejoin="round"
        filter="url(#core-glow)"
      />

      {/* Intense White Core Flare */}
      <circle cx="250" cy="240" r="90" fill="url(#center-flare)" filter="url(#core-glow)" />

      {/* Innermost Blinding White Triangle */}
      <polygon 
        points="250,305 297.6,222.5 202.4,222.5" 
        fill="#ffffff" 
        stroke="#ffffff"
        strokeWidth="8"
        strokeLinejoin="round"
        filter="url(#core-glow)"
      />
    </svg>
  );
};
`;

fs.writeFileSync('src/components/ArcReactor.tsx', arcReactorContent);

// Now update Mark85SuitWidget to use cyan theme instead of yellow to match the new core.
let mark85 = fs.readFileSync('src/components/Mark85SuitWidget.tsx', 'utf8');

// Replace yellow color classes with cyan/blue equivalents
mark85 = mark85.replace(/bg-yellow-500\/10 blur-3xl/g, 'bg-cyan-500/20 blur-3xl');
mark85 = mark85.replace(/text-yellow-400/g, 'text-cyan-400');
mark85 = mark85.replace(/border-yellow-500/g, 'border-cyan-500');
mark85 = mark85.replace(/bg-yellow-400/g, 'bg-cyan-400');
mark85 = mark85.replace(/rgba\(250,204,21/g, 'rgba(6,182,212'); // drop shadow colors
mark85 = mark85.replace(/text-yellow-500/g, 'text-cyan-500');
mark85 = mark85.replace(/bg-yellow-500/g, 'bg-cyan-500');

fs.writeFileSync('src/components/Mark85SuitWidget.tsx', mark85);

