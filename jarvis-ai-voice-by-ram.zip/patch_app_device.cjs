const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Add deviceAction state
content = content.replace(
  "const [interimTranscript, setInterimTranscript] = useState('');",
  "const [interimTranscript, setInterimTranscript] = useState('');\n  const [deviceAction, setDeviceAction] = useState<string | null>(null);"
);

// In handleSendMessage, check for the tag
const processAIResponse = `
      let aiResponse = data.text;
      
      const deviceActionMatch = aiResponse.match(/\\[DEVICE_ACTION:\\s*(.*?)\\]/);
      if (deviceActionMatch) {
        setDeviceAction(deviceActionMatch[1]);
        aiResponse = aiResponse.replace(deviceActionMatch[0], '').trim();
      }
      
      // Update the streaming message to final
`;

content = content.replace(
  "const aiResponse = data.text;\n      // Update the streaming message to final",
  processAIResponse
);

// Add clearDeviceAction to handleVoiceCommand or similar? No, pass it to LegacyHUD
content = content.replace(
  "<LegacyHUD \n              messages={currentSession?.messages || []}",
  `<LegacyHUD 
              messages={currentSession?.messages || []}
              deviceAction={deviceAction}
              onClearDeviceAction={() => setDeviceAction(null)}`
);

fs.writeFileSync('src/App.tsx', content);
