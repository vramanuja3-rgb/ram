const fs = require('fs');
const content = `import React, { useState, useEffect } from 'react';
import { JarvisCoreWidget } from './components/JarvisCoreWidget';
import { BrainReactorWidget } from './components/BrainReactorWidget';
import { useVoiceRecognition } from './hooks/useVoiceRecognition';
import { SettingsPanel } from './components/SettingsPanel';

function App() {
  const [showSettings, setShowSettings] = useState(false);
  const [useBrainReactor, setUseBrainReactor] = useState(true);
  
  // Basic mock state since useJarvisCore doesn't exist in this iteration
  const [coreState, setCoreState] = useState('IDLE');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  
  const toggleListen = () => {
    setIsListening(!isListening);
    setCoreState(!isListening ? 'LISTENING' : 'IDLE');
  };

  return (
    <>
      <button 
        onClick={() => setUseBrainReactor(!useBrainReactor)}
        className="absolute top-6 left-6 p-2 rounded-lg bg-neutral-900/50 hover:bg-neutral-800 text-yellow-400 hover:text-yellow-300 transition-colors z-50 text-xs font-bold tracking-widest uppercase border border-yellow-500/20"
      >
        Toggle View
      </button>

      {useBrainReactor ? (
        <BrainReactorWidget 
          coreState={coreState}
          isListening={isListening}
          isSpeaking={isSpeaking}
          transcript={""}
          onToggleListen={toggleListen}
          onOpenSettings={() => setShowSettings(true)}
        />
      ) : (
        <JarvisCoreWidget 
          coreState={coreState}
          isListening={isListening}
          isSpeaking={isSpeaking}
          transcript={""}
          onToggleListen={toggleListen}
          onOpenSettings={() => setShowSettings(true)}
        />
      )}
      <SettingsPanel isOpen={showSettings} onClose={() => setShowSettings(false)} />
    </>
  );
}

export default App;
`;
fs.writeFileSync('src/App.tsx', content);
