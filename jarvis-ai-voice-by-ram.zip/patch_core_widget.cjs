const fs = require('fs');
let content = fs.readFileSync('src/components/JarvisCoreWidget.tsx', 'utf8');

const newCore = `
      {/* Background Arc Reactor */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden">
         <ArcReactor />
      </div>

      {/* Rotating Brain inside Center Core */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center pointer-events-none">
         <Brain 
           className="w-24 h-24 text-yellow-400/90 animate-[spin_10s_linear_infinite]" 
           style={{ filter: 'drop-shadow(0 0 15px rgba(250,204,21,0.8))' }} 
         />
      </div>

      {/* Dynamic State Glows Overlaid on Core */}
      <div className={\`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] rounded-full blur-3xl transition-opacity duration-1000 \${
         isSpeaking ? 'bg-yellow-400/30 opacity-100' :
         isListening ? 'bg-yellow-500/20 opacity-100' :
         coreState === 'THINKING' ? 'bg-yellow-300/30 opacity-100' :
         coreState === 'ERROR' ? 'bg-red-500/30 opacity-100' :
         'bg-yellow-600/5 opacity-50'
      }\`} pointer-events-none />

      {/* The Waveform - Shifted down for visual clarity */}
      <div className="relative z-10 w-80 h-32 mt-72 mix-blend-screen drop-shadow-[0_0_15px_rgba(253,224,71,0.9)]">
         <JarvisWaveform 
            isActive={isListening || isSpeaking || coreState === 'THINKING'}
            isListening={isListening}
            isSpeaking={isSpeaking}
         />
      </div>
`;

content = content.replace(
  /\{\/\* Background Arc Reactor & Brain \*\/\}.*?\{\/\* The Waveform \*\/\}.*?<\/div>.*?<\/div>/s,
  newCore
);

content = content.replace(
  "import { JarvisWaveform } from './JarvisWaveform';",
  "import { JarvisWaveform } from './JarvisWaveform';\nimport { ArcReactor } from './ArcReactor';"
);

fs.writeFileSync('src/components/JarvisCoreWidget.tsx', content);
