const fs = require('fs');

let content = fs.readFileSync('src/components/Mark85SuitWidget.tsx', 'utf8');

if (!content.includes('GeoLocationHUDWidget')) {
  content = content.replace(
    "import { SystemStatusWidget } from './SystemStatusWidget';",
    "import { SystemStatusWidget } from './SystemStatusWidget';\nimport { GeoLocationHUDWidget } from './GeoLocationHUDWidget';"
  );
  
  content = content.replace(
    "<SystemStatusWidget />",
    "<GeoLocationHUDWidget />\n      <SystemStatusWidget />"
  );
  
  fs.writeFileSync('src/components/Mark85SuitWidget.tsx', content);
}
