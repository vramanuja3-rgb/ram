const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(
  /<SettingsPanel isOpen=\{showSettings\} onClose=\{\(\) => setShowSettings\(false\)\} settings=\{settings\} onUpdateSettings=\{setSettings\} \/>/,
  '{showSettings && <SettingsPanel onClose={() => setShowSettings(false)} settings={settings} onUpdateSettings={setSettings} />}'
);

fs.writeFileSync('src/App.tsx', content);
