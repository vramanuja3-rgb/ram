const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  /async function startServer\(\) \{/,
  `import http from "http";\n\nasync function startServer() {\n  const server = http.createServer(app);`
);

code = code.replace(
  /if \(process\.env\.NODE_ENV !== "production"\) \{[\s\S]*?app\.use\(vite\.middlewares\);\n  \} else \{/,
  `if (process.env.NODE_ENV !== "production") {
    vite = await createViteServer({
      server: { middlewareMode: true, hmr: { server } },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {`
);

code = code.replace(
  /const server = app\.listen\(PORT, "0\.0\.0\.0", \(\) => \{/,
  `server.listen(PORT, "0.0.0.0", () => {`
);

fs.writeFileSync('server.ts', code);
