const fs = require('fs');
let content = fs.readFileSync('src/components/Sidebar.tsx', 'utf8');

const newButton = `        <button
          onClick={() => onChangeView('dashboard')}
          className={\`w-full flex items-center gap-2 px-3 py-2 rounded-md transition-colors \${currentView === 'dashboard' ? 'bg-cyan-950/60 text-cyan-300 border border-cyan-500/30' : 'text-neutral-400 hover:bg-white/5 hover:text-cyan-200 border border-transparent'}\`}
        >
          <Grid className="w-4 h-4" /> Command Center
        </button>
        <button
          onClick={() => onChangeView('tactical')}
          className={\`w-full flex items-center gap-2 px-3 py-2 rounded-md transition-colors \${currentView === 'tactical' ? 'bg-cyan-950/60 text-cyan-300 border border-cyan-500/30' : 'text-neutral-400 hover:bg-cyan-950/40 hover:text-cyan-400 border border-transparent font-orbitron text-sm uppercase tracking-widest'}\`}
        >
          <Cpu className="w-4 h-4" /> Tactical HUD
        </button>`;

content = content.replace(
  /<button[\s\S]*?Command Center\n\s*<\/button>/,
  newButton
);

fs.writeFileSync('src/components/Sidebar.tsx', content);
