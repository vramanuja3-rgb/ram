const fs = require('fs');
let content = fs.readFileSync('src/components/JarvisCoreWidget.tsx', 'utf8');

content = content.replace(
  /className=\{\`w-full h-full object-cover transition-transform duration-1000 \\\$\{\s*coreState === 'THINKING' \|\| isSpeaking \? 'scale-110' : 'scale-100'\s*\}\`\}/,
  "className={\`w-full h-full object-cover transition-transform duration-1000 animate-[spin_20s_linear_infinite] \${coreState === 'THINKING' || isSpeaking ? 'scale-110' : 'scale-100'}\`}"
);

fs.writeFileSync('src/components/JarvisCoreWidget.tsx', content);
