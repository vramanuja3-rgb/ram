const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');
code = code.replace('import http from "http";\n\n', '');
code = 'import http from "http";\n' + code;
fs.writeFileSync('server.ts', code);
