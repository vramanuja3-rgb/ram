const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Fix playChirp reference
content = content.replace(/playChirp\(\)/g, 'soundEffects.playChirp()');

// Fix toggleListen
const cleanToggleListen = `
  const toggleListen = () => {
    if (!recognitionRef.current) {
      alert("Microphone access is required or unsupported by this browser.");
      return;
    }
    if (isListening) {
      autoRestartRef.current = false;
      recognitionRef.current.stop();
    } else {
      autoRestartRef.current = true; // Siri mode stays on
      try { recognitionRef.current.start(); } catch(e) {}
    }
  };
`;

content = content.replace(/const toggleListen = \(\) => \{[\s\S]*?\};[\s\n]*const handleNewSession/, cleanToggleListen + '\n  const handleNewSession');

fs.writeFileSync('src/App.tsx', content);
