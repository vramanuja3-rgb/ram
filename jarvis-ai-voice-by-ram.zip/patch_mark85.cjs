const fs = require('fs');
let content = fs.readFileSync('src/components/Mark85SuitWidget.tsx', 'utf8');

// Add import
if (!content.includes('SystemStatusWidget')) {
  content = content.replace(
    "import { ArcReactor } from './ArcReactor';",
    "import { ArcReactor } from './ArcReactor';\nimport { SystemStatusWidget } from './SystemStatusWidget';"
  );
}

// Add widget right before the closing </div> of the main container
if (!content.includes('<SystemStatusWidget />')) {
  content = content.replace(
    "      {/* Manual Control */}",
    "      <SystemStatusWidget />\n\n      {/* Manual Control */}"
  );
}

fs.writeFileSync('src/components/Mark85SuitWidget.tsx', content);
