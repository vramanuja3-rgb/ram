const fs = require('fs');
let content = fs.readFileSync('src/components/BrainReactorWidget.tsx', 'utf8');

// Replace the escaped backticks/dollar signs which got messed up during the HEREDOC interpolation
content = content.replace(/\\`/g, '`');
content = content.replace(/\\\$/g, '$');

fs.writeFileSync('src/components/BrainReactorWidget.tsx', content);
